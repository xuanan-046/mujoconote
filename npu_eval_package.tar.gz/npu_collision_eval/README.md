# npu_collision_eval —— NPU 碰撞检测优化的阶段级对比测评

和原版 MuJoCo 逐阶段(pipeline-stage)对比:**效果有无差异 / 能不能更好**。
不看碰撞算子内部(GJK simplex / EPA polytope),只在 `mj_step` 各阶段边界比 `mjData`。

方法学模板:
- MuJoCo `test/pipeline_test.cc`(整条 pipeline 跨配置一致性)
- `mujoco_warp/_src/collision_driver_test.py`(跨实现容差对照 + 无序接触匹配)

配套设计文档:`../npu_collision_eval_plan.md` 的 **§ E 测评执行流程**。

---

## 装

```bash
pip install -r requirements.txt          # mujoco==3.11.0 + numpy + pyyaml + pytest
# 可选,内部有 N 卡的机器:
pip install mujoco-warp==<pin> warp-lang  # mjwarp 参考泳道
```

## 四条泳道

| lane | 是什么 | 何时可用 |
|---|---|---|
| `cpu_fp64` | 官方 double 构建,**唯一 ground truth** | 总是(默认 wheel) |
| `cpu_fp32` | `mjtNum=float` 构建,"纯精度损失"基线 | 需单独 float wheel(见下) |
| `mjwarp` | MuJoCo Warp,GPU 参考带 | 需 NVIDIA GPU + `mujoco-warp` |
| `npu` | **被测对象**,填 `npu_eval/lanes.py:NpuHandle` | 设 `NPU_EVAL_ENABLE=1`;否则自动降级为 mock |

## 两种模式

- **`free`(模式 A 自由运行)**:各泳道从同一初值跑 N 步,每步在 S3/S4/S6/S9/S10 边界快照,逐阶段对照。看碰撞差异经 S4→S9→S10 是收敛还是发散。
- **`hybrid`(混合)**:被测泳道只跑碰撞(`collision_only`),接触喂回 `cpu_fp64` 跑 S4..S10,比 `qacc` / 下一帧 `qpos` 与纯 `cpu_fp64` 的差异 —— **直接回答"碰撞差异影不影响仿真结果"**。

## 跑

```bash
# 无 NPU,mock 泳道跑通全流程(冒烟)
python scripts/run_eval.py --lanes cpu_fp64 npu --modes free hybrid --nstep 20

# 内部机器,全泳道
NPU_EVAL_ENABLE=1 python scripts/run_eval.py \
    --lanes cpu_fp64 cpu_fp32 mjwarp npu --modes free hybrid \
    --nstep 40 --seeds 0 1 2 --jitter 1e-3

# pytest 形态(CI)
pytest -q
```

产出:`report/report.md`、`report/results.csv`、`report/summary.json`。
`run_eval.py` 退出码:全 PASS = 0,有 FAIL = 1(可直接做 CI gate)。

---

## 接你的 NPU(唯一必填的地方)

编辑 `npu_eval/lanes.py` 的 `NpuHandle`:

```python
class NpuHandle:
    def __init__(self, xml): ...              # 初始化 NPU 上下文,加载模型
    def reset(self, qpos, qvel, act, ctrl): ...
    def collision_only(self, qpos, qvel) -> np.ndarray:
        # 调 NPU 碰撞 kernel;按 MuJoCo 确定性接触排序规则重排;
        # 返回 [N, 21] = [dist(1), pos(3), frame(9), dim(1), geom(2), friction(5)]
        ...
    def run_full(self, nstep, snap_stages):  # 仅当 NPU 能跑完整 mj_step 才需要
        ...
```

只做碰撞检测 → 实现 `collision_only` 就够,用 `--modes hybrid`。
能跑整步 → 再实现 `run_full`,可用 `--modes free`。

## 标定阈值(Phase 2.4)

`config/thresholds.yaml` 里的 p95 阈值现在是占位值(参照 mujoco_warp 的 `5e-2/1e-2`)。
正式值来自 `cpu_fp64` vs `cpu_fp32` 的实测误差带:

```bash
# 在装了 float 构建 mujoco 的 venv 里:
python scripts/gen_golden.py --nstep 40      # 产出 golden/fp32_band.json
# 把 fp32_band.json 的 p95 × 1.5 回填到 thresholds.yaml
```

硬门禁不受标定影响,永远是:`missed_rate=0`、`normal_flip_rate=0`、broadphase 非子集。

## 阶段 → 代码映射

| § E 阶段 | 代码 | gate |
|---|---|---|
| E0 环境校验 | `tests/test_e0_env.py`(golden checksum / 模型加载 / mj 版本) | — |
| E1 冒烟 | `tests/test_e1_smoke.py` | 不崩 + 无 NaN |
| S3 碰撞 | `runner.run_free` → `metrics.stage_metrics("S3")` → `gates.check_stage` | 漏检=0;翻转=0;`dist/pos/normal` p95 |
| S4 构建约束 | 同上 `"S4"` | `nefc` 一致;`efc_J` 相对差 |
| S6 速度相关 | 同上 `"S6"` | `efc_aref` / `qfrc_bias` |
| S9 约束求解 | 同上 `"S9"` | `qacc_linf`;`solver_niter` 差 |
| S10 积分 | 同上 `"S10"` | `qpos/qvel` H 步发散 |
| 下游敏感度 | `runner.run_hybrid` | `qacc_linf` |
| 报告 | `report.write_markdown` / `write_csv` | `run_eval.py` 退出码 |

## 文件

```
npu_eval/
  stages.py     阶段分解(已验证 == mj_forward+mj_Euler) + mjData 快照
  lanes.py      4 条泳道 + Mock NPU;NpuHandle 是唯一 TODO
  fixtures.py   碰撞用例(前 9 条逐字来自 mujoco_warp) + 解析/退化/场景补充
  matching.py   无序接触匹配器(抄自 mujoco_warp collision_driver_test.py)
  metrics.py    每阶段对照指标
  gates.py      指标 vs thresholds.yaml -> PASS/FAIL
  runner.py     cases × lanes × modes 编排
  report.py     markdown + csv
config/thresholds.yaml   阈值(占位,待 fp32 band 标定)
scripts/
  gen_golden.py  生成 golden + fp32 误差带
  run_eval.py    一键跑 + 出报告 + CI 退出码
golden/          cpu_fp64 参考快照 + sha256 manifest
```

## 已知限制(v0.1)

- `hybrid` 注入接触时,若 NPU 接触数 > `cpu_fp64` 本步分配的 `d.contact` 容量,会截断并在
  `metrics.ncon_test/ncon_cap` 标注。绝大多数 fp32 级扰动不改变接触数,不受影响。
- `mjwarp` 泳道的 `run_full` 因 MJWarp 不暴露与 C 完全一致的阶段切分,退化为整步 + 末态
  快照;逐阶段对照请直接用 `mujoco_warp` 自带的 `forward_test.py` / `constraint_test.py` /
  `solver_test.py`。
- `cpu_fp32` 需要单独的 float 构建;官方 PyPI wheel 是 double。
