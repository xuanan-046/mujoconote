"""碰撞用例 fixture。

_FIXTURES 前若干条逐字来自 mujoco_warp/_src/collision_driver_test.py (Apache-2.0),
其余是常见解析/退化位形补充。每条是一段自包含 MJCF 字符串。

tier:
  analytic   —— 有闭式解
  primitive  —— 解析 primitive 碰撞函数
  degenerate —— GJK/EPA 易翻车位形
  scene      —— 多体场景, 走 rollout
"""
from __future__ import annotations

# ---- 来自 mujoco_warp collision_driver_test.py 的 _FIXTURES ----------------
MJWARP_FIXTURES = {
    "box_plane": ("""
        <mujoco><worldbody>
          <geom size="40 40 40" type="plane"/>
          <body pos="0 0 0.3" euler="45 0 0"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "primitive"),
    "box_box_vf": ("""
        <mujoco><worldbody>
          <body pos="0 -0.2 1.2" euler="44 46 0"><freejoint/><geom size="0.6 0.4 0.7" type="box"/></body>
          <body pos="0 0 0" euler="0 0 0"><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "box_box_ee": ("""
        <mujoco><worldbody>
          <body pos="0 0 0" euler="0 45 0"><geom size="0.5 0.5 0.5" type="box"/></body>
          <body pos="0 0 1.6" euler="44 0 90"><freejoint/><geom size="0.6 0.4 0.7" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "box_box_ee_deep": ("""
        <mujoco><worldbody>
          <body pos="0 0 0" euler="0 74 0"><geom size="0.4 0.45 0.4" type="box"/></body>
          <body pos="0 0 1.2" euler="24 0 90"><freejoint/><geom size="0.6 0.4 0.7" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "plane_sphere": ("""
        <mujoco><worldbody>
          <geom size="40 40 40" type="plane"/>
          <body pos="0 0 0.2" euler="45 0 0"><freejoint/><geom size="0.5" type="sphere"/></body>
        </worldbody></mujoco>""", "analytic"),
    "plane_ellipsoid": ("""
        <mujoco><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 .299"><geom type="ellipsoid" size=".1 .2 .3"/><freejoint/></body>
        </worldbody></mujoco>""", "primitive"),
    "plane_capsule": ("""
        <mujoco><worldbody>
          <geom size="40 40 40" type="plane"/>
          <body pos="0 0 0.0" euler="30 30 0"><freejoint/><geom size="0.05 0.05" type="capsule"/></body>
        </worldbody></mujoco>""", "primitive"),
    "convex_convex": ("""
        <mujoco><asset>
          <mesh name="poly" vertex="0.3 0 0  0 0.5 0  -0.3 0 0  0 -0.5 0  0 -1 1  0 1 1"/>
        </asset><worldbody>
          <body pos="0.0 2.0 0.35" euler="0 0 90"><freejoint/><geom size="0.2 0.2 0.2" type="mesh" mesh="poly"/></body>
          <body pos="0.0 2.0 2.281" euler="180 0 0"><freejoint/><geom size="0.2 0.2 0.2" type="mesh" mesh="poly"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "capsule_capsule": ("""
        <mujoco model="two_capsules"><worldbody>
          <body><joint type="free"/><geom fromto="0.62235904 0.58846647 0.651046 1.5330081 0.33564585 0.977849" size="0.05" type="capsule"/></body>
          <body><joint type="free"/><geom fromto="0.5505271 0.60345304 0.476661 1.3900293 0.30709633 0.932082" size="0.05" type="capsule"/></body>
        </worldbody></mujoco>""", "primitive"),
}

# ---- 解析 / 退化补充 -----------------------------------------------------
EXTRA_FIXTURES = {
    "sphere_sphere_overlap": ("""
        <mujoco><worldbody>
          <body pos="0 0 0"><geom size="0.5" type="sphere"/></body>
          <body pos="0.8 0 0"><freejoint/><geom size="0.5" type="sphere"/></body>
        </worldbody></mujoco>""", "analytic"),
    "sphere_plane_grazing": ("""
        <mujoco><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.4999"><freejoint/><geom size="0.5" type="sphere"/></body>
        </worldbody></mujoco>""", "analytic"),
    "capsule_capsule_parallel": ("""
        <mujoco><worldbody>
          <body pos="0 0 0"><geom fromto="-1 0 0 1 0 0" size="0.1" type="capsule"/></body>
          <body pos="0 0 0.19"><freejoint/><geom fromto="-1 0 0 1 0 0" size="0.1" type="capsule"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "box_plane_flush": ("""
        <mujoco><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
}

# ---- 多体场景 (rollout) ------------------------------------------------
# 起始即接触/极近, 让 free 模式前几步就有 contact。
SCENE_FIXTURES = {
    "box_stack3": ("""
        <mujoco><option timestep="0.002"/><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
          <body pos="0.01 0 1.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
          <body pos="-0.01 0.01 2.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "scene"),
    "spheres_20": ("""
        <mujoco><option timestep="0.002"/><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <replicate count="20" offset="0.19 0 0">
            <body pos="-1.9 0 0.1"><freejoint/><geom size="0.1" type="sphere"/></body>
          </replicate>
        </worldbody></mujoco>""", "scene"),
    "box_drop": ("""
        <mujoco><option timestep="0.004"/><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.56" euler="3 2 0"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "scene"),
}

ALL_FIXTURES = {**MJWARP_FIXTURES, **EXTRA_FIXTURES, **SCENE_FIXTURES}


def by_tier(*tiers):
    return {k: v for k, (v, t) in ALL_FIXTURES.items() if t in tiers}


def xml_of(name):
    return ALL_FIXTURES[name][0]


def tier_of(name):
    return ALL_FIXTURES[name][1]
