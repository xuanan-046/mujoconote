# NPU 碰撞检测 —— 阶段级对比测评报告

```
timestamp: 2026-09-11T11:18:18
lanes: ['cpu_fp64', 'npu']
modes: ['free', 'hybrid']
nstep: 30
seeds: [0, 1, 2]
jitter: 0.0
```

## 总判定

**FAIL ❌ (69/1389 项)** — pass_rate = 0.950

| mode:stage | pass/total |
|---|---|
| free:S10 | 270/270 |
| free:S3 | 270/270 |
| free:S4 | 267/270 |
| free:S6 | 228/270 |
| free:S9 | 246/270 |
| hybrid:S9/S10 | 39/39 |

## 失败明细

| case | lane | stage | seed | step | 原因 |
|---|---|---|---|---|---|
| box_stack3 | npu | S4 | 0 | 3 | efc_J_rel.p95=0.9985 > 0.05 |
| box_stack3 | npu | S4 | 1 | 3 | efc_J_rel.p95=0.9985 > 0.05 |
| box_stack3 | npu | S4 | 2 | 3 | efc_J_rel.p95=0.9985 > 0.05 |
| spheres_20 | npu | S9 | 0 | 0 | qacc_rel_p95=1.188e+05 > 0.05 |
| spheres_20 | npu | S9 | 0 | 2 | qacc_rel_p95=0.05483 > 0.05 |
| spheres_20 | npu | S9 | 0 | 3 | qacc_rel_p95=0.07886 > 0.05 |
| spheres_20 | npu | S9 | 0 | 4 | qacc_rel_p95=0.05293 > 0.05 |
| spheres_20 | npu | S9 | 0 | 5 | qacc_rel_p95=0.05143 > 0.05 |
| spheres_20 | npu | S9 | 0 | 6 | qacc_rel_p95=0.0725 > 0.05 |
| spheres_20 | npu | S9 | 0 | 7 | qacc_rel_p95=0.06208 > 0.05 |
| spheres_20 | npu | S9 | 0 | 8 | qacc_rel_p95=0.05057 > 0.05 |
| spheres_20 | npu | S9 | 1 | 0 | qacc_rel_p95=1.188e+05 > 0.05 |
| spheres_20 | npu | S9 | 1 | 2 | qacc_rel_p95=0.05483 > 0.05 |
| spheres_20 | npu | S9 | 1 | 3 | qacc_rel_p95=0.07886 > 0.05 |
| spheres_20 | npu | S9 | 1 | 4 | qacc_rel_p95=0.05293 > 0.05 |
| spheres_20 | npu | S9 | 1 | 5 | qacc_rel_p95=0.05143 > 0.05 |
| spheres_20 | npu | S9 | 1 | 6 | qacc_rel_p95=0.0725 > 0.05 |
| spheres_20 | npu | S9 | 1 | 7 | qacc_rel_p95=0.06208 > 0.05 |
| spheres_20 | npu | S9 | 1 | 8 | qacc_rel_p95=0.05057 > 0.05 |
| spheres_20 | npu | S9 | 2 | 0 | qacc_rel_p95=1.188e+05 > 0.05 |
| spheres_20 | npu | S9 | 2 | 2 | qacc_rel_p95=0.05483 > 0.05 |
| spheres_20 | npu | S9 | 2 | 3 | qacc_rel_p95=0.07886 > 0.05 |
| spheres_20 | npu | S9 | 2 | 4 | qacc_rel_p95=0.05293 > 0.05 |
| spheres_20 | npu | S9 | 2 | 5 | qacc_rel_p95=0.05143 > 0.05 |
| spheres_20 | npu | S9 | 2 | 6 | qacc_rel_p95=0.0725 > 0.05 |
| spheres_20 | npu | S9 | 2 | 7 | qacc_rel_p95=0.06208 > 0.05 |
| spheres_20 | npu | S9 | 2 | 8 | qacc_rel_p95=0.05057 > 0.05 |
| box_drop | npu | S6 | 0 | 16 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 17 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 18 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 19 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 20 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 21 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 22 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 23 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 24 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 25 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 26 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 27 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 28 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 29 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 16 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 17 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 18 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 19 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 20 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 21 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 22 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 23 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 24 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 25 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 26 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 27 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 28 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 29 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 16 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 17 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 18 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 19 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 20 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 21 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 22 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 23 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 24 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 25 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 26 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 27 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 28 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 29 | qfrc_bias_rel.p95 > 0.001 |

## S3 碰撞阶段误差(按 case 聚合最坏值)

| case | tier | lane | missed | flip | ncon(r/t) | dist_p95 | pos_p95 | normal°_p95 |
|---|---|---|---|---|---|---|---|---|
| box_drop | scene | npu | 0.000 | 0.000 | 0/0 | 1.32e-10 | 1.64e-08 | 0.00 |
| box_stack3 | scene | npu | 0.000 | 0.000 | 12/12 | 1.58e-11 | 6.03e-08 | 0.00 |
| spheres_20 | scene | npu | 0.000 | 0.000 | 29/29 | 1.61e-09 | 5.70e-08 | 0.00 |

## 混合模式 —— 碰撞差异是否影响下游

| case | lane | qacc_linf | qpos_linf | ncon(test/cap) | pass |
|---|---|---|---|---|---|
| box_plane | npu | 1.482e-05 | 5.928e-11 | 2/2 | ✅ |
| box_plane | npu | 1.482e-05 | 5.928e-11 | 2/2 | ✅ |
| box_plane | npu | 1.482e-05 | 5.928e-11 | 2/2 | ✅ |
| box_box_vf | npu | 7.334e-06 | 1.559e-11 | 1/1 | ✅ |
| box_box_vf | npu | 7.334e-06 | 1.559e-11 | 1/1 | ✅ |
| box_box_vf | npu | 7.334e-06 | 1.559e-11 | 1/1 | ✅ |
| box_box_ee | npu | 1.282e-06 | 5.127e-12 | 1/1 | ✅ |
| box_box_ee | npu | 1.282e-06 | 5.127e-12 | 1/1 | ✅ |
| box_box_ee | npu | 1.282e-06 | 5.127e-12 | 1/1 | ✅ |
| box_box_ee_deep | npu | 9.750e-06 | 2.287e-11 | 1/1 | ✅ |
| box_box_ee_deep | npu | 9.750e-06 | 2.287e-11 | 1/1 | ✅ |
| box_box_ee_deep | npu | 9.750e-06 | 2.287e-11 | 1/1 | ✅ |
| plane_sphere | npu | 2.980e-05 | 1.192e-10 | 1/1 | ✅ |
| plane_sphere | npu | 2.980e-05 | 1.192e-10 | 1/1 | ✅ |
| plane_sphere | npu | 2.980e-05 | 1.192e-10 | 1/1 | ✅ |
| plane_ellipsoid | npu | 1.187e-07 | 4.750e-13 | 1/1 | ✅ |
| plane_ellipsoid | npu | 1.187e-07 | 4.750e-13 | 1/1 | ✅ |
| plane_ellipsoid | npu | 1.187e-07 | 4.750e-13 | 1/1 | ✅ |
| plane_capsule | npu | 3.665e-05 | 5.743e-11 | 2/2 | ✅ |
| plane_capsule | npu | 3.665e-05 | 5.743e-11 | 2/2 | ✅ |
| plane_capsule | npu | 3.665e-05 | 5.743e-11 | 2/2 | ✅ |
| convex_convex | npu | 9.437e-07 | 3.775e-12 | 1/1 | ✅ |
| convex_convex | npu | 9.437e-07 | 3.775e-12 | 1/1 | ✅ |
| convex_convex | npu | 9.437e-07 | 3.775e-12 | 1/1 | ✅ |
| capsule_capsule | npu | 5.796e-04 | 1.844e-09 | 1/1 | ✅ |
| capsule_capsule | npu | 5.796e-04 | 1.844e-09 | 1/1 | ✅ |
| capsule_capsule | npu | 5.796e-04 | 1.844e-09 | 1/1 | ✅ |
| sphere_sphere_overlap | npu | 7.451e-06 | 2.980e-11 | 1/1 | ✅ |
| sphere_sphere_overlap | npu | 7.451e-06 | 2.980e-11 | 1/1 | ✅ |
| sphere_sphere_overlap | npu | 7.451e-06 | 2.980e-11 | 1/1 | ✅ |
| sphere_plane_grazing | npu | 6.202e-09 | 2.481e-14 | 1/1 | ✅ |
| sphere_plane_grazing | npu | 6.202e-09 | 2.481e-14 | 1/1 | ✅ |
| sphere_plane_grazing | npu | 6.202e-09 | 2.481e-14 | 1/1 | ✅ |
| capsule_capsule_parallel | npu | 5.731e-07 | 2.292e-12 | 2/2 | ✅ |
| capsule_capsule_parallel | npu | 5.731e-07 | 2.292e-12 | 2/2 | ✅ |
| capsule_capsule_parallel | npu | 5.731e-07 | 2.292e-12 | 2/2 | ✅ |
| box_plane_flush | npu | 0.000e+00 | 0.000e+00 | 4/4 | ✅ |
| box_plane_flush | npu | 0.000e+00 | 0.000e+00 | 4/4 | ✅ |
| box_plane_flush | npu | 0.000e+00 | 0.000e+00 | 4/4 | ✅ |
