# NPU 机器 —— 分步操作清单（照抄命令即可）

> 这是纯操作版，每步给命令 + 怎么判断通过。背后的原理/为什么这么设计/踩坑详解看
> `部署到NPU机器-操作方案.md`；评测的判定标准/双维度门槛看上级目录
> `NPU碰撞检测评测方案-汇总.md`；这次评测建立在哪些假设上看 `../phase0_scope.md`。
> 前置：`npu_eval_package.tar.gz` 已经传到这台机器上。

---

## Step 0 · 解压

```bash
tar xzf npu_eval_package.tar.gz
cd npu_collision_eval
```

**通过标准**：能看到 `npu_eval/` `scripts/` `tests/` `config/` `golden/` 等目录。

---

## Step 1 · 建环境、装依赖

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

**通过标准**：`pip install` 无报错，装上的是 `mujoco==3.11.0`（版本必须跟这个一致，golden 是跟它绑定的）。

> 如果这台机器没有外网（内网机器常见情况），改成先在有网的机器上 `pip download --no-deps -d wheels mujoco==3.11.0 numpy pyyaml pytest`（要跟目标机器**同操作系统 + 同 Python 版本**），把 `wheels/` 目录一起传过来，这里改成 `pip install --no-index --find-links=wheels -r requirements.txt`。

---

## Step 2 · 跑现有回归，确认 harness 本身没问题（跟你的 NPU 完全无关的一步）

```bash
python3 -m pytest -q
```

**通过标准**：`73 passed`。**这一步失败说明是环境问题（Python/依赖版本），不是你的 NPU 问题**，先在这一步排查干净，不要带着这个问题往后走。

---

## Step 3 · 在本机重新生成 golden（cpu_fp64 参考）

```bash
python3 scripts/gen_golden.py --nstep 30
```

**通过标准**：打印 `golden -> .../golden (63 cases)`。

> `golden/manifest.json` 里的 sha256 会跟原机器不一样，这是正常的——golden 内容应该等价，checksum 只是用来防"同一台机器上后续被悄悄改动"，不是用来跨机器比对的。

---

## Step 4（可选）· 如果这台机器也有 CUDA GPU，装 MJWarp 参考泳道

```bash
pip install mujoco-warp==<与 mujoco 3.11 对应版本> warp-lang
python3 -c "import warp as wp; print(wp.get_cuda_device_count())"   # 应 > 0
```

**通过标准**：能 import 成功且 GPU 数 > 0。这条不是必须的，跳过也不影响主线，跳过就在后面命令里把 `mjwarp` 从 `--lanes` 里去掉。

---

## Step 5（可选）· 如果有 cmake + 构建工具链，编译真实 fp32 版做阈值标定

```bash
git clone --branch <与 3.11 对应 tag> https://github.com/google-deepmind/mujoco /tmp/mujoco-fp32
cd /tmp/mujoco-fp32 && cmake -B build -DmjUSESINGLE=ON && cmake --build build -j
# 另开一个 venv 装对应 python 绑定，验证：
python3 -c "import mujoco,numpy; print(mujoco.MjModel.from_xml_string('<mujoco/>').qpos0.dtype)"  # 应 float32
```

回到 `npu_collision_eval` 目录（在这个 fp32 venv 里）：

```bash
python3 scripts/gen_golden.py --nstep 30    # 产出 golden/fp32_band.json
```

把 `fp32_band.json` 里每项 p95 × 1.5，手动回填到 `config/thresholds.yaml` 对应字段（覆盖里面的占位值）。这条也不是必须的，跳过就继续用占位阈值。

---

## Step 6 · 唯一必须改代码的地方：`npu_eval/npu_backend.py`

打开这个文件，文件顶部有完整数据契约。只填两个函数（`npu_close` 可留空）：

```python
def npu_open(static: dict):
    # 把 static（geom 类型/尺寸/mesh/opt 等）加载到 NPU，返回句柄
    ...

def npu_collide(handle, geom_xpos, geom_xmat) -> np.ndarray:
    # 每帧：给 [ngeom,3] 位置 + [ngeom,9] 旋转矩阵，返回 [K,21] 接触数组
    ...
```

**6 条硬性要求（照着核对，最容易踩坑）**：

1. 返回 `shape=[K,21]`，`dtype=float64`，`K` 可以是 0
2. 列布局固定：`[0]=dist`、`[1:4]=pos`、`[4:13]=frame`（前 3 个是法向）、`[13]=dim`、`[14:16]=geom`、`[16:21]=friction`
3. **`geom` 列必须 `g1 < g2`**
4. **法向必须单位向量，方向 geom1→geom2**
5. **同一输入必须给同一输出**（不确定就先测 Step 10 的确定性）
6. 顺序无所谓，不用自己排序

三种接入方式（Python 绑定 / ctypes 动态库 / 子进程）的模板代码就写在这两个函数体的注释里，选一种删掉不用的。

**这一步没有"通过标准"，改完往下走。**

---

## Step 7 · 先用内置 `selfcheck` 后端验证胶水层（不涉及真硬件，最快排查环境问题）

```bash
NPU_EVAL_ENABLE=1 NPU_BACKEND=selfcheck python3 scripts/npu_smoke.py
```

**通过标准**：打印的接触数组 sanity 检查全过、几步内无 NaN、跟 CPU `mj_collision` 的漏检/虚检/最大几何误差都接近 0（因为 `selfcheck` 内部就是拿 CPU `mj_collision` 冒充"NPU"）。

**这一步过不了 = harness 或环境本身有问题，不是你的 NPU kernel 问题**，先在这一步排查干净再往下走。

---

## Step 8 · 填完真实 `npu_open`/`npu_collide` 后，先冒烟（单模型几步）

```bash
NPU_EVAL_ENABLE=1 python3 scripts/npu_smoke.py --case box_stack3 --steps 5
```

**通过标准**：不崩、无 NaN、打印的接触数组 shape 对（`[K,21]`）。

**常见第一轮报错**：
- `shape=[K,?] 期望 [K,21]` → 列数不对，多半是 `friction` 只填了 3 个没 pad 到 5
- 漏检/虚检率非 0 → 先看是不是 `geom` 列 `g1<g2` 没做，或法向方向反了
- 深度符号看着反了 → `dist` 应该是"负值=穿透"，不是"正值=穿透"

---

## Step 9 · 最小用例集验证下游敏感度接口

```bash
NPU_EVAL_ENABLE=1 python3 scripts/run_eval.py \
    --lanes cpu_fp64 npu --modes hybrid \
    --cases gjk_sphere_sphere_dist box_plane sphere_sphere_overlap \
    --nstep 1
```

**通过标准**：`report/report.md` 能正常生成，不看数字好不好看，先看能不能跑完不报错。

---

## Step 10 · 全量 63 个用例，两种模式，多个随机种子

```bash
NPU_EVAL_ENABLE=1 python3 scripts/run_eval.py \
    --lanes cpu_fp64 npu --modes free hybrid \
    --nstep 40 --seeds 0 1 2 3 4 --jitter 1e-3
```

（如果 Step 4 装了 mjwarp，把 `--lanes` 改成 `cpu_fp64 mjwarp npu`，多一条参照带）

**通过标准/怎么读结果**（对照 `NPU碰撞检测评测方案-汇总.md` §3）：

- `report/report.md` 顶部总判定；`missed_rate`/`normal_flip_rate` 必须是 0（硬门禁）
- `dist/pos/normal` 的 p95 是否在阈值内（占位阈值，若做了 Step 5 已回填真实值）
- `hybrid` 的 `qacc_linf` 是否被明显放大
- **即使全 PASS 也不代表"没问题"，即使 fp32 级噪声在多步 rollout 里 pass_rate 掉到 0.95 左右也是正常现象**（接触系统天然混沌敏感），不要因为不是 100% 就怀疑接线错了——先看是所有场景都跌还是个别场景跌（个别跌更像混沌放大，全跌更像系统性 bug）
- `broadphase_filter` 这个用例默认不在 63 个里被自动选中（tier 是 `structural`），如果想单独验证宽相位候选对，用：
  ```bash
  NPU_EVAL_ENABLE=1 python3 scripts/run_eval.py \
      --lanes cpu_fp64 npu --modes free \
      --cases broadphase_filter --nstep 1
  ```
  只看 `report.md` 里这个 case 的 **S3** 那一行（漏检率/`ncon`），S4 往后的数字对这个模型无意义（原因见 `npu_eval/fixtures.py` 里 `broadphase_filter` 上面的注释）。

---

## Step 11 · 确定性检查

```bash
NPU_EVAL_ENABLE=1 python3 scripts/npu_determinism.py --repeats 1000
```

**通过标准**：bit 一致。如果因为异步归约不一致，脚本会报出抖动上界——把这个数字记下来，回填进 `config/thresholds.yaml` 对应字段（不能假装它是确定性的，直接忽略）。

---

## Step 12 · 打包结果带回来

```bash
tar czf npu_result_$(date +%Y%m%d).tar.gz report/ golden/manifest.json config/thresholds.yaml
```

带回来的这三样，配合 `NPU碰撞检测评测方案-汇总.md` §2（如果装了 mjwarp，顺手出一份 `|npu-mjwarp|` 分解表），就是第一版可以拿出去讨论的真实数据。

---

## 一页纸流程图

```
Step0 解压 → Step1 装依赖 → Step2 pytest回归(跟NPU无关) → Step3 生成golden
   → Step4(可选)装mjwarp → Step5(可选)编fp32标阈值
   → Step6 填 npu_backend.py 两个函数
   → Step7 selfcheck验证胶水层(不用等真硬件)
   → Step8 单模型冒烟 → Step9 最小用例集验证接口
   → Step10 全量63用例出数据 → Step11 确定性
   → Step12 打包带回来
```

任一步失败：Step0-3 是环境问题；Step6-9 是接口/schema 问题；Step10-11 数字异常先查 `部署到NPU机器-操作方案.md` §5 的三个常见坑。
