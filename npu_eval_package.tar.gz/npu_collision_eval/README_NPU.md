# 在内网机器上接 NPU 并跑评测

整个包拷到内网机器即可。**你要动的只有一个文件**：`npu_eval/npu_backend.py` 里的三个函数。
其余（阶段分解、四泳道、无序匹配、门禁、报告）都已接好。

---

## 0. 装依赖（离线）

从有网的机器先下好 wheel：

```bash
pip download -d wheels mujoco==3.11.0 numpy pyyaml pytest
# 可选：mujoco-warp 及其依赖（内网有 NVIDIA GPU 才需要）
```

内网机器：

```bash
pip install --no-index --find-links wheels mujoco==3.11.0 numpy pyyaml pytest
python -m pytest -q          # 应 27 passed，证明包本身没问题
```

---

## 1. 先用自检后端验证胶水（不接 kernel）

```bash
NPU_EVAL_ENABLE=1 NPU_BACKEND=selfcheck python scripts/npu_smoke.py --case box_stack3
NPU_EVAL_ENABLE=1 NPU_BACKEND=selfcheck python scripts/run_eval.py \
    --lanes cpu_fp64 npu --modes free hybrid --nstep 15 --seeds 0
```

自检后端用 CPU `mj_collision` 从传入的世界位姿算接触，走完整的
`build_static → npu_open → npu_collide → 注入 → 下游` 链路。**结果应全 PASS、误差全 0**。
不为 0 说明胶水层有问题（先解决，别往下走）。

---

## 2. 接你的 NPU（编辑 `npu_eval/npu_backend.py`）

只实现两个函数（`npu_close` 可留空）：

```python
def npu_open(static: dict):
    # static 里有几何类型/尺寸/margin/solref/solimp/friction、mesh 顶点面、opt 开关
    # 见文件顶部 Schema。把它加载到 NPU，返回一个句柄。
    ...

def npu_collide(handle, geom_xpos, geom_xmat) -> np.ndarray:
    # 每帧：ngeom 个几何的世界位姿（xpos [ngeom,3]，xmat [ngeom,9] 行主序）
    # 返回接触数组 [K,21]：
    #   [0] dist(带符号，负=穿透) [1:4] pos [4:13] frame(前3是法向,geom1→geom2单位向量)
    #   [13] dim(1/3/4/6) [14:16] geom([g1,g2],g1<g2) [16:21] friction(前3有效)
    ...
```

文件里有三种接法的模板（Python 绑定 / ctypes 动态库 / 子进程服务），按你的 NPU 栈选一种。

**主机侧不用你管**：运动学（算世界位姿）、下游阶段（约束/求解/积分）、无序匹配、门禁、报告，
harness 都做了。你只负责"给位姿 → 还接触"。

---

## 3. 逐步验证

```bash
# 3.1 隔离测适配层：接口通不通、sanity、和 CPU 的漏检/虚检/几何误差
NPU_EVAL_ENABLE=1 python scripts/npu_smoke.py --case box_plane --steps 5
NPU_EVAL_ENABLE=1 python scripts/npu_smoke.py --case box_stack3 --steps 5
NPU_EVAL_ENABLE=1 python scripts/npu_smoke.py --case convex_convex --steps 5

# 3.2 确定性（Step 5）：同输入重复跑，看是否逐位一致
NPU_EVAL_ENABLE=1 python scripts/npu_determinism.py --repeats 1000
#   不逐位一致 → 脚本给出 FP 抖动上界，回填 config/thresholds.yaml 的 S3 容差

# 3.3 全套评测
NPU_EVAL_ENABLE=1 python scripts/run_eval.py \
    --lanes cpu_fp64 npu --modes free hybrid --nstep 40 --seeds 0 1 2 --jitter 1e-3
#   有 NVIDIA GPU + mujoco-warp：--lanes cpu_fp64 mjwarp npu
#   有 fp32 构建的 mujoco（单独 venv）：先在那个 venv 跑 gen_golden.py 出 fp32_band.json，
#   把 p95 回填 config/thresholds.yaml，再把 cpu_fp32 加进 --lanes
```

产出：`report/report.md`（逐阶段误差表 + S3 分族 + hybrid 下游）、`report/results.csv`、
`report/summary.json`。`run_eval.py` 退出码：全 PASS = 0，有 FAIL = 1（可直接接 CI）。

---

## 4. 环境变量一览

| 变量 | 值 | 作用 |
|---|---|---|
| `NPU_EVAL_ENABLE` | `1` | 打开 npu 真泳道（不设 → 用 mock 代理） |
| `NPU_BACKEND` | `real`（默认）/ `selfcheck` | `selfcheck` = 用 CPU 走一遍 schema 链路，验证胶水 |
| `NPU_MOCK_PROFILE` | `fp32` / `fp32+jit` / `none` | 仅 mock 泳道用（未接 NPU 时的代理，见 report/首批数据-说明.md） |

---

## 5. 已知限制

- `run_full`（free 模式）：NPU 若在某帧产出的接触数与 CPU 不同，多出来的接触其
  `solref/solimp` 等参数是从"同 geom 对的 CPU 接触"复制的（近似）。接触数一致时精确。
  报告里 `ncon_equal` / `nefc` 会标出不一致的帧。
- 主机侧运动学用 `mj_kinematics + mj_comPos`，不含肌腱/传动 —— 当前用例都没有，若模型有需补。
- `cpu_fp32` 泳道需要单独的 float 构建 mujoco；官方 PyPI wheel 是 double。
