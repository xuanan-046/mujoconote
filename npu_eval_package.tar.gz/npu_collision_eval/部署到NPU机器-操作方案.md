# 部署到 NPU 机器 —— 操作方案

> 目的：把 `npu_collision_eval/` 整套 harness 搬到一台**真的能跑 NPU** 的机器上，接入真实碰撞检测 kernel，跑出第一版**真实**评测数据。
> 前提：本机（开发机）已经跑通 mock 版全流程（`pytest` 27 passed），且发现并修复了一个真实 bug（见下方"出发前先知道"）。
> 对应 `phase0_scope.md` 的 Track C（`NEXT_STEPS.md` C1/C2）。

---

## 0. 出发前先知道：这次连带修了一个 bug

`MockNpuHandle`（`npu_eval/lanes.py`）原来继承 `MujocoHandle`，`run_full` 只在事后把 S3 快照的 `contact` 字段覆盖成扰动值展示，**从未把扰动真正喂回去重跑 S4~S10**——导致 `free` 模式下游阶段恒为 0，制造"下游没问题"的假象。`hybrid` 模式不受影响（它是在 `runner.py` 里独立注入的）。

**已修复**：现在 `MockNpuHandle` 改为继承 `NpuHandle`，只重写 `_npu_contacts()`（用 CPU 参考碰撞 + mock 扰动生成"NPU 结果"），`run_full`/`collision_only` 都复用 `NpuHandle` 原本就有的、真实的 `_inject_and_step` 注入/传播逻辑。修复后 `pytest` 仍 27 passed，但 mock 数据的 pass_rate 从 1.000/0.985 变成了 0.950/0.505（30 步 rollout 里扰动会真的累积/放大）——**这不是变差了，是之前的数字是假的，现在的才是这套 harness 该有的行为**。

**这件事的意义**：说明 `NpuHandle`（真实 NPU 走的那条代码路径）本身设计是对的，之前只是 mock 的简化实现掩盖了问题。到了这台新机器，你填 `npu_backend.py` 之后走的就是 `NpuHandle` 这条真实路径，不会有这个 bug。

---

## 1. 打包清单：具体拷贝什么

只需要整个 `npu_collision_eval/` 目录，自包含、无硬编码路径（已检查过），结构：

```
npu_collision_eval/
├── requirements.txt
├── README.md / README_NPU.md / NEXT_STEPS.md
├── config/thresholds.yaml
├── npu_eval/                  # 核心代码，唯一要改的是 npu_backend.py
├── scripts/                   # gen_golden.py / run_eval.py / npu_smoke.py / npu_determinism.py
├── tests/                     # pytest 回归
├── golden/                    # cpu_fp64 参考快照 + sha256（可重新生成，带过去省一步）
└── fixtures.py 等
```

建议一并带上（放同一个上级目录，供查阅，不参与运行）：

- `../phase0_scope.md` —— 这次评测建立在哪些假设上（native CCD、multiccd 默认开、offload 整个 `mj_collision()` 等），新机器上跑出异常时第一时间对照
- `../npu_collision_eval_plan.md` + `../npu_collision_eval_tables_A_B.md` —— 完整方案和用例池设计依据
- `../NPU碰撞检测评测方案-汇总.md` —— 五泳道分工、双维度门槛的方法论总纲

打包命令（在本机执行，`xzf` 一份传过去）：

```bash
cd /Users/xuzhixuan/Desktop/mujoconote/code
tar czf npu_eval_package.tar.gz \
    npu_collision_eval/ \
    phase0_scope.md npu_collision_eval_plan.md npu_collision_eval_tables_A_B.md \
    NPU碰撞检测评测方案-汇总.md
# scp / rsync 到新机器后：
tar xzf npu_eval_package.tar.gz
```

---

## 2. 新机器环境搭建

```bash
cd npu_collision_eval
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # mujoco==3.11.0 pin 死，golden 与之绑定，不要改版本
python3 -m pytest -q                      # 应 27 passed —— 先确认 harness 本身没问题，跟你的 NPU 无关
python3 scripts/gen_golden.py --nstep 40  # 重新生成本机 golden（sha256 会变，属正常，golden 内容应等价）
```

如果这台机器同时也有 CUDA GPU（可选，不阻塞主线）：

```bash
pip install mujoco-warp==<与 mujoco 3.11 对应版本> warp-lang
python -c "import warp as wp; print(wp.get_cuda_device_count())"   # 应 > 0
```

如果这台机器有 cmake + 完整构建工具链（可选，用来把 `cpu_fp32` 阈值标定坐实，本机做不了这步）：

```bash
git clone --branch <与 3.11 对应 tag> https://github.com/google-deepmind/mujoco /tmp/mujoco-fp32
cd /tmp/mujoco-fp32 && cmake -B build -DmjUSESINGLE=ON && cmake --build build -j
# 装对应 python 绑定，另开一个 venv
python -c "import mujoco,numpy; print(mujoco.MjModel.from_xml_string('<mujoco/>').qpos0.dtype)"  # 应 float32
python scripts/gen_golden.py --nstep 40   # 在 fp32 venv 里跑，产出 golden/fp32_band.json
# 把 fp32_band.json 每项 p95 × 1.5 回填 config/thresholds.yaml
```

---

## 3. 唯一要改的文件：`npu_eval/npu_backend.py`

文件顶部已经写清楚了完整的数据契约（Schema），这里只提炼成清单，照着填三个函数中的两个（`npu_close` 可选）：

| 函数 | 干什么 | 何时调 |
|---|---|---|
| `npu_open(static: dict) -> handle` | 一次性把几何/mesh/opt 数据加载到 NPU，返回句柄 | 每个模型 load 一次 |
| `npu_collide(handle, geom_xpos, geom_xmat) -> [K,21]` | 每帧：给世界位姿，返回接触数组 | 每步调一次（hybrid 模式每 case 调一次） |
| `npu_close(handle)` | 释放资源，没有可留空 | 结束时 |

**返回值的 6 条硬性要求**（文件顶部已写，这里再强调一遍，容易踩坑）：

1. `shape = [K, 21]`，`dtype = float64`，`K` 可以是 0
2. 列布局固定：`[0]=dist`（`margin+带符号距离`，负=穿透）、`[1:4]=pos`、`[4:13]=frame`（前 3 个是法向，geom1→geom2）、`[13]=dim`、`[14:16]=geom`（`g1<g2`）、`[16:21]=friction`
3. **`geom` 列必须是 `g1 < g2`**——排序错了会导致 `matching.py` 的无序匹配器把明明匹配上的接触判成漏检/虚检
4. **同一输入必须给同一输出**——异步归约如果导致不确定，必须先测出抖动上界（见 §5.3），不能悄悄放过去
5. `frame` 的法向必须单位向量、方向是 geom1→geom2（不是任意方向），符号反了会被判成"法向翻转"硬门禁 FAIL
6. 顺序无所谓（harness 用无序匹配），不需要自己排序，但如果 NPU 本身能保证确定性顺序，`npu_backend.canonical_sort` 已经帮你在主机侧统一规范化了

三种接入方式的代码模板已经写在 `npu_backend.py` 的 `npu_open`/`npu_collide` 函数体注释里（Python 绑定 / ctypes 动态库 / 子进程），选一种删掉不用的。

---

## 4. 接入验证顺序 —— 不要一上来就跑全量，分四步

### Step A：先用 `selfcheck` 后端验证 Python 胶水层（不涉及真硬件）

`npu_backend.py` 内置了一个 `_SelfCheckHandle`，用 CPU 的 `mj_collision` 冒充"NPU"，走完整的 `build_static → npu_open → npu_collide → 规范排序 → 注入 → 跑 S4~S10` 链路：

```bash
NPU_EVAL_ENABLE=1 NPU_BACKEND=selfcheck python scripts/run_eval.py \
    --lanes cpu_fp64 npu --modes hybrid --cases box_plane plane_sphere --nstep 1
```

**目的**：在真 kernel 还没写之前，先确认 harness 这边的 schema/接线（数据怎么传进传出、注入逻辑、快照对照）没有 bug。结果应该 ≈ fp64（微小差异来自运动学重算/排序，不是精度问题）。**这一步过不了，说明是 harness 或环境问题，不是你的 NPU kernel 问题**，先在这一步排查干净。

### Step B：填真实 `npu_open`/`npu_collide`，先跑最小用例集验证接口通不通

```bash
NPU_EVAL_ENABLE=1 python scripts/run_eval.py \
    --lanes cpu_fp64 npu --modes hybrid --cases box_plane sphere_sphere_overlap --nstep 1
```

- 先看能不能跑通（shape 对不对、有没有抛异常），不追求数字好看。
- 常见第一轮报错：`shape=[K,?] 期望 [K,21]`（列数不对，检查 friction 是不是只填了 3 个没 pad 到 5）、法向翻转率非 0（geom1/geom2 顺序或法向方向反了）、`ncon` 对不上但深度基本对（检查 `geom` 列 g1<g2 有没有做）。

### Step C：扩到全部 16 个用例 + 两种模式

```bash
NPU_EVAL_ENABLE=1 python scripts/run_eval.py \
    --lanes cpu_fp64 npu --modes free hybrid --nstep 40 --seeds 0 1 2 3 4 --jitter 1e-3
```

看什么（对照 `NPU碰撞检测评测方案-汇总.md` §3 的双维度门槛）：

- **正确性**：`report/report.md` 里 `missed_rate`/`normal_flip_rate` 是否为 0（硬门禁）；`dist/pos/normal` 的 p95 是否在阈值内（占位阈值，等标定后回填）；`hybrid` 的 `qacc_linf` 是否被放大。
- **不要忽略 free 模式的多步发散**——修 bug 后我们发现即使 profile A（纯 fp32）级别的噪声，在 30 步多体 rollout 里也会让 pass_rate 跌到 0.95，这是接触系统天然的混沌敏感性（不是 bug），真 NPU 也大概率会看到类似现象，属正常，不要一看到 free 模式不是 100% 就怀疑接线错了——先看是不是所有场景都跌，还是只有个别场景跌（个别场景跌更像混沌放大；全跌更像系统性 bug）。

### Step D：确定性 + 性能（如果 Step C 数字大致合理再做）

```bash
python scripts/npu_determinism.py   # NPU 同输入重复跑, 比 contact 是否 bit 一致
python scripts/npu_smoke.py         # 200 步冒烟, 不崩/无 NaN/ncon>0
```

性能：目前 `thresholds.yaml` 的 `perf.*` 字段没有接入判定逻辑（`NEXT_STEPS.md` D3 待办），先用 `d.timer[mjTIMER_POS_COLLISION/COL_BROAD/COL_NARROW]` 手工读数据，正式的加速比 gate 后续再补。

---

## 5. 三个容易踩的坑（针对这台新机器，提前说明）

### 5.1 golden 的 sha256 会变，这是正常的

`golden/manifest.json` 里的 checksum 是跟具体 mujoco 版本/机器绑的，新机器上重新 `gen_golden.py` 会产生不同 sha256——**不代表数据错了**，是 `E0 环境校验` 要求"golden 未漂移"这条针对的是"同一台机器上的两次跑之间"，不是跨机器比较。跨机器只需要保证 mujoco 版本号一致（`requirements.txt` 里 pin 的 `3.11.0`）。

### 5.2 `phase0_scope.md` 里的假设要在这台机器上重新对一遍

尤其两条：
- **native CCD + multiccd 默认开启**——如果你的 NPU 实现对标的其实是 libccd/MPR，或者 multiccd 关了，第一批数据会出现大量"接触点数对不上但深度差不多"的现象，容易误判成精度问题，实际是配置口径不一致。
- **offload 整个 `mj_collision()`**——如果实际只 offload 了部分（比如只做窄相位，宽相位还是 CPU 过滤好候选对再传给 NPU），`build_static` 里的 `filterparent`/`pair_geom`/`exclude_signature` 这些宽相位相关字段可能就不需要传给 NPU，`npu_open` 可以简化；反过来如果全段都在 NPU，这些字段必须真的用起来，不能忽略。

### 5.3 异步接口的话，Step D 的确定性检查必须过

如果 NPU 侧接口实际是异步的（不是"host 调用、阻塞等待返回"），`npu_collide` 这个函数签名本身要求同步返回，你可能需要在 `npu_open`/`npu_collide` 内部自己做同步等待（比如轮询/回调转同步）。这种情况下 `npu_determinism.py` 这一步**不能跳过**——如果同输入重复跑结果不 bit 一致，必须测出 FP 抖动上界，手动写进 `config/thresholds.yaml`，不能假装它是确定性的。

---

## 6. 交付物 —— 这台机器最终应该产出什么

```
report/npu_collision_eval_report.md   # 逐阶段误差表 + 失败明细 + summary.json
report/results.csv                    # 全部原始字段（~70 列），供后续画图/分桶分析
golden/                               # 本机 cpu_fp64 参考 + sha256（下次回归对比用）
```

把这三样带回来，配合 `NPU碰撞检测评测方案-汇总.md` §2 的分解方法（如果这台机器同时装了 `mujoco-warp`，顺手把 `|npu-mjwarp|` 那张对照表也出一份），就是第一版可以拿出去讨论的真实数据。

---

## 7. 一句话流程图

```
拷贝 npu_collision_eval/ → pip install + pytest(mock回归) → gen_golden.py
   → 填 npu_backend.py 两个函数
   → Step A selfcheck 验证胶水层
   → Step B 最小用例集验证接口
   → Step C 全量 free+hybrid 出数据
   → Step D 确定性+冒烟
   → 出 report/ 三件套带回来
```
