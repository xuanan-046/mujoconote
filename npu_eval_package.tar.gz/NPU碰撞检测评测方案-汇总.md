# NPU 碰撞检测优化评测方案 —— 汇总

> 本文整合近期讨论对方案的**修正与补充**，是入口文档。
> 底层细节分别在：`npu_collision_eval_plan.md`(完整 Phase 0–6 + §E 流程)、`npu_collision_eval_tables_A_B.md`(碰撞函数矩阵/官方用例池)、`评测流程PPT/评测流程-按步骤.md`(按步骤讲稿)、`mujoco官方测试-场景与复用详解.md`(官方场景怎么复用)、`npu_collision_eval/`(已实现的 Python harness)。
> 本文只讲**方案骨架和这次修正的三处关键点**，不重复细节。

---

## 0. 一句话定性：这是什么类型的优化，决定了整套评测怎么设计

把碰撞检测 offload 到 NPU，属于 **A 类优化 —— 不改变被求解的物理方程，只改变"算力落在哪、怎么算"**。

这个定性直接决定评测目标**不是**"证明 NPU 算得更准"（不可能，`cpu_fp64` 就是真值，NPU 用 fp32/bf16 只会更不准），而是回答两个独立问题：

1. **正确性/一致性**：有没有把物理结果悄悄搞坏？—— 目标是**不劣化**，不是"更好"。
2. **性能**：是不是真的更快、划不划算？—— 这才是"更好"能成立的唯一维度。

两个维度都要过，"划算"这个结论才成立；只测一个都不完整（`optimization_vs_baseline_case_studies.md` 点名的通病：Isaac Sim 官方 benchmark 只测性能不测精度、Genesis 只报速度不披露精度代价）。

---

## 1. 参照体系：五条"泳道"，分工不同，不是三方/多方投票

第一处修正：**四/五条泳道不是对称地互相比较，各自角色不同**。

| 泳道 | 角色 | 干什么用 | 是否已实现 |
|---|---|---|---|
| `cpu_fp64` | **唯一真值** | 所有误差都相对它算：`误差 = |X − fp64|` | ✅ |
| `cpu_fp32` | **误差标尺**（不是"第二参照物"） | 回答"纯精度损失、不含任何移植/算法改动，本身就带来多大误差" → 这个值 ×1.5 就是所有 p95 类阈值的来源 | 待建（`NEXT_STEPS.md` A2） |
| `mjwarp`（本体，GPU） | **参照带 + 继承偏差基线** | ①"NPU 偏差 ≤ mjwarp 偏差带"= 达到成熟 GPU 移植水平；②见 §4，拆解"继承自 MJWarp 的偏差" | 待建（`NEXT_STEPS.md` A1） |
| `npu`（修改版） | **被测对象** | 唯一真正要判定 PASS/FAIL 的对象 | 骨架已实现，mock 泳道跑通，待接真硬件（`NEXT_STEPS.md` C1） |
| `npu_naive`（可选，新增） | **未优化的 NPU 移植基线** | 把 MJWarp 碰撞 kernel 原样搬到 NPU、不做任何算法级优化 → 用来把"移植"和"优化"这两件事拆开（见 §4 情形 B） | 未实现，按需补 |

**判定逻辑只有一条主线**：`NPU vs cpu_fp64`。`cpu_fp32 vs cpu_fp64` 是拿来**定阈值**的，不参与"投票"。

- NPU 偏差 ≤ fp32 偏差带 → 只是精度损失级别，可接受
- NPU 偏差 > fp32 偏差带 → 移植/重排引入了额外误差，要解释
- NPU 偏差 ≤ mjwarp 偏差带 → 达到成熟 GPU 移植水平

---

## 2. 新增一层：MJWarp 本体 vs 修改版 横向对照（拆解偏差来源）

第二处修正/补充：单独一条 `NPU vs fp64` 拆不开"偏差是继承来的还是新引入的"，因为 **MJWarp 本身相对 `fp64` 就已经有已知偏差**（`mesh_optimization_evaluation_survey.md` 提过：MJX/MJWarp 在特定 `solimp`/`solref` 组合、尤其 box-box 碰撞上跟原生 MuJoCo 结果不同）。

即：`|NPU − fp64|` 的偏差 = **(MJWarp 本身固有的偏差)** + **(NPU 移植/优化新引入的偏差)**，混在一起看不出来是哪部分。

### 2.1 两种情形，取决于"修改版"具体指什么

**情形 A：修改版 = MJWarp 碰撞算法移植到 NPU（硬件变了，算法结构基本没变）**

对应 `optimization_vs_baseline_case_studies.md` §二.2 的 ComFree-Sim 正面范式：固定算法结构，只换后端硬件，确保差异能归因到"移植"本身。

```
mjwarp(GPU, 本体)  ──┐
                      ├─► 直接对照(不经过 fp64) ──► "移植引入了多少额外偏差 / 加速比"
修改版(NPU)          ──┘
```

**情形 B：修改版 = 在 NPU 上对 MJWarp 实现做了进一步算法级优化（硬件都是 NPU，改的是算法/kernel）**

再拆一层泳道，把"移植"和"优化"彻底分开：

```
npu_naive     = MJWarp 碰撞 kernel 原样搬到 NPU（不做算法改动，只求能跑通）
npu_optimized = 实际做了优化的版本("修改版")
```

`npu_optimized vs npu_naive` 隔离出**硬件相同、只有优化手法不同**的效果——这是本次调研里几乎所有论文的通病（Isaac Gym、ComFree-Sim、Barrier-Augmented Lagrangian 全都没拆开"并行化贡献多少、算法改进贡献多少"），补上就是加分项。

### 2.2 报告里加一张分解表

| case | \|npu−fp64\| | \|mjwarp−fp64\| | \|npu−mjwarp\| | 解读 |
|---|---|---|---|---|
| xxx | 3e-3 | 2.8e-3 | 3e-4 | 大部分偏差继承自 MJWarp，NPU 改动本身干净 |
| yyy | 5e-2 | 2.8e-3 | 4.9e-2 | 偏差主要是 NPU 改动新引入的，重点排查这个 case |

### 2.3 两个坑

1. **硬件对等性必须标注**：情形 A 里"本体"跑 GPU、"修改版"跑 NPU，这个对照的**加速比没有意义**（跨硬件），只能拿来比数值偏差；真要比性能，要么两边都在 NPU 上跑（情形 B），要么明确注明是"跨硬件历史对比"不是"受控对比"。
2. **版本要 pin 死**："MJWarp 本体"具体是哪个 commit/release，要记进 `golden/manifest.csv` 同一套校验码体系，否则"本体"是个移动靶，对照失去意义（参照 `npu_collision_eval_plan.md` 里 `~/mujoco @ f9a00bd` 的 pin 处理方式）。

---

## 3. 两个评测维度与 PASS 门槛

第三处强调：**一致性达标只回答"没搞坏"，回答不了"划算"——两个维度都要测，报告都要出。**

### 3.1 正确性/一致性维度（目标：不劣化）

| 检查项 | 判据 | 层级 |
|---|---|---|
| 漏检率 | `missed / (matched + missed)` | **硬门禁 = 0**（安全关键） |
| 法向翻转率 | 匹配集中法向夹角 > 90° 占比 | **硬门禁 = 0** |
| broadphase 候选对 | vs CPU 候选对的关系 | **硬门禁：不得是子集**（超集只损性能，允许） |
| 穿透深度/位置/法向夹角 p95 | 按算法族 + 穿透深度分桶 | ≤ fp32 带 ×1.5 |
| 下游 `qacc`/`qpos` 偏差 | hybrid 模式：NPU 接触喂回 `cpu_fp64` 求解器 | p95 ≤ 与 fp32 同量级 |
| 确定性 | NPU 同输入重复 1000 次 | bit 一致，或声明 FP 抖动上界并纳入阈值 |
| golden checksum | sha256 未漂移 | 环境校验 gate |

### 3.2 性能维度（目标：更好/划算）

| 检查项 | 判据 |
|---|---|
| 碰撞阶段加速比 | `timer[POS_COLLISION]_cpu / timer[POS_COLLISION]_npu` ≥ Phase 0 约定目标 |
| broad/narrow 拆分 | 分别报，定位加速来自哪一段 |
| 整步是否劣化 | `mj_step` 端到端（含 host↔NPU 传输）**不得慢于纯 CPU** |
| 扩展性 | 加速比随场景规模（geom 数/接触数）的曲线，不能单调退化 |
| 传输开销 | 上行/下行字节与耗时，算 batch breakeven |

**最终 PASS = 3.1 全部满足 且 3.2 全部满足**。只有 3.1 通过、3.2 不达标 → "没搞坏但不划算"；只有 3.2 达标、3.1 不通过 → "快但不能信"，两者都不能单独宣称"优化成功"。

---

## 4. 执行流程骨架（详见 `npu_collision_eval_plan.md` §E 与 `评测流程-按步骤.md`）

```
Step 0 准备(冻结基线,建 fp64/fp32 构建,标阈值)
  │
Step 1 环境校验 ─gate→ Step 2 冒烟 ─gate→
  │
Step 3 逐阶段对照(按 mj_step 阶段边界比 mjData：S3碰撞→S4构建约束→S6速度→S9求解→S10积分)
  │   § 3.1 位置阶段(碰撞检测=NPU改动核心；运动学/惯量/构建约束=传播观测/自检点)
  │   § 3.2 速度阶段(传播观测，不设硬门禁)
  │   § 3.3 驱动阶段(自检点，应与fp64逐位相同)
  │   § 3.4 加速度阶段(自检点)
  │   § 3.5 约束求解阶段(关键传播点，qacc 是否被污染)
  │   § 3.6 积分/推进(H步发散曲线)
  │
Step 4 下游敏感度(hybrid模式：碰撞差异是否影响仿真结果) ─gate→
Step 5 确定性(重复1000次) ─gate→
Step 6 性能(§3.2 全部指标) ─gate→
  │
Step 7 判定 + 报告(含 §2 的 mjwarp本体/修改版 分解表)
```

**任一阶段不通过 → 停**，报告写清停在哪、差多少。

---

## 5. 官方测试场景复用（总纲，详表见 `mujoco官方测试-场景与复用详解.md`）

按优化类型（这里是 A 类为主）复用原则：

- **等效性判据全家原样复用**：`SolversEquivalent`(Newton==PGS==CG)、`IslandsEquivalent`(有岛==无岛)、`SparseDenseEquivalent`(稀疏==稠密)、单线程==多线程、休眠==非休眠 —— 判据是"A==B"不依赖硬编码值，把"官方 fp64"当 A、"NPU/修改版"当 B 直接跑。
- **守恒系统直接复用**：能量守恒摆、Dzhanibekov、肌腱 armature 守恒 —— 不依赖参照实现。
- **GJK 47 个内联位形 + expected 值直接当 golden**：`engine_collision_gjk_test.cc` 抽出来是"逐算子 parity"的标准用例池。
- **退化/病态场景是精度退化必做回归池**：`EllipsoidEllipsoidSlowConvergence`、`ThinBox*`、`DegenerateInertia`、无自由度约束模型。
- **`pipeline_test.cc::SparseDenseEquivalent` 是逐阶段对照的现成骨架** —— `npu_collision_eval/` 的结构就是照它写的。
- **`test/benchmark/`（`ccd_benchmark` + `step_benchmark`）是性能载体** —— §3.2 全部指标从这里读。
- **官方判据要做的唯一改造**：把"逐位对齐硬编码值（`MjTol` 的 fp64 列）"换成"以官方 fp64 为真值的容差带对照（fp32 列或标定值 ×1.5）"；等效性和守恒/不变量判据不用改。

---

## 6. 落地到现有代码 `npu_collision_eval/` 的改动点

| 改动 | 位置 | 说明 |
|---|---|---|
| 补 `cpu_fp32` 泳道 | 单独 venv + float 构建 mujoco | 标定 §3.1 的阈值来源（`NEXT_STEPS.md` A2，最优先） |
| 补 `mjwarp` 泳道 | 内部 N 卡机器 | 拿到"参照带"（`NEXT_STEPS.md` A1） |
| **新增 `npu_naive` 泳道（可选）** | `lanes.py` | 情形 B：隔离"移植"与"优化"两件事的贡献 |
| **`report.py` 加分解列** | `report.py` | 新增 `\|npu-mjwarp\|` 列，产出 §2.2 的分解表 |
| 接真 NPU | `npu_eval/lanes.py:NpuHandle` | 唯一必填项（`NEXT_STEPS.md` C1） |
| 补 E5 不变量 / E6 确定性 / E8 完整性能基准 / E9 fuzz | `tests/` | Track D，主线跑通后补，不挡路 |

---

## 7. 现状速览

```
✅ 阶段级 harness 跑通(pytest 27 passed)，mock 泳道验证了整条流水线逻辑
✅ 首批 mock 数据已证明"S3 通过还不够，必须看 Step 4 下游敏感度"
     （0.1mm 穿透误差在刚性接触上被约束求解放大成 0.1~0.7 的 qacc 误差）
⬜ 阈值仍是占位值 —— 待 cpu_fp32 泳道标定(A2，最优先)
⬜ cpu_fp32 / mjwarp / npu 三条真实泳道待接
⬜ 本文 §2 的"mjwarp 本体 vs 修改版"分解层待补(建议随 A1 一起做)
⬜ Phase 0 五个问题待合作方书面确认(B1，可并行发起)
```

**关键路径**：`B1(邮件) + A1(接MJWarp,顺带做§2分解) + A2(fp32标阈值) → C1(接NPU) → C2(首轮全泳道报告) → D(补全)`。硬件到位前 A1+A2 可做完（~3 天）；合作方回复+NPU到位后 C1→C2 约 1 周。
