"""碰撞用例 fixture。

_FIXTURES 前若干条逐字来自 mujoco_warp/_src/collision_driver_test.py (Apache-2.0),
其余是常见解析/退化位形补充。每条是一段自包含 MJCF 字符串。

tier:
  analytic   —— 有闭式解
  primitive  —— 解析 primitive 碰撞函数
  degenerate —— GJK/EPA 易翻车位形
  scene      —— 多体场景, 走 rollout
"""
from __future__ import annotations

# ---- 来自 mujoco_warp collision_driver_test.py 的 _FIXTURES ----------------
MJWARP_FIXTURES = {
    "box_plane": ("""
        <mujoco><worldbody>
          <geom size="40 40 40" type="plane"/>
          <body pos="0 0 0.3" euler="45 0 0"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "primitive"),
    "box_box_vf": ("""
        <mujoco><worldbody>
          <body pos="0 -0.2 1.2" euler="44 46 0"><freejoint/><geom size="0.6 0.4 0.7" type="box"/></body>
          <body pos="0 0 0" euler="0 0 0"><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "box_box_ee": ("""
        <mujoco><worldbody>
          <body pos="0 0 0" euler="0 45 0"><geom size="0.5 0.5 0.5" type="box"/></body>
          <body pos="0 0 1.6" euler="44 0 90"><freejoint/><geom size="0.6 0.4 0.7" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "box_box_ee_deep": ("""
        <mujoco><worldbody>
          <body pos="0 0 0" euler="0 74 0"><geom size="0.4 0.45 0.4" type="box"/></body>
          <body pos="0 0 1.2" euler="24 0 90"><freejoint/><geom size="0.6 0.4 0.7" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "plane_sphere": ("""
        <mujoco><worldbody>
          <geom size="40 40 40" type="plane"/>
          <body pos="0 0 0.2" euler="45 0 0"><freejoint/><geom size="0.5" type="sphere"/></body>
        </worldbody></mujoco>""", "analytic"),
    "plane_ellipsoid": ("""
        <mujoco><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 .299"><geom type="ellipsoid" size=".1 .2 .3"/><freejoint/></body>
        </worldbody></mujoco>""", "primitive"),
    "plane_capsule": ("""
        <mujoco><worldbody>
          <geom size="40 40 40" type="plane"/>
          <body pos="0 0 0.0" euler="30 30 0"><freejoint/><geom size="0.05 0.05" type="capsule"/></body>
        </worldbody></mujoco>""", "primitive"),
    "convex_convex": ("""
        <mujoco><asset>
          <mesh name="poly" vertex="0.3 0 0  0 0.5 0  -0.3 0 0  0 -0.5 0  0 -1 1  0 1 1"/>
        </asset><worldbody>
          <body pos="0.0 2.0 0.35" euler="0 0 90"><freejoint/><geom size="0.2 0.2 0.2" type="mesh" mesh="poly"/></body>
          <body pos="0.0 2.0 2.281" euler="180 0 0"><freejoint/><geom size="0.2 0.2 0.2" type="mesh" mesh="poly"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "capsule_capsule": ("""
        <mujoco model="two_capsules"><worldbody>
          <body><joint type="free"/><geom fromto="0.62235904 0.58846647 0.651046 1.5330081 0.33564585 0.977849" size="0.05" type="capsule"/></body>
          <body><joint type="free"/><geom fromto="0.5505271 0.60345304 0.476661 1.3900293 0.30709633 0.932082" size="0.05" type="capsule"/></body>
        </worldbody></mujoco>""", "primitive"),
}

# ---- 解析 / 退化补充 -----------------------------------------------------
EXTRA_FIXTURES = {
    "sphere_sphere_overlap": ("""
        <mujoco><worldbody>
          <body pos="0 0 0"><geom size="0.5" type="sphere"/></body>
          <body pos="0.8 0 0"><freejoint/><geom size="0.5" type="sphere"/></body>
        </worldbody></mujoco>""", "analytic"),
    "sphere_plane_grazing": ("""
        <mujoco><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.4999"><freejoint/><geom size="0.5" type="sphere"/></body>
        </worldbody></mujoco>""", "analytic"),
    "capsule_capsule_parallel": ("""
        <mujoco><worldbody>
          <body pos="0 0 0"><geom fromto="-1 0 0 1 0 0" size="0.1" type="capsule"/></body>
          <body pos="0 0 0.19"><freejoint/><geom fromto="-1 0 0 1 0 0" size="0.1" type="capsule"/></body>
        </worldbody></mujoco>""", "degenerate"),
    "box_plane_flush": ("""
        <mujoco><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "degenerate"),
}

# ---- 多体场景 (rollout) ------------------------------------------------
# 起始即接触/极近, 让 free 模式前几步就有 contact。
SCENE_FIXTURES = {
    "box_stack3": ("""
        <mujoco><option timestep="0.002"/><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
          <body pos="0.01 0 1.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
          <body pos="-0.01 0.01 2.5"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "scene"),
    "spheres_20": ("""
        <mujoco><option timestep="0.002"/><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <replicate count="20" offset="0.19 0 0">
            <body pos="-1.9 0 0.1"><freejoint/><geom size="0.1" type="sphere"/></body>
          </replicate>
        </worldbody></mujoco>""", "scene"),
    "box_drop": ("""
        <mujoco><option timestep="0.004"/><worldbody>
          <geom type="plane" size="10 10 .001"/>
          <body pos="0 0 0.56" euler="3 2 0"><freejoint/><geom size="0.5 0.5 0.5" type="box"/></body>
        </worldbody></mujoco>""", "scene"),
}

# ---- 官方 engine_collision_gjk_test.cc 内联位形 (47 个测试, 46 个抽出; EllipsoidEllipsoidPenetrating 需要 keyframe 暂缺) --------------------
# 来源: ~/mujoco @ f9a00bd, test/engine/engine_collision_gjk_test.cc
# 这些是官方 GJK/EPA 单元测试用的解析/退化位形, 逐字抽取(静态两geom worldbody, 无自由度),
# tier 沿用本文件既有词表: 有闭式解的几个标 analytic, 其余(多为 GJK/EPA 易翻车位形)标 degenerate。
GJK_OFFICIAL_FIXTURES = {
    "gjk_sphere_sphere_dist": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="sphere" pos="-1.5 0 0" size="1"/>
      <geom name="geom2" type="sphere" pos="1.5 0 0" size="1"/>
    </worldbody>
  </mujoco>""", "analytic"),  # SphereSphereDist
    "gjk_sphere_sphere_dist_cutoff": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="sphere" pos="-1.5 0 0" size="1"/>
      <geom name="geom2" type="sphere" pos="1.5 0 0" size="1"/>
    </worldbody>
  </mujoco>""", "analytic"),  # SphereSphereDistCutoff
    "gjk_sphere_sphere_no_dist": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="sphere" pos="-1.5 0 0" size="1"/>
      <geom name="geom2" type="sphere" pos="1.5 0 0" size="1"/>
    </worldbody>
  </mujoco>""", "analytic"),  # SphereSphereNoDist
    "gjk_sphere_sphere_intersect": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="sphere" pos="-1 0 0" size="3"/>
      <geom name="geom2" type="sphere" pos="3 0 0" size="3"/>
    </worldbody>
  </mujoco>""", "analytic"),  # SphereSphereIntersect
    "gjk_box_box_depth": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" pos="-1 0 0" size="2.5 2.5 2.5"/>
      <geom name="geom2" type="box" pos="1.5 0 0" size="1 1 1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxDepth
    "gjk_box_box_depth2": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="5 5 .1"/>
      <geom name="geom2" type="box" size="1 1 1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxDepth2
    "gjk_box_box_depth3": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.25 0.25 0.05"/>
      <geom name="geom2" type="box" size="0.25 0.25 0.05"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxDepth3
    "gjk_box_box_size05": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.5 0.5 0.5"/>
      <geom name="geom2" type="box" size="0.5 0.5 0.5"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxSize05
    "gjk_box_box_size05b": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.5 0.5 0.5"/>
      <geom name="geom2" type="box" size="0.5 0.5 0.5"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxSize05b
    "gjk_box_box_size05c": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.5 0.5 0.5"/>
      <geom name="geom2" type="box" size="0.5 0.5 0.5"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxSize05c
    "gjk_box_box_touching": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" pos="0 0 1.859913200000001376466229885409" size="1 1 1"/>
      <geom name="geom2" type="box" pos="0 2 1.859913200000001376466229885409" size="1 1 1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxTouching
    "gjk_box_box_multi_c_c_d": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" pos="0 0 1.9" size="1 1 1"/>
      <geom name="geom2" type="box" pos="0 0 0" size="10 10 1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD
    "gjk_box_box_multi_c_c_d2": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" pos="9.5 9.5 1.9" size="1 1 1"/>
      <geom name="geom2" type="box" pos="0 0 0" size="10 10 1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD2
    "gjk_box_box_multi_c_c_d3": ("""  <mujoco>
    <worldbody>
      <geom type="box" name="geom1" size="5 5 .1" pos="0 0 0"/>
      <geom type="box" name="geom2" size="1 1 1"/>
    </worldbody>
</mujoco>""", "degenerate"),  # BoxBoxMultiCCD3
    "gjk_box_box_multi_c_c_d4": ("""  <mujoco>
    <worldbody>
     <geom name="geom1" size="0.25 0.25 0.05" type="box"/>
     <geom name="geom2" size="0.25 0.25 0.05" type="box"/>
    </worldbody>
</mujoco>""", "degenerate"),  # BoxBoxMultiCCD4
    "gjk_box_box_multi_c_c_d5": ("""  <mujoco>
    <worldbody>
     <geom name="geom1" size="0.25 0.25 0.05" type="box"/>
     <geom name="geom2" size="0.25 0.25 0.05" type="box"/>
    </worldbody>
</mujoco>""", "degenerate"),  # BoxBoxMultiCCD5
    "gjk_box_box_multi_c_c_d6": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size=".5 .5 .1" pos="0 0 -.1"/>
      <geom name="geom2" type="box" size=".1 .1 .1" pos="0 0 0"/>
    </worldbody>
</mujoco>""", "degenerate"),  # BoxBoxMultiCCD6
    "gjk_box_box_multi_c_c_d7": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size=".25 .25 .05"/>
      <geom name="geom2" type="box" size=".25 .25 .05"/>
    </worldbody>
</mujoco>""", "degenerate"),  # BoxBoxMultiCCD7
    "gjk_box_box_multi_c_c_d8": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size=".25 .25 .05"/>
      <geom name="geom2" type="box" size=".25 .25 .05"/>
    </worldbody>
</mujoco>""", "degenerate"),  # BoxBoxMultiCCD8
    "gjk_box_box_multi_c_c_d9": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size=".025 .025 .025"/>
      <geom name="geom2" type="box" size=".025 .025 .025"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD9
    "gjk_box_box_multi_c_c_d10": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.025 0.025 0.025"/>
      <geom name="geom2" type="box" size="0.025 0.025 0.025"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD10
    "gjk_box_box_multi_c_c_d11": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.025 0.025 0.025"/>
      <geom name="geom2" type="box" size="0.025 0.025 0.025"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD11
    "gjk_box_box_multi_c_c_d12": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.025 0.025 0.025"/>
      <geom name="geom2" type="box" size="0.025 0.025 0.025"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD12
    "gjk_box_box_multi_c_c_d13": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.02 0.02 0.02"/>
      <geom name="geom2" type="box" size="0.02 0.02 0.02"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD13
    "gjk_box_box_multi_c_c_d14": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.02 0.02 0.02"/>
      <geom name="geom2" type="box" size="0.02 0.02 0.02"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD14
    "gjk_box_box_multi_c_c_d15": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" size="0.5 0.5 0.1"/>
      <geom name="geom2" type="box" size="0.025 0.025 0.025"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxMultiCCD15
    "gjk_small_box_mesh": ("""  <mujoco>
    <asset>
      <mesh name="box" scale=".5 .5 .1"
        vertex="-1 -1 -1
                 1 -1 -1
                 1  1 -1
                 1  1  1
                 1 -1  1
                -1  1 -1
                -1  1  1
                -1 -1  1"/>
      <mesh name="smallbox" scale=".1 .1 .1"
        vertex="-1 -1 -1
                 1 -1 -1
                 1  1 -1
                 1  1  1
                 1 -1  1
                -1  1 -1
                -1  1  1
                -1 -1  1"/>
    </asset>

    <worldbody>
      <geom name="geom2" pos="0 0 .1" size=".1 .1 .1"  type="mesh" mesh="smallbox"/>
      <geom name="geom1" pos="0 0 -.099999999" size=".5 .5 .1"  type="mesh" mesh="box"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # SmallBoxMesh
    "gjk_box_mesh": ("""  <mujoco>
    <asset>
      <mesh name="pentaprism"
            vertex="1 0 0 0.309 0.951 0 -0.809 0.588 0 -0.809 -0.588 0 0.309 -0.951 0
                    1 0 1 0.309 0.951 1 -0.809 0.588 1 -0.809 -0.588 1 0.309 -0.951 1"
            scale=".2 .2 .1"/>
    </asset>
    <worldbody>
      <geom name="geom1" type="box" pos="0 0 -.01" size="3 3 .01"/>
      <geom name="geom2" pos="0 0 0.157" euler="0 -90 0" type="mesh" mesh="pentaprism"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxMesh
    "gjk_box_mesh2": ("""  <mujoco>
    <asset>
      <mesh name="pentaprism"
            vertex="1 0 0 0.309 0.951 0 -0.809 0.588 0 -0.809 -0.588 0 0.309 -0.951 0
                    1 0 1 0.309 0.951 1 -0.809 0.588 1 -0.809 -0.588 1 0.309 -0.951 1"
            scale=".2 .2 .1"/>
    </asset>
    <worldbody>
      <geom name="geom1" type="box" pos="0 0 -.01" size="3 3 .01"/>
      <geom name="geom2" pos="0 0 -0.001" type="mesh" mesh="pentaprism"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxMesh2
    "gjk_box_mesh_prune": ("""  <mujoco>
    <asset>
      <mesh name="pentaprism"
            vertex="1 0 0 0.309 0.951 0 -0.809 0.588 0 -0.809 -0.588 0 0.309 -0.951 0
                    1 0 1 0.309 0.951 1 -0.809 0.588 1 -0.809 -0.588 1 0.309 -0.951 1"
            scale=".2 .2 .1"/>
    </asset>
    <worldbody>
      <geom name="geom1" type="box" pos="0 0 -.01" size="3 3 .01"/>
      <geom name="geom2" pos="0 0 -0.001" type="mesh" mesh="pentaprism"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxMeshPrune
    "gjk_mesh_mesh": ("""  <mujoco>
    <asset>
      <mesh name="box" vertex="-1 -1 -1 1 -1 -1 1 1 -1 1 1 1 1 -1 1 -1 1 -1 -1 1 1 -1 -1 1"
            scale="1 1 .01"/>
      <mesh name="pentaprism"
            vertex="1 0 0 0.309 0.951 0 -0.809 0.588 0 -0.809 -0.588 0 0.309 -0.951 0
                    1 0 1 0.309 0.951 1 -0.809 0.588 1 -0.809 -0.588 1 0.309 -0.951 1"
            scale=".2 .2 .1"/>
    </asset>
    <worldbody>
      <geom name="geom1" type="mesh" pos="0 0 -0.01" mesh="box"/>
      <geom name="geom2" pos="0 0 -0.001" type="mesh" mesh="pentaprism"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # MeshMesh
    "gjk_mesh_mesh_prune": ("""  <mujoco>
    <asset>
      <mesh name="box" vertex="-1 -1 -1 1 -1 -1 1 1 -1 1 1 1 1 -1 1 -1 1 -1 -1 1 1 -1 -1 1"
            scale="1 1 .01"/>
      <mesh name="pentaprism"
            vertex="1 0 0 0.309 0.951 0 -0.809 0.588 0 -0.809 -0.588 0 0.309 -0.951 0
                    1 0 1 0.309 0.951 1 -0.809 0.588 1 -0.809 -0.588 1 0.309 -0.951 1"
            scale=".2 .2 .1"/>
    </asset>
    <worldbody>
      <geom name="geom1" type="mesh" pos="0 0 -0.01" mesh="box"/>
      <geom name="geom2" pos="0 0 -0.001" type="mesh" mesh="pentaprism"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # MeshMeshPrune
    "gjk_box_edge": ("""  <mujoco>
    <worldbody>
      <geom type="box" name="box1" size="1 1 1" pos="0 0 2"/>
      <geom type="box" name="box2" size="1 1 1" pos="0 0 4.4" euler="0 90 40"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxEdge
    "gjk_box_edge2": ("""  <mujoco>
    <worldbody>
      <geom type="box" name="box1" size="1 1 1"/>
      <geom type="box" name="box2" size="1 1 1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxEdge2
    "gjk_box_edge_edge": ("""  <mujoco>
    <worldbody>
      <geom type="box" name="box1" size=".15 1 3"/>
      <geom type="box" name="box2" size=".15 1 3"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxEdgeEdge
    "gjk_mesh_edge": ("""  <mujoco>
    <asset>
      <mesh name="smallbox"
        vertex="-1 -1 -1  1 -1 -1   1  1 -1
                 1  1  1  1 -1  1  -1  1 -1
                -1  1  1 -1 -1  1"/>
    </asset>
    <worldbody>
      <geom type="mesh" mesh="smallbox" name="box1" size="1 1 1" pos="0 0 2"/>
      <geom type="mesh" mesh="smallbox" name="box2" size="1 1 1" pos="0 0 4.4" euler="0 90 40"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # MeshEdge
    "gjk_mesh_edge2": ("""  <mujoco>
    <asset>
      <mesh name="meshbox"
            vertex="-1 -1 -1
                     1 -1 -1
                     1  1 -1
                     1  1  1
                     1 -1  1
                    -1  1 -1
                    -1  1  1
                    -1 -1  1"/>
    </asset>

    <worldbody>
      <geom type="box" name="floor" size="6 6 2" pos="0 0 -1"/>
      <body pos="2 0 1" euler="0 5 0">
        <freejoint/>
        <geom type="mesh" name="meshbox" mesh="meshbox"/>
      </body>
    </worldbody>
  </mujoco>
  """, "degenerate"),  # MeshEdge2
    "gjk_ellipsoid_ellipsoid": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="ellipsoid" pos="1.5 0 -.5" size=".15 .30 .20"/>
      <geom name="geom2" type="ellipsoid" pos="1.5 .5 .5" size=".10 .10 .15"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # EllipsoidEllipsoid
    "gjk_ellipsoid_ellipsoid_slow_convergence": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="ellipsoid" size=".05 .07 .15"/>
      <geom name="geom2" type="ellipsoid" size=".05 .07 .15"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # EllipsoidEllipsoidSlowConvergence
    "gjk_box_box": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" pos="-1.5 .5 0" size="1 1 1"/>
      <geom name="geom2" type="box" pos="1.5 0 0" size="1 1 1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBox
    "gjk_box_box_large": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="box" pos="0 0 0.25" size="50 50 0.25"/>
      <geom name="geom2" type="box" pos="0 0 0.60" size="0.1 0.1 0.1"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxBoxLarge
    "gjk_long_box": ("""  <mujoco>
    <asset>
      <mesh name="long_box"
            vertex="-1 -1 -1 1 -1 -1 1 1 -1 1 1 1 1 -1 1 -1 1 -1 -1 1 1 -1 -1 1"
            scale=".6 .03 .03"/>
    </asset>
    <worldbody>
      <geom name="geom1" type="box" size="1 1 .3" pos="0 0 -.3"/>
      <geom name="geom2" type="mesh" mesh="long_box" pos="0 0 .02" euler="0 0 40"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # LongBox
    "gjk_ellipsoid_ellipsoid_intersect": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="ellipsoid" pos="1.5 0 -.5" size=".15 .30 .20"/>
      <geom name="geom2" type="ellipsoid" pos="1.5 .5 .5" size=".10 .10 .15"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # EllipsoidEllipsoidIntersect
    "gjk_capsule_capsule": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" type="capsule" pos="-.3 .2 -.4" size=".15 .30"/>
      <geom name="geom2" type="capsule" pos=".3 .2 .4" size=".10 .10"/>
    </worldbody>
  </mujoco>""", "analytic"),  # CapsuleCapsule
    "gjk_cylinder_box_margin": ("""  <mujoco>
    <statistic meansize="0.15"/>
    <option>
      <flag gravity="disable" multiccd="disable"/>
    </option>

    <worldbody>
      <body pos="0 0 .265">
        <freejoint/>
        <geom type="box" size=".05 .05 .05" margin="0.1" gap="0.1"/>
      </body>
      <body mocap="true">
        <geom name="geom2" type="cylinder" size=".2 .2"/>
      </body>
    </worldbody>
  </mujoco>""", "degenerate"),  # CylinderBoxMargin
    "gjk_box_edge_flipped": ("""  <mujoco>
    <worldbody>
      <geom name="geom1" pos="1.10164554 -0.11389316 0.74"
            quat="-0.348312918 0 0 0.937378318" type="box" size="0.65 0.48 0.04"/>
      <geom name="geom2" type="box" size="0.1 1.2 1.4" pos="1.4 0 1.425"/>
    </worldbody>
  </mujoco>""", "degenerate"),  # BoxEdgeFlipped
}

# ---- 官方 testdata/collisions.xml: broadphase 分类/过滤判定(碰/需窄相位/可宽相位排除/exclude/pair) --
# 来源: ~/mujoco @ f9a00bd, test/engine/testdata/collisions.xml, 逐字抽取
#
# 注意: tier 故意标成 "structural" 而不是 "scene", 不会被 run_eval.py 的默认 --cases 自动选中
# (默认 free 只挑 "scene", hybrid 只挑 analytic/primitive/degenerate)。原因: 这个模型里的球深度
# 嵌入 box(官方原意只用它测"候选对有没有被正确筛出", 从没让它真的 mj_step 往前跑), 而且部分球的
# 关节轴恰好穿过геom中心, 旋转不改变位置——对这类"物理上无法缓解穿透"的位形, 求解器为了单步内
# 修正巨大穿透量会产生数量级 1e10 的加速度(参考解本身就这么大, 不是 NPU/fp32 引入的), 相对误差
# 在这种病态数值下毫无意义, S4~S10 的 qacc/qpos 门禁在这个用例上会产生看似"炸裂"实则无意义的假警报。
# 这个用例只应该用来单独验证 S3 层面的结构性正确性(候选对集合、ncon、missed/spurious rate),
# 不要用它的 S4+ 结果下结论。手动跑法: `--cases broadphase_filter --modes free --nstep 1`,
# 只看 report 里 S3 那一行。
BROADPHASE_FIXTURES = {
    "broadphase_filter": ("""
<mujoco model="collisions">
  <worldbody>
    <body name="box">
      <geom name="box" type="box" size="1 1 1"/>
    </body>
    <body pos="1.2 1.2 0.0">
      <!-- collides with box -->
      <joint/>
      <geom name="sphere_collides" type="sphere" size="1"/>
    </body>
    <body pos="-0.9 -0.9 0.0">
      <!-- collides with box, and is a predefined pair -->
      <joint/>
      <geom name="sphere_predefined" type="sphere"  size="0.1"/>
    </body>
    <body pos="1.8 -1.8 0.0" >
      <!-- doesn't collide with box, but requires narrowphase checking -->
      <joint/>
      <geom name="sphere_narrowphase" type="sphere" size="1"/>
    </body>
    <body pos="-2.1 -2.1 0.0">
      <!-- doesn't collide with box, and can be eliminated in broadphase -->
      <joint/>
      <geom name="sphere_broadphase" type="sphere" size="1"/>
    </body>
    <body name="sphere_excluded">
      <!-- collides with box, but is excluded -->
      <joint/>
      <geom name="sphere_excluded" type="sphere" pos="0.0 0.0 0.0" size="0.2"/>
    </body>
  </worldbody>
  <contact>
    <exclude body1="box" body2="sphere_excluded"/>
    <pair geom1="box" geom2="sphere_predefined"/>
  </contact>
</mujoco>
""", "structural"),
}


ALL_FIXTURES = {**MJWARP_FIXTURES, **EXTRA_FIXTURES, **SCENE_FIXTURES, **GJK_OFFICIAL_FIXTURES, **BROADPHASE_FIXTURES}


def by_tier(*tiers):
    return {k: v for k, (v, t) in ALL_FIXTURES.items() if t in tiers}


def xml_of(name):
    return ALL_FIXTURES[name][0]


def tier_of(name):
    return ALL_FIXTURES[name][1]
