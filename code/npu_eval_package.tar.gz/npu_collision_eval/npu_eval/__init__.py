"""NPU 碰撞检测优化 —— 阶段级(pipeline-stage)对比测评。

设计文档: ../npu_collision_eval_plan.md 的 § E(阶段级执行流程)。
方法学模板: MuJoCo test/pipeline_test.cc + mujoco_warp/_src/collision_driver_test.py。

四条泳道(lane):
  cpu_fp64   —— 官方默认 double 构建, 唯一 ground truth
  cpu_fp32   —— mjtNum=float 构建, "纯精度损失"基线(需单独 wheel, 见 README)
  mjwarp     —— MuJoCo Warp, GPU 参考带(需 NVIDIA GPU + pip install mujoco-warp)
  npu        —— 被测对象(填 npu_eval/lanes.py:NpuLane)

对照点是 mj_step 各阶段边界处的 mjData 字段, 不看碰撞算子内部。
"""
__version__ = "0.1.0"
