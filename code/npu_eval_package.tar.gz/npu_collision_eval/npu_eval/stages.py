"""mj_step 的阶段分解 + 每个阶段边界的 mjData 快照。

阶段序列严格对应 src/engine/engine_forward.c 里 mj_fwdPosition / mj_fwdVelocity /
mj_fwdActuation / mj_fwdAcceleration / mj_fwdConstraint + 积分器的调用顺序。
已验证: 依次调用下列子函数, 结果与 mj_forward()+mj_Euler() 逐位相同。
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import mujoco
import numpy as np

T = mujoco.mjtTimer

# ---- 阶段定义 --------------------------------------------------------------
# 每个阶段: id, 中文名, 该阶段要跑的 mujoco 函数序列, 关联的官方 timer, NPU 是否改动
STAGES = [
    ("S1", "位置运动学/惯量", ["mj_fwdKinematics", "mj_makeM", "mj_factorM"],
     [T.mjTIMER_POS_KINEMATICS, T.mjTIMER_POS_INERTIA], False),
    ("S3", "碰撞检测", ["mj_collision"],
     [T.mjTIMER_POS_COLLISION, T.mjTIMER_COL_BROAD, T.mjTIMER_COL_NARROW], True),
    ("S4", "构建约束", ["mj_makeConstraint", "mj_island"],
     [T.mjTIMER_POS_MAKE], False),
    ("S5", "投影约束/传动", ["mj_projectConstraint", "mj_transmission"],
     [T.mjTIMER_POS_PROJECT], False),
    ("S6", "速度相关", ["mj_fwdVelocity"], [T.mjTIMER_VELOCITY], False),
    ("S7", "执行器/无约束加速度", ["mj_fwdActuation", "mj_fwdAcceleration"],
     [T.mjTIMER_ACTUATION], False),
    ("S9", "约束求解", ["mj_fwdConstraint"], [T.mjTIMER_CONSTRAINT], False),
    ("S10", "积分", ["__integrate__"], [T.mjTIMER_ADVANCE], False),
]
STAGE_IDS = [s[0] for s in STAGES]
STAGE_INFO = {s[0]: dict(name=s[1], funcs=s[2], timers=s[3], npu=s[4]) for s in STAGES}


def _integrator_fn(m):
    return {
        mujoco.mjtIntegrator.mjINT_EULER: mujoco.mj_Euler,
        mujoco.mjtIntegrator.mjINT_IMPLICIT: mujoco.mj_implicit,
        mujoco.mjtIntegrator.mjINT_IMPLICITFAST: mujoco.mj_implicit,
        mujoco.mjtIntegrator.mjINT_RK4: lambda mm, dd: mujoco.mj_RungeKutta(mm, dd, 4),
    }.get(mujoco.mjtIntegrator(m.opt.integrator), mujoco.mj_Euler)


def run_stage(m, d, stage_id):
    """在 (m,d) 上就地跑 stage_id 一个阶段。返回该阶段的 wall-clock 秒数。"""
    t0 = time.perf_counter()
    for fname in STAGE_INFO[stage_id]["funcs"]:
        if fname == "__integrate__":
            _integrator_fn(m)(m, d)
        elif fname == "mj_island" and not hasattr(mujoco, "mj_island"):
            continue
        else:
            getattr(mujoco, fname)(m, d)
    return time.perf_counter() - t0


# ---- 快照 ---------------------------------------------------------------
# 每个阶段边界要抽出来比对的 mjData 字段。key 是快照字段名, value 是提取函数。
def _contacts(d):
    n = int(d.ncon)
    if n == 0:
        return np.zeros((0, 21))
    rows = []
    for i in range(n):
        c = d.contact[i]
        rows.append(np.concatenate([
            [c.dist], c.pos.ravel(), c.frame.ravel(), [c.dim],
            c.geom.astype(float).ravel(), c.friction.ravel()[:5],
        ]))
    return np.array(rows)  # [N, 1+3+9+1+2+5]


CONTACT_COLS = dict(dist=slice(0, 1), pos=slice(1, 4), frame=slice(4, 13),
                    dim=slice(13, 14), geom=slice(14, 16), friction=slice(16, 21))

SNAP_FIELDS = {
    # 名称 -> (提取函数, 该字段在哪个阶段之后才有意义的最早阶段)
    "geom_xpos":       (lambda m, d: np.array(d.geom_xpos), "S1"),
    "geom_xmat":       (lambda m, d: np.array(d.geom_xmat), "S1"),
    "qM":              (lambda m, d: np.array(d.qM), "S1"),
    "ncon":            (lambda m, d: np.array([d.ncon]), "S3"),
    "contact":         (lambda m, d: _contacts(d), "S3"),
    "nefc":            (lambda m, d: np.array([d.nefc]), "S4"),
    "efc_pos":         (lambda m, d: np.array(d.efc_pos), "S4"),
    "efc_J":           (lambda m, d: np.array(d.efc_J).reshape(d.nefc, m.nv)
                        if d.efc_J.size == d.nefc * m.nv else np.array(d.efc_J), "S4"),
    "efc_aref":        (lambda m, d: np.array(d.efc_aref), "S6"),
    "qfrc_bias":       (lambda m, d: np.array(d.qfrc_bias), "S6"),
    "qacc":            (lambda m, d: np.array(d.qacc), "S9"),
    "efc_force":       (lambda m, d: np.array(d.efc_force), "S9"),
    "qfrc_constraint": (lambda m, d: np.array(d.qfrc_constraint), "S9"),
    "solver_niter":    (lambda m, d: np.array(d.solver_niter), "S9"),
    "qpos":            (lambda m, d: np.array(d.qpos), "S10"),
    "qvel":            (lambda m, d: np.array(d.qvel), "S10"),
    "act":             (lambda m, d: np.array(d.act), "S10"),
    "time":            (lambda m, d: np.array([d.time]), "S10"),
}


@dataclass
class Snapshot:
    stage: str
    step: int
    fields: dict = field(default_factory=dict)
    stage_seconds: float = 0.0
    timers: dict = field(default_factory=dict)   # {timer_name: (duration, number)}


def snapshot(m, d, stage_id, step, stage_seconds=0.0):
    order = STAGE_IDS.index(stage_id)
    fields = {}
    for name, (fn, min_stage) in SNAP_FIELDS.items():
        if STAGE_IDS.index(min_stage) <= order:
            try:
                fields[name] = fn(m, d)
            except Exception as e:  # noqa: BLE001
                fields[name] = np.array([np.nan])
                fields[name + "__err"] = str(e)
    tmr = {}
    for tid in STAGE_INFO[stage_id]["timers"]:
        tmr[T(tid).name] = (float(d.timer[int(tid)].duration), int(d.timer[int(tid)].number))
    return Snapshot(stage=stage_id, step=step, fields=fields,
                    stage_seconds=stage_seconds, timers=tmr)
