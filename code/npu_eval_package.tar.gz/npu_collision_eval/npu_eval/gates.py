"""把 metrics.stage_metrics 的输出对照 thresholds.yaml 判 PASS/FAIL。"""
from __future__ import annotations

import pathlib

import yaml

_CFG = pathlib.Path(__file__).resolve().parents[1] / "config" / "thresholds.yaml"


def load_thresholds(path=None):
    with open(path or _CFG) as f:
        return yaml.safe_load(f)


def _get(d, *keys, default=None):
    for k in keys:
        if isinstance(d, dict) and k in d:
            d = d[k]
        else:
            return default
    return d


def check_stage(stage, m, thr, case_name=""):
    """返回 (passed: bool, failures: list[str])。"""
    t = thr.get(stage, {})
    fails = []

    if stage == "S3":
        if m.get("missed_rate", 0) > t.get("missed_rate", 0):
            fails.append(f"missed_rate={m['missed_rate']:.4f} > {t['missed_rate']}")
        if m.get("normal_flip_rate", 0) > t.get("normal_flip_rate", 0):
            fails.append(f"normal_flip_rate={m['normal_flip_rate']:.4f} > {t['normal_flip_rate']}")
        if t.get("ncon_equal_required") and not m.get("ncon_equal", 1):
            if not any(k in case_name for k in thr.get("known_divergent", [])):
                fails.append(f"ncon mismatch ref={m.get('ncon_ref')} test={m.get('ncon_test')}")
            elif m.get("ncon_test", 0) < m.get("ncon_ref", 0):
                fails.append(f"ncon test<ref on known-divergent collider ({m.get('ncon_test')}<{m.get('ncon_ref')})")
        for k in ("dist_abs_p95", "pos_l2_p95", "normal_deg_p95", "spurious_rate"):
            if k in t and m.get(k, 0) > t[k]:
                fails.append(f"{k}={m[k]:.4g} > {t[k]}")

    elif stage == "S4":
        if t.get("nefc_equal_required") and not m.get("nefc_equal", 1):
            fails.append(f"nefc mismatch ref={m.get('nefc_ref')} test={m.get('nefc_test')}")
        if _get(m, "efc_J_rel", "p95", default=0) > t.get("efc_J_rel_p95", 1):
            fails.append(f"efc_J_rel.p95={m['efc_J_rel']['p95']:.4g} > {t['efc_J_rel_p95']}")
        if _get(m, "efc_pos_rel", "p95", default=0) > t.get("efc_pos_rel_p95", 1):
            fails.append(f"efc_pos_rel.p95={m['efc_pos_rel']['p95']:.4g} > {t['efc_pos_rel_p95']}")

    elif stage == "S6":
        if _get(m, "efc_aref_rel", "p95", default=0) > t.get("efc_aref_rel_p95", 1):
            fails.append(f"efc_aref_rel.p95 > {t['efc_aref_rel_p95']}")
        if _get(m, "qfrc_bias_rel", "p95", default=0) > t.get("qfrc_bias_rel_p95", 1):
            fails.append(f"qfrc_bias_rel.p95 > {t['qfrc_bias_rel_p95']}")

    elif stage == "S9":
        if m.get("qacc_linf", 0) > t.get("qacc_linf", 1):
            fails.append(f"qacc_linf={m['qacc_linf']:.4g} > {t['qacc_linf']}")
        if m.get("qacc_rel_p95", 0) > t.get("qacc_rel_p95", 1):
            fails.append(f"qacc_rel_p95={m['qacc_rel_p95']:.4g} > {t['qacc_rel_p95']}")
        if m.get("solver_niter_absdiff", 0) > t.get("solver_niter_absdiff", 99):
            fails.append(f"solver_niter_absdiff={m['solver_niter_absdiff']} > {t['solver_niter_absdiff']}")
        if _get(m, "efc_force_rel", "p95", default=0) > t.get("efc_force_rel_p95", 1):
            fails.append(f"efc_force_rel.p95 > {t['efc_force_rel_p95']}")

    elif stage == "S10":
        if m.get("qpos_linf", 0) > t.get("qpos_linf", 1):
            fails.append(f"qpos_linf={m['qpos_linf']:.4g} > {t['qpos_linf']}")
        if m.get("qvel_linf", 0) > t.get("qvel_linf", 1):
            fails.append(f"qvel_linf={m['qvel_linf']:.4g} > {t['qvel_linf']}")

    return (len(fails) == 0), fails
