"""NPU 碰撞检测后端适配层 —— 内网机器上唯一要改的文件。

harness 已经把「主机侧运动学 → 调 NPU 碰撞 → 拿回接触 → 喂回 CPU 下游」这条链路
接好了。你只需要在下面 ▶▶▶ 三个函数里，把 npu_collide 接到你的 NPU 碰撞实现上。

────────────────────────────────────────────────────────────────────────
数据契约（Schema）
────────────────────────────────────────────────────────────────────────
一次性（build_static）——从编译好的 mjModel 抽出的静态几何信息，字典：
  ngeom:        int
  geom_type:    [ngeom] int      MuJoCo geom 类型枚举 (0 plane,2 sphere,3 capsule,
                                 4 ellipsoid,5 cylinder,6 box,7 mesh,...)
  geom_size:    [ngeom,3] float
  geom_rbound:  [ngeom] float    包围球半径
  geom_margin:  [ngeom] float
  geom_gap:     [ngeom] float
  geom_condim:  [ngeom] int
  geom_priority:[ngeom] int
  geom_solmix:  [ngeom] float
  geom_solref:  [ngeom,2] float
  geom_solimp:  [ngeom,5] float
  geom_friction:[ngeom,3] float
  geom_dataid:  [ngeom] int      mesh geom 指向 mesh_* 的下标，非 mesh 为 -1
  geom_bodyid:  [ngeom] int
  pair_geom:    [npair,2] int    <contact><pair> 显式对（可能为空）
  exclude_signature: [nexclude] int   <contact><exclude>
  mesh:  {  dataid: {"vert":[nv,3] float32, "face":[nf,3] int32,
                     "graphadr":int, ...}  }   仅 mesh geom
  opt:   { "ccd_iterations":int, "ccd_tolerance":float,
           "broadphase":int, "disableflags":int, "enableflags":int,
           "o_margin":float, "multiccd":bool, "nativeccd":bool }
  filterparent: bool

每帧（npu_collide 的入参）——主机侧算好的世界位姿：
  geom_xpos:  [ngeom,3] float
  geom_xmat:  [ngeom,9] float    行主序 3x3

每帧返回（npu_collide 的出参）——接触数组 [K,21]，每行：
  [ 0]      dist        带符号距离（负=穿透），= margin + 几何带符号距离
  [ 1: 4]   pos         世界坐标接触点
  [ 4:13]   frame       9 元素接触帧，前 3 个是法向（geom1→geom2 单位向量）
  [13]      dim         接触维度 1/3/4/6（通常 3）
  [14:16]   geom        [geom1_id, geom2_id]，geom1_id < geom2_id
  [16:21]   friction    5 元素摩擦（前 3 有效即可，其余填 0）
  K 可以是 0。顺序无所谓（harness 用无序匹配）；但同一输入必须给同一结果。
────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import numpy as np

# 接触数组列布局（和 npu_eval/stages.py 的 _contacts 一致）
NCOL = 21
COL = dict(dist=slice(0, 1), pos=slice(1, 4), frame=slice(4, 13),
           dim=slice(13, 14), geom=slice(14, 16), friction=slice(16, 21))


# ============================================================ 主机侧：抽静态数据
def build_static(model) -> dict:
    m = model
    g = dict(
        ngeom=int(m.ngeom),
        geom_type=np.array(m.geom_type, dtype=np.int32),
        geom_size=np.array(m.geom_size, dtype=np.float64).reshape(-1, 3),
        geom_rbound=np.array(m.geom_rbound, dtype=np.float64),
        geom_margin=np.array(m.geom_margin, dtype=np.float64),
        geom_gap=np.array(m.geom_gap, dtype=np.float64),
        geom_condim=np.array(m.geom_condim, dtype=np.int32),
        geom_priority=np.array(m.geom_priority, dtype=np.int32),
        geom_solmix=np.array(m.geom_solmix, dtype=np.float64),
        geom_solref=np.array(m.geom_solref, dtype=np.float64).reshape(-1, 2),
        geom_solimp=np.array(m.geom_solimp, dtype=np.float64).reshape(-1, 5),
        geom_friction=np.array(m.geom_friction, dtype=np.float64).reshape(-1, 3),
        geom_dataid=np.array(m.geom_dataid, dtype=np.int32),
        geom_bodyid=np.array(m.geom_bodyid, dtype=np.int32),
        pair_geom=np.array(m.pair_geom, dtype=np.int32).reshape(-1, 2) if m.npair else np.zeros((0, 2), np.int32),
        filterparent=not bool(m.opt.disableflags & (1 << 0)),  # mjDSBL_CONSTRAINT? 见下注
    )
    # opt
    g["opt"] = dict(
        ccd_iterations=int(m.opt.ccd_iterations),
        ccd_tolerance=float(m.opt.ccd_tolerance),
        broadphase=int(getattr(m.opt, "broadphase", 0)),
        disableflags=int(m.opt.disableflags),
        enableflags=int(m.opt.enableflags),
        o_margin=float(m.opt.o_margin),
        multiccd=bool(m.opt.enableflags & (1 << 19) or not (m.opt.disableflags & (1 << 19))),
        nativeccd=not bool(m.opt.disableflags & (1 << 17)),
    )
    # mesh
    meshes = {}
    for gi in range(m.ngeom):
        did = int(m.geom_dataid[gi])
        if int(m.geom_type[gi]) == 7 and did >= 0 and did not in meshes:  # mjGEOM_MESH
            va = int(m.mesh_vertadr[did]); vn = int(m.mesh_vertnum[did])
            fa = int(m.mesh_faceadr[did]); fn = int(m.mesh_facenum[did])
            meshes[did] = dict(
                vert=np.array(m.mesh_vert[va:va + vn], dtype=np.float32).reshape(-1, 3),
                face=np.array(m.mesh_face[fa:fa + fn], dtype=np.int32).reshape(-1, 3),
            )
    g["mesh"] = meshes
    g["_model"] = model   # 仅自检后端用；真 NPU 后端忽略它
    return g


def host_kinematics(model, data, qpos, qvel):
    """主机侧算世界位姿（运动学不 offload，很便宜）。返回 (geom_xpos[ngeom,3], geom_xmat[ngeom,9])。"""
    import mujoco
    data.qpos[:] = qpos
    data.qvel[:] = qvel
    mujoco.mj_kinematics(model, data)
    mujoco.mj_comPos(model, data)
    return (np.array(data.geom_xpos, dtype=np.float64).reshape(-1, 3),
            np.array(data.geom_xmat, dtype=np.float64).reshape(-1, 9))


def canonical_sort(contacts: np.ndarray) -> np.ndarray:
    """按 (geom1, geom2, pos) 做稳定规范排序，方便复现和注入。harness 匹配是无序的，
    这里排序只为确定性。"""
    if contacts.size == 0:
        return contacts.reshape(0, NCOL)
    c = np.atleast_2d(contacts)
    key = np.lexsort((c[:, 3], c[:, 2], c[:, 1],  # pos z,y,x
                      c[:, 15], c[:, 14]))          # geom2, geom1
    return c[key]


# ============================================================ 自检后端（接真 NPU 前先用它验证胶水）
# 用法: NPU_EVAL_ENABLE=1 NPU_BACKEND=selfcheck python scripts/run_eval.py --lanes cpu_fp64 npu ...
# 它用 CPU mj_collision 从传入的世界位姿算接触，走完整的 build_static→npu_open→npu_collide 链路，
# 结果应 ≈ fp64（微小差异来自运动学重算 / 排序）。用来在真 kernel 就绪前发现 schema/接线问题。
class _SelfCheckHandle:
    def __init__(self, static):
        import mujoco
        self._m = static["_model"]
        self._d = mujoco.MjData(self._m)

    def collide(self, geom_xpos, geom_xmat):
        import mujoco
        d = self._d
        d.geom_xpos[:] = np.asarray(geom_xpos, np.float64).reshape(d.geom_xpos.shape)
        d.geom_xmat[:] = np.asarray(geom_xmat, np.float64).reshape(d.geom_xmat.shape)
        # mj_collision 还需要 body/xipos 等；直接对齐 geom 层即可满足纯几何碰撞
        mujoco.mj_collision(self._m, d)
        n = int(d.ncon)
        if n == 0:
            return np.zeros((0, NCOL))
        rows = []
        for i in range(n):
            c = d.contact[i]
            rows.append(np.concatenate([[c.dist], c.pos.ravel(), c.frame.ravel(),
                                        [c.dim], c.geom.astype(float).ravel(),
                                        c.friction.ravel()[:5]]))
        return np.array(rows)


# ============================================================ ▶▶▶ 要接的三个函数
_READY = False   # 接好后把这里改成 True（或让 npu_open 成功即置位）


def _backend_name():
    import os
    return os.environ.get("NPU_BACKEND", "real").lower()


def npu_open(static: dict):
    """一次性：把 static（几何 / mesh / opt）加载到 NPU，返回一个句柄对象。
    如果你的 NPU 侧不需要预加载，直接 return static 也行。
    """
    if _backend_name() == "selfcheck":
        return _SelfCheckHandle(static)
    # ────────────────────────────────────────────────────────────
    # TODO(内网): 三选一，接你的 NPU 栈
    #
    # 【方式 1 · Python 绑定】
    #   import bluenpu_collide as bnc
    #   return bnc.Model(static)
    #
    # 【方式 2 · 动态库 ctypes】
    #   import ctypes, json
    #   lib = ctypes.CDLL("/opt/bluenpu/libnpu_collide.so")
    #   lib.npu_open.restype = ctypes.c_void_p
    #   buf = json.dumps(_static_to_jsonable(static)).encode()
    #   return lib.npu_open(buf, len(buf))
    #
    # 【方式 3 · 子进程 / 常驻服务】
    #   import subprocess, json
    #   p = subprocess.Popen(["/opt/bluenpu/npu_collide_server"],
    #                        stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    #   p.stdin.write((json.dumps(_static_to_jsonable(static)) + "\n").encode()); p.stdin.flush()
    #   return p
    # ────────────────────────────────────────────────────────────
    raise NotImplementedError("接你的 NPU: npu_backend.npu_open")


def npu_collide(handle, geom_xpos: np.ndarray, geom_xmat: np.ndarray) -> np.ndarray:
    """每帧：输入 ngeom 个几何的世界位姿，返回接触数组 [K,21]（见文件顶部 Schema）。"""
    if _backend_name() == "selfcheck":
        return handle.collide(np.asarray(geom_xpos, np.float64), np.asarray(geom_xmat, np.float64))
    # ────────────────────────────────────────────────────────────
    # TODO(内网): 调 NPU 碰撞 kernel。要点：
    #   - geom_xpos [ngeom,3] float64, geom_xmat [ngeom,9] float64（行主序）
    #   - 返回必须是 np.ndarray, shape [K,21], dtype float64
    #   - dist = margin + 带符号距离；负值 = 穿透
    #   - frame 前 3 个是法向，指向 geom1→geom2，单位向量
    #   - geom 列 [g1,g2] 且 g1 < g2
    #   - 同一输入必须给同一输出（确定性；异步归约要保证或声明抖动上界）
    #
    # 【方式 1】 return handle.collide(geom_xpos, geom_xmat)
    # 【方式 2】 见 _ctypes_collide 模板
    # 【方式 3】 见 _subprocess_collide 模板
    # ────────────────────────────────────────────────────────────
    raise NotImplementedError("接你的 NPU: npu_backend.npu_collide")


def npu_close(handle):
    """收尾：释放 NPU 资源。没有可留空。"""
    try:
        if hasattr(handle, "close"):
            handle.close()
    except Exception:  # noqa: BLE001
        pass


def backend_ready() -> bool:
    """harness 用它判断真 NPU 后端是否可用；不可用则自动降级为 mock 泳道。"""
    if _READY:
        return True
    try:
        npu_open  # noqa: B018
        # 试探：能否 import / dlopen。真正判定放到 NpuHandle.__init__ 里 try。
        import os
        return os.environ.get("NPU_EVAL_FORCE", "0") == "1"
    except Exception:  # noqa: BLE001
        return False


# ============================================================ 模板（按需取用，删掉不用的）
def _static_to_jsonable(static: dict) -> dict:
    """把 static 里的 ndarray 转成可 JSON 序列化的 list，供方式 2/3 用。"""
    out = {}
    for k, v in static.items():
        if isinstance(v, np.ndarray):
            out[k] = v.tolist()
        elif isinstance(v, dict):
            out[k] = {str(kk): _static_to_jsonable(vv) if isinstance(vv, dict) else
                      (vv.tolist() if isinstance(vv, np.ndarray) else vv)
                      for kk, vv in v.items()}
        else:
            out[k] = v
    return out


def _subprocess_collide(proc, geom_xpos, geom_xmat) -> np.ndarray:
    """方式 3 模板：每帧一行 JSON 进、一行 JSON 出。"""
    import json
    msg = json.dumps({"xpos": geom_xpos.tolist(), "xmat": geom_xmat.tolist()})
    proc.stdin.write((msg + "\n").encode()); proc.stdin.flush()
    line = proc.stdout.readline()
    rows = json.loads(line)["contacts"]   # 约定 NPU 侧返回 {"contacts": [[21个数], ...]}
    return np.array(rows, dtype=np.float64).reshape(-1, NCOL) if rows else np.zeros((0, NCOL))
