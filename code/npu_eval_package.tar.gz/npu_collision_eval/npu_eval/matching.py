"""无序接触匹配 —— 抄自 mujoco_warp/_src/collision_driver_test.py 的双重循环,
加上按 (geom1,geom2) 先分组以提速, 并同时报漏检 / 虚检。

参考 (reference) 一般是 cpu_fp64; 被测 (test) 是 npu / mjwarp / cpu_fp32。
"""
from __future__ import annotations

import numpy as np

from .stages import CONTACT_COLS

# mujoco_warp 用的容差: 接触几何 rtol=5e-2, atol=1e-2
GEOM_RTOL = 5e-2
GEOM_ATOL = 1e-2


def _match_one(ref_row, test_rows, rtol, atol):
    for j, tr in enumerate(test_rows):
        d_ok = np.allclose(ref_row[CONTACT_COLS["dist"]], tr[CONTACT_COLS["dist"]], rtol=rtol, atol=atol)
        p_ok = np.allclose(ref_row[CONTACT_COLS["pos"]], tr[CONTACT_COLS["pos"]], rtol=rtol, atol=atol)
        f_ok = np.allclose(ref_row[CONTACT_COLS["frame"]], tr[CONTACT_COLS["frame"]], rtol=rtol, atol=atol)
        if d_ok and p_ok and f_ok:
            return j
    return -1


def match_contacts(ref, test, rtol=GEOM_RTOL, atol=GEOM_ATOL):
    """返回 dict:
        matched : [(i_ref, j_test), ...]
        missed  : [i_ref, ...]     参考有、被测无 -> 漏检
        spurious: [j_test, ...]    被测有、参考无 -> 虚检
    """
    ref = np.atleast_2d(ref) if ref.size else np.zeros((0, 21))
    test = np.atleast_2d(test) if test.size else np.zeros((0, 21))
    used = set()
    matched, missed = [], []
    for i, rr in enumerate(ref):
        # 先按 geom 对缩小候选
        cand = [j for j in range(len(test))
                if j not in used and np.array_equal(test[j, CONTACT_COLS["geom"]], rr[CONTACT_COLS["geom"]])]
        sub = test[cand] if cand else np.zeros((0, 21))
        jj = _match_one(rr, sub, rtol, atol)
        if jj < 0 and len(test):  # 放宽: 不限 geom 对再试一次
            free = [j for j in range(len(test)) if j not in used]
            jj2 = _match_one(rr, test[free], rtol, atol)
            if jj2 >= 0:
                j = free[jj2]
                used.add(j); matched.append((i, j)); continue
        if jj < 0:
            missed.append(i)
        else:
            j = cand[jj]; used.add(j); matched.append((i, j))
    spurious = [j for j in range(len(test)) if j not in used]
    return dict(matched=matched, missed=missed, spurious=spurious,
                n_ref=len(ref), n_test=len(test))
