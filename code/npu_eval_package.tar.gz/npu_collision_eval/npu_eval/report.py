"""结果 -> markdown + csv 报告。"""
from __future__ import annotations

import csv
import json
import pathlib


def _flat(metrics, prefix=""):
    out = {}
    for k, v in (metrics or {}).items():
        if isinstance(v, dict):
            out.update(_flat(v, f"{prefix}{k}."))
        elif isinstance(v, (list, tuple)):
            out[prefix + k] = json.dumps(v)
        else:
            out[prefix + k] = v
    return out


def write_csv(rows, path):
    flat = []
    for r in rows:
        base = {k: r[k] for k in ("mode", "case", "tier", "lane", "seed", "step", "stage", "passed")
                if k in r}
        base["failures"] = " ; ".join(r.get("failures", []))
        base.update(_flat(r.get("metrics", {})))
        flat.append(base)
    keys = sorted({k for f in flat for k in f})
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        for f in flat:
            w.writerow(f)


def write_markdown(rows, summary, path, meta=None):
    L = []
    L.append("# NPU 碰撞检测 —— 阶段级对比测评报告\n")
    if meta:
        L.append("```")
        for k, v in meta.items():
            L.append(f"{k}: {v}")
        L.append("```\n")
    L.append("## 总判定\n")
    verdict = "PASS ✅" if summary["failed"] == 0 else f"FAIL ❌ ({summary['failed']}/{summary['total']} 项)"
    L.append(f"**{verdict}** — pass_rate = {summary['pass_rate']:.3f}\n")
    L.append("| mode:stage | pass/total |")
    L.append("|---|---|")
    for k, v in sorted(summary["by_stage"].items()):
        L.append(f"| {k} | {v} |")
    if any(r["mode"] in ("pairwise", "pairwise_hybrid") for r in rows):
        L.append("\n> `pairwise`/`pairwise_hybrid` 行是泳道间直接对照(比如 `npu~mjwarp`)，"
                 "不设 gate、恒为 100% ——不是真的全过，是这部分本来就没有 pass/fail 判据，"
                 "只看下面的数值表，不要把这两行当门禁读。")
    L.append("")

    if summary["failures"]:
        L.append("## 失败明细\n")
        L.append("| case | lane | stage | seed | step | 原因 |")
        L.append("|---|---|---|---|---|---|")
        for f in summary["failures"]:
            L.append(f"| {f['case']} | {f['lane']} | {f['stage']} | {f.get('seed')} | "
                     f"{f.get('step')} | {' ; '.join(f['why'])} |")
        L.append("")

    # S3 逐 case 误差表(不含泳道间直接对照——那部分见下面独立小节)
    s3 = [r for r in rows if r["stage"] == "S3" and r["mode"] not in ("pairwise", "pairwise_hybrid")]
    if s3:
        L.append("## S3 碰撞阶段误差(按 case 聚合最坏值)\n")
        L.append("| case | tier | lane | missed | flip | ncon(r/t) | dist_p95 | pos_p95 | normal°_p95 |")
        L.append("|---|---|---|---|---|---|---|---|---|")
        agg = {}
        for r in s3:
            m = r["metrics"]
            key = (r["case"], r["lane"])
            a = agg.setdefault(key, dict(tier=r["tier"], missed=0, flip=0, ncr=0, nct=0,
                                         dist=0, pos=0, nrm=0))
            a["missed"] = max(a["missed"], m.get("missed_rate", 0))
            a["flip"] = max(a["flip"], m.get("normal_flip_rate", 0))
            a["ncr"] = m.get("ncon_ref", 0)
            a["nct"] = m.get("ncon_test", 0)
            a["dist"] = max(a["dist"], m.get("dist_abs_p95", 0))
            a["pos"] = max(a["pos"], m.get("pos_l2_p95", 0))
            a["nrm"] = max(a["nrm"], m.get("normal_deg_p95", 0))
        for (case, lane), a in sorted(agg.items()):
            L.append(f"| {case} | {a['tier']} | {lane} | {a['missed']:.3f} | {a['flip']:.3f} | "
                     f"{a['ncr']}/{a['nct']} | {a['dist']:.2e} | {a['pos']:.2e} | {a['nrm']:.2f} |")
        L.append("")

    # hybrid
    hy = [r for r in rows if r["mode"] == "hybrid"]
    if hy:
        L.append("## 混合模式 —— 碰撞差异是否影响下游\n")
        L.append("| case | lane | qacc_linf | qpos_linf | ncon(test/cap) | pass |")
        L.append("|---|---|---|---|---|---|")
        for r in hy:
            m = r["metrics"]
            L.append(f"| {r['case']} | {r['lane']} | {m.get('qacc_linf'):.3e} | "
                     f"{m.get('qpos_linf'):.3e} | {m.get('ncon_test')}/{m.get('ncon_cap')} | "
                     f"{'✅' if r['passed'] else '❌'} |")
        L.append("")

    # 泳道间直接对照(不经 cpu_fp64 中介)——比如 npu vs mjwarp
    pw = [r for r in rows if r["mode"] in ("pairwise", "pairwise_hybrid")]
    if pw:
        L.append("## 泳道间直接对照（不经 cpu_fp64 中介，例如 npu vs mjwarp）\n")
        L.append("这里比的是两条非 fp64 泳道彼此的差异，不是各自相对 fp64 的误差——"
                 "回答「NPU 相对成熟 GPU 移植水平差多少」，不回答「谁对」。"
                 "无 gate，纯参照数据；`report_profileA/B` 里 mjwarp 未接入 GPU 前，这一节不会有内容。\n")
        L.append("| case | pair | stage | dist/pos/normal 或 qacc 差异 | ncon(a/b) |")
        L.append("|---|---|---|---|---|")
        for r in sorted(pw, key=lambda r: (r["case"], r["lane"], r["stage"])):
            m = r["metrics"]
            if r["stage"] == "S3":
                val = f"dist_p95={m.get('dist_abs_p95', 0):.2e} pos_p95={m.get('pos_l2_p95', 0):.2e} normal°_p95={m.get('normal_deg_p95', 0):.2f}"
                ncon = f"{m.get('ncon_ref', '—')}/{m.get('ncon_test', '—')}"
            elif r["stage"] == "S10":
                val = f"qpos_linf={m.get('qpos_linf', 0):.2e} qvel_linf={m.get('qvel_linf', 0):.2e}"
                ncon = "—"
            else:
                val = json.dumps(m, default=str)[:60]
                ncon = "—"
            L.append(f"| {r['case']} | {r['lane']} | {r['stage']} | {val} | {ncon} |")
        L.append("")

    pathlib.Path(path).write_text("\n".join(L))
    return "\n".join(L)
