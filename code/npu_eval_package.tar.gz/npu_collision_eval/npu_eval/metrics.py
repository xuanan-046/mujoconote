"""每个阶段边界的对照指标。输入是两条泳道在同一 (case, step, stage) 的 Snapshot。"""
from __future__ import annotations

import numpy as np

from .matching import match_contacts
from .stages import CONTACT_COLS


def _p(a, q):
    a = np.asarray(a, float).ravel()
    return float(np.percentile(np.abs(a), q)) if a.size else 0.0


def _rel(a, b):
    a, b = np.asarray(a, float).ravel(), np.asarray(b, float).ravel()
    if a.shape != b.shape or a.size == 0:
        return dict(shape_mismatch=True, a=a.shape, b=b.shape)
    den = np.maximum(np.abs(b), 1e-12)
    r = np.abs(a - b) / den
    return dict(mean=float(r.mean()), p95=float(np.percentile(r, 95)), max=float(r.max()))


def stage_metrics(stage, ref, test):
    """ref/test: Snapshot。返回该阶段的指标 dict。"""
    rf, tf = ref.fields, test.fields
    out = {"stage": stage}

    if stage == "S3":
        rc, tc = rf.get("contact", np.zeros((0, 21))), tf.get("contact", np.zeros((0, 21)))
        mm = match_contacts(rc, tc)
        n_ref = max(mm["n_ref"], 1)
        out["ncon_ref"] = mm["n_ref"]
        out["ncon_test"] = mm["n_test"]
        out["ncon_equal"] = int(mm["n_ref"] == mm["n_test"])
        out["missed_rate"] = len(mm["missed"]) / n_ref
        out["spurious_rate"] = len(mm["spurious"]) / max(mm["n_test"], 1)
        if mm["matched"]:
            di = np.array([abs(rc[i, 0] - tc[j, 0]) for i, j in mm["matched"]])
            po = np.array([np.linalg.norm(rc[i, CONTACT_COLS["pos"]] - tc[j, CONTACT_COLS["pos"]])
                           for i, j in mm["matched"]])
            nf = []
            for i, j in mm["matched"]:
                n1 = rc[i, CONTACT_COLS["frame"]][:3]
                n2 = tc[j, CONTACT_COLS["frame"]][:3]
                c = np.clip(np.dot(n1, n2) / (np.linalg.norm(n1) * np.linalg.norm(n2) + 1e-12), -1, 1)
                nf.append(np.degrees(np.arccos(c)))
            nf = np.array(nf)
            out["dist_abs_p95"] = float(np.percentile(di, 95))
            out["dist_abs_max"] = float(di.max())
            out["pos_l2_p95"] = float(np.percentile(po, 95))
            out["pos_l2_max"] = float(po.max())
            out["normal_deg_p95"] = float(np.percentile(nf, 95))
            out["normal_deg_max"] = float(nf.max())
            out["normal_flip_rate"] = float((nf > 90).mean())
        else:
            out.update(dist_abs_p95=0, dist_abs_max=0, pos_l2_p95=0, pos_l2_max=0,
                       normal_deg_p95=0, normal_deg_max=0, normal_flip_rate=0)

    elif stage == "S4":
        out["nefc_ref"] = int(rf.get("nefc", [0])[0])
        out["nefc_test"] = int(tf.get("nefc", [0])[0])
        out["nefc_equal"] = int(out["nefc_ref"] == out["nefc_test"])
        out["efc_J_rel"] = _rel(tf.get("efc_J"), rf.get("efc_J"))
        out["efc_pos_rel"] = _rel(tf.get("efc_pos"), rf.get("efc_pos"))

    elif stage == "S6":
        out["efc_aref_rel"] = _rel(tf.get("efc_aref"), rf.get("efc_aref"))
        out["qfrc_bias_rel"] = _rel(tf.get("qfrc_bias"), rf.get("qfrc_bias"))

    elif stage == "S9":
        qa_r, qa_t = rf.get("qacc"), tf.get("qacc")
        if qa_r is not None and qa_t is not None and qa_r.shape == qa_t.shape:
            out["qacc_linf"] = float(np.abs(qa_r - qa_t).max())
            out["qacc_rel_p95"] = _rel(qa_t, qa_r).get("p95", np.nan)
        ni_r = rf.get("solver_niter", np.zeros(1)).sum()
        ni_t = tf.get("solver_niter", np.zeros(1)).sum()
        out["solver_niter_ref"] = int(ni_r)
        out["solver_niter_test"] = int(ni_t)
        out["solver_niter_absdiff"] = int(abs(ni_r - ni_t))
        out["efc_force_rel"] = _rel(tf.get("efc_force"), rf.get("efc_force"))

    elif stage == "S10":
        for f in ("qpos", "qvel"):
            a, b = tf.get(f), rf.get(f)
            if a is not None and b is not None and a.shape == b.shape:
                out[f + "_l2"] = float(np.linalg.norm(a - b))
                out[f + "_linf"] = float(np.abs(a - b).max())

    # 阶段计时
    out["timers_ref"] = ref.timers
    out["timers_test"] = test.timers
    out["stage_seconds_ref"] = ref.stage_seconds
    out["stage_seconds_test"] = test.stage_seconds
    if test.stage_seconds > 0:
        out["speedup_wall"] = ref.stage_seconds / test.stage_seconds
    return out
