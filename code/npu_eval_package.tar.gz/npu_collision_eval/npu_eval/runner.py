"""编排: cases × lanes × 模式 -> 结果表。

模式:
  free   模式 A —— 各泳道从同一初值自由跑 nstep, 每步在阶段边界快照, 逐阶段对照
  hybrid 混合 —— 被测泳道只跑碰撞(collision_only), 其接触喂回 cpu_fp64 跑 S4..S10,
                 比 qacc / 下一帧 qpos 与纯 cpu_fp64 的差异 -> "碰撞差异影不影响仿真"
"""
from __future__ import annotations

import itertools

import numpy as np

import mujoco

from . import fixtures
from .gates import check_stage, load_thresholds
from .lanes import MujocoLane, get_lanes
from .metrics import stage_metrics
from .stages import STAGE_IDS, Snapshot, run_stage, snapshot

DEFAULT_SNAP_STAGES = ("S3", "S4", "S6", "S9", "S10")


def _init_state(m, seed=0, jitter=0.0):
    d = mujoco.MjData(m)
    mujoco.mj_resetData(m, d)
    qpos = np.array(d.qpos)
    if jitter:
        rng = np.random.default_rng(seed)
        qpos = qpos + jitter * rng.standard_normal(qpos.shape)
    return qpos, np.zeros(m.nv)


# ---------------------------------------------------------------- 模式 A
def run_free(case_names, lane_names, nstep=20, snap_stages=DEFAULT_SNAP_STAGES,
             seeds=(0,), jitter=0.0, thr=None):
    thr = thr or load_thresholds()
    lanes = get_lanes(lane_names)
    ref_lane = next(l for l in lanes if l.name == "cpu_fp64")
    rows = []
    for case in case_names:
        xml = fixtures.xml_of(case)
        m0 = mujoco.MjModel.from_xml_string(xml)
        for seed in seeds:
            qpos, qvel = _init_state(m0, seed, jitter)
            snaps_by_lane = {}
            for lane in lanes:
                if not lane.available() and lane.name != "npu":
                    continue
                h = lane.load(xml)
                h.reset(qpos, qvel)
                snaps_by_lane[lane.name] = h.run_full(nstep, snap_stages)
            ref = snaps_by_lane.get("cpu_fp64")
            if ref is None:
                continue
            for lname, lsnaps in snaps_by_lane.items():
                if lname == "cpu_fp64":
                    continue
                for step in range(min(nstep, len(lsnaps), len(ref))):
                    rmap = {s.stage: s for s in ref[step]}
                    tmap = {s.stage: s for s in lsnaps[step]}
                    for sid in snap_stages:
                        if sid not in rmap or sid not in tmap:
                            continue
                        mt = stage_metrics(sid, rmap[sid], tmap[sid])
                        ok, fails = check_stage(sid, mt, thr, case_name=case)
                        rows.append(dict(mode="free", case=case, tier=fixtures.tier_of(case),
                                         lane=lname, seed=seed, step=step, stage=sid,
                                         passed=ok, failures=fails, metrics=mt))

            # 泳道间直接对照(不经 cpu_fp64 中介)——比如 npu vs mjwarp。纯 informational,
            # 不设 gate(没有"NPU 该跟 mjwarp 差多少"的先验阈值,只作参照带解读用),
            # 所以 passed 恒为 True,不影响 summarize() 的 pass_rate。
            # mjwarp 的 run_full 目前只产出末态(S10)快照,不是逐阶段,所以这条比较
            # 大概率只在 S10 有数据——这是 mjwarp 泳道本身的已知限制,不是这里的 bug。
            peer_names = [n for n in snaps_by_lane if n != "cpu_fp64"]
            for la, lb in itertools.combinations(peer_names, 2):
                sa, sb = snaps_by_lane[la], snaps_by_lane[lb]
                for step in range(min(nstep, len(sa), len(sb))):
                    amap = {s.stage: s for s in sa[step]}
                    bmap = {s.stage: s for s in sb[step]}
                    for sid in snap_stages:
                        if sid not in amap or sid not in bmap:
                            continue
                        mt = stage_metrics(sid, amap[sid], bmap[sid])
                        rows.append(dict(mode="pairwise", case=case, tier=fixtures.tier_of(case),
                                         lane=f"{la}~{lb}", seed=seed, step=step, stage=sid,
                                         passed=True, failures=[], metrics=mt))
    return rows


# ---------------------------------------------------------------- 混合
def run_hybrid(case_names, lane_names, seeds=(0,), jitter=0.0, thr=None):
    thr = thr or load_thresholds()
    lanes = [l for l in get_lanes(lane_names) if l.name != "cpu_fp64"]
    rows = []
    for case in case_names:
        xml = fixtures.xml_of(case)
        m = mujoco.MjModel.from_xml_string(xml)
        m.opt.jacobian = mujoco.mjtJacobian.mjJAC_DENSE
        for seed in seeds:
            qpos, qvel = _init_state(m, seed, jitter)

            # 纯 cpu_fp64 参考
            dref = mujoco.MjData(m)
            dref.qpos[:] = qpos; dref.qvel[:] = qvel
            mujoco.mj_forward(m, dref)
            mujoco.mj_Euler(m, dref)
            qacc_ref = np.array(dref.qacc)
            qpos_ref = np.array(dref.qpos)

            contacts_by_lane = {}
            for lane in lanes:
                if not lane.available() and lane.name != "npu":
                    continue
                h = lane.load(xml)
                try:
                    h.reset(qpos, qvel)
                except NotImplementedError:
                    pass
                c_test = h.collision_only(qpos, qvel)
                contacts_by_lane[lane.name] = c_test

                # 把 c_test 注入一份新的 cpu_fp64 mjData, 跑 S4..S10
                d = mujoco.MjData(m)
                d.qpos[:] = qpos; d.qvel[:] = qvel
                run_stage(m, d, "S1")
                run_stage(m, d, "S3")  # 先真跑一遍以分配 arena
                cap = len(d.contact)
                n_new = min(len(c_test), cap)
                d.ncon = int(n_new)
                for i in range(n_new):
                    r = c_test[i]
                    d.contact[i].dist = float(r[0])
                    d.contact[i].pos[:] = r[1:4]
                    d.contact[i].frame[:] = r[4:13]
                for sid in ("S4", "S5", "S6", "S7", "S9", "S10"):
                    run_stage(m, d, sid)
                qacc_h = np.array(d.qacc)
                qpos_h = np.array(d.qpos)

                def _linf(a, b):
                    # 0 自由度模型(如官方 GJK 静态位形测试)qacc/qpos 是空数组,
                    # max() 会抛 ValueError；空且形状一致时视为 0(平凡相等)。
                    if a.shape != b.shape:
                        return np.nan
                    if a.size == 0:
                        return 0.0
                    return float(np.abs(a - b).max())

                qacc_linf = _linf(qacc_h, qacc_ref)
                qpos_linf = _linf(qpos_h, qpos_ref)
                t9 = thr.get("S9", {})
                ok = (not np.isnan(qacc_linf)) and qacc_linf <= t9.get("qacc_linf", 1e-2)
                rows.append(dict(mode="hybrid", case=case, tier=fixtures.tier_of(case),
                                 lane=lane.name, seed=seed, stage="S9/S10", passed=ok,
                                 failures=[] if ok else [f"qacc_linf={qacc_linf:.4g} > {t9.get('qacc_linf')}"],
                                 metrics=dict(qacc_linf=qacc_linf, qpos_linf=qpos_linf,
                                              ncon_test=len(c_test), ncon_cap=cap)))

            # 泳道间直接对照(不经 cpu_fp64 中介)——比如 npu vs mjwarp 的接触输出直接比,
            # 这是 apples-to-apples 的碰撞层对照(两边都只是 collision_only,不涉及各自
            # 下游求解器实现差异)。纯 informational,不设 gate,原因同 run_free 里那条。
            for la, lb in itertools.combinations(contacts_by_lane, 2):
                snap_a = Snapshot(stage="S3", step=0, fields={"contact": contacts_by_lane[la]})
                snap_b = Snapshot(stage="S3", step=0, fields={"contact": contacts_by_lane[lb]})
                mt = stage_metrics("S3", snap_a, snap_b)
                rows.append(dict(mode="pairwise_hybrid", case=case, tier=fixtures.tier_of(case),
                                 lane=f"{la}~{lb}", seed=seed, stage="S3", passed=True,
                                 failures=[], metrics=mt))
    return rows


def summarize(rows):
    total = len(rows)
    failed = [r for r in rows if not r["passed"]]
    by_stage = {}
    for r in rows:
        k = (r["mode"], r["stage"])
        by_stage.setdefault(k, [0, 0])
        by_stage[k][0] += 1
        by_stage[k][1] += int(r["passed"])
    return dict(total=total, failed=len(failed),
               pass_rate=(total - len(failed)) / total if total else 1.0,
               by_stage={f"{m}:{s}": f"{p}/{n}" for (m, s), (n, p) in by_stage.items()},
               failures=[dict(case=r["case"], lane=r["lane"], stage=r["stage"],
                              seed=r.get("seed"), step=r.get("step"), why=r["failures"])
                         for r in failed])
