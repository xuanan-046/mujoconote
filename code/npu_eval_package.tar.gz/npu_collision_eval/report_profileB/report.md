# NPU 碰撞检测 —— 阶段级对比测评报告

```
timestamp: 2026-09-14T09:54:59
lanes: ['cpu_fp64', 'npu']
modes: ['free', 'hybrid']
nstep: 30
seeds: [0, 1, 2]
jitter: 0.0
```

## 总判定

**FAIL ❌ (693/1527 项)** — pass_rate = 0.546

| mode:stage | pass/total |
|---|---|
| free:S10 | 207/270 |
| free:S3 | 237/270 |
| free:S4 | 93/270 |
| free:S6 | 84/270 |
| free:S9 | 63/270 |
| hybrid:S9/S10 | 150/177 |

## 失败明细

| case | lane | stage | seed | step | 原因 |
|---|---|---|---|---|---|
| box_stack3 | npu | S4 | 0 | 1 | efc_pos_rel.p95=2.5 > 0.05 |
| box_stack3 | npu | S6 | 0 | 1 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 1 | qacc_linf=0.4745 > 0.01 ; qacc_rel_p95=2.623e+11 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 2 | efc_pos_rel.p95=2.126 > 0.05 |
| box_stack3 | npu | S6 | 0 | 2 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 2 | qacc_linf=0.66 > 0.01 ; qacc_rel_p95=30.47 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 3 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=1.154 > 0.05 |
| box_stack3 | npu | S6 | 0 | 3 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 3 | qacc_linf=0.7046 > 0.01 ; qacc_rel_p95=107.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 4 | efc_J_rel.p95=35.49 > 0.05 ; efc_pos_rel.p95=0.8112 > 0.05 |
| box_stack3 | npu | S6 | 0 | 4 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 4 | qacc_linf=0.6616 > 0.01 ; qacc_rel_p95=81.86 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 5 | efc_J_rel.p95=22.1 > 0.05 ; efc_pos_rel.p95=0.6389 > 0.05 |
| box_stack3 | npu | S6 | 0 | 5 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 5 | qacc_linf=0.618 > 0.01 ; qacc_rel_p95=127.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 6 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.5505 > 0.05 |
| box_stack3 | npu | S6 | 0 | 6 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 6 | qacc_linf=0.5735 > 0.01 ; qacc_rel_p95=269.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 7 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.4856 > 0.05 |
| box_stack3 | npu | S6 | 0 | 7 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 7 | qacc_linf=0.5282 > 0.01 ; qacc_rel_p95=298.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 8 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.4355 > 0.05 |
| box_stack3 | npu | S6 | 0 | 8 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 8 | qacc_linf=0.4824 > 0.01 ; qacc_rel_p95=2435 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 9 | efc_pos_rel.p95=0.3953 > 0.05 |
| box_stack3 | npu | S6 | 0 | 9 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 9 | qacc_linf=0.4363 > 0.01 ; qacc_rel_p95=50.11 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 10 | efc_pos_rel.p95=0.362 > 0.05 |
| box_stack3 | npu | S6 | 0 | 10 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 10 | qacc_linf=0.3902 > 0.01 ; qacc_rel_p95=61.36 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 11 | efc_J_rel.p95=0.05622 > 0.05 ; efc_pos_rel.p95=0.3338 > 0.05 |
| box_stack3 | npu | S6 | 0 | 11 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 11 | qacc_linf=0.3446 > 0.01 ; qacc_rel_p95=132 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 12 | efc_J_rel.p95=0.06492 > 0.05 ; efc_pos_rel.p95=0.3093 > 0.05 |
| box_stack3 | npu | S6 | 0 | 12 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 12 | qacc_linf=0.2996 > 0.01 ; qacc_rel_p95=94.02 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 13 | efc_J_rel.p95=0.07389 > 0.05 ; efc_pos_rel.p95=0.2876 > 0.05 |
| box_stack3 | npu | S6 | 0 | 13 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 13 | qacc_linf=0.2557 > 0.01 ; qacc_rel_p95=146.8 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 14 | efc_J_rel.p95=0.08308 > 0.05 ; efc_pos_rel.p95=0.2682 > 0.05 |
| box_stack3 | npu | S6 | 0 | 14 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 14 | qacc_linf=0.2132 > 0.01 ; qacc_rel_p95=192.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 15 | efc_J_rel.p95=0.09204 > 0.05 ; efc_pos_rel.p95=0.2505 > 0.05 |
| box_stack3 | npu | S6 | 0 | 15 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 15 | qacc_linf=0.1723 > 0.01 ; qacc_rel_p95=201.8 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 16 | efc_J_rel.p95=0.1012 > 0.05 ; efc_pos_rel.p95=0.2343 > 0.05 |
| box_stack3 | npu | S6 | 0 | 16 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 16 | qacc_linf=0.1332 > 0.01 ; qacc_rel_p95=113.4 > 0.05 |
| box_stack3 | npu | S4 | 0 | 17 | efc_J_rel.p95=0.1101 > 0.05 ; efc_pos_rel.p95=0.2192 > 0.05 |
| box_stack3 | npu | S6 | 0 | 17 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 17 | qacc_linf=0.09619 > 0.01 ; qacc_rel_p95=80.25 > 0.05 |
| box_stack3 | npu | S4 | 0 | 18 | efc_J_rel.p95=0.1255 > 0.05 ; efc_pos_rel.p95=0.205 > 0.05 |
| box_stack3 | npu | S6 | 0 | 18 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 18 | qacc_linf=0.06129 > 0.01 ; qacc_rel_p95=85.77 > 0.05 |
| box_stack3 | npu | S4 | 0 | 19 | efc_J_rel.p95=0.1428 > 0.05 ; efc_pos_rel.p95=0.1917 > 0.05 |
| box_stack3 | npu | S6 | 0 | 19 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 19 | qacc_linf=0.02863 > 0.01 ; qacc_rel_p95=91.6 > 0.05 |
| box_stack3 | npu | S4 | 0 | 20 | efc_J_rel.p95=0.1594 > 0.05 ; efc_pos_rel.p95=0.179 > 0.05 |
| box_stack3 | npu | S6 | 0 | 20 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 20 | qacc_linf=0.03278 > 0.01 ; qacc_rel_p95=97.84 > 0.05 |
| box_stack3 | npu | S4 | 0 | 21 | efc_J_rel.p95=0.1682 > 0.05 ; efc_pos_rel.p95=0.167 > 0.05 |
| box_stack3 | npu | S6 | 0 | 21 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 21 | qacc_linf=0.04852 > 0.01 ; qacc_rel_p95=104.6 > 0.05 |
| box_stack3 | npu | S4 | 0 | 22 | efc_J_rel.p95=0.1769 > 0.05 ; efc_pos_rel.p95=0.1555 > 0.05 |
| box_stack3 | npu | S6 | 0 | 22 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 22 | qacc_linf=0.06253 > 0.01 ; qacc_rel_p95=243.7 > 0.05 |
| box_stack3 | npu | S4 | 0 | 23 | efc_J_rel.p95=0.1856 > 0.05 ; efc_pos_rel.p95=0.1445 > 0.05 |
| box_stack3 | npu | S6 | 0 | 23 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 23 | qacc_linf=0.07871 > 0.01 ; qacc_rel_p95=120.4 > 0.05 |
| box_stack3 | npu | S4 | 0 | 24 | efc_J_rel.p95=0.1941 > 0.05 ; efc_pos_rel.p95=0.1339 > 0.05 |
| box_stack3 | npu | S6 | 0 | 24 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 24 | qacc_linf=0.09978 > 0.01 ; qacc_rel_p95=129.8 > 0.05 |
| box_stack3 | npu | S4 | 0 | 25 | efc_J_rel.p95=0.2026 > 0.05 ; efc_pos_rel.p95=0.1238 > 0.05 |
| box_stack3 | npu | S6 | 0 | 25 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 25 | qacc_linf=0.1186 > 0.01 ; qacc_rel_p95=198.7 > 0.05 |
| box_stack3 | npu | S4 | 0 | 26 | efc_J_rel.p95=0.2109 > 0.05 ; efc_pos_rel.p95=0.114 > 0.05 |
| box_stack3 | npu | S6 | 0 | 26 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 26 | qacc_linf=0.1354 > 0.01 ; qacc_rel_p95=410.8 > 0.05 |
| box_stack3 | npu | S4 | 0 | 27 | efc_J_rel.p95=0.2191 > 0.05 ; efc_pos_rel.p95=0.1047 > 0.05 |
| box_stack3 | npu | S6 | 0 | 27 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 27 | qacc_linf=0.15 > 0.01 ; qacc_rel_p95=502.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 28 | efc_J_rel.p95=0.227 > 0.05 ; efc_pos_rel.p95=0.09572 > 0.05 |
| box_stack3 | npu | S6 | 0 | 28 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 28 | qacc_linf=0.1627 > 0.01 ; qacc_rel_p95=449.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 0 | 29 | efc_J_rel.p95=0.2348 > 0.05 ; efc_pos_rel.p95=0.08712 > 0.05 |
| box_stack3 | npu | S6 | 0 | 29 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 0 | 29 | qacc_linf=0.1735 > 0.01 ; qacc_rel_p95=533.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 1 | efc_pos_rel.p95=2.5 > 0.05 |
| box_stack3 | npu | S6 | 1 | 1 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 1 | qacc_linf=0.4745 > 0.01 ; qacc_rel_p95=2.623e+11 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 2 | efc_pos_rel.p95=2.126 > 0.05 |
| box_stack3 | npu | S6 | 1 | 2 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 2 | qacc_linf=0.66 > 0.01 ; qacc_rel_p95=30.47 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 3 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=1.154 > 0.05 |
| box_stack3 | npu | S6 | 1 | 3 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 3 | qacc_linf=0.7046 > 0.01 ; qacc_rel_p95=107.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 4 | efc_J_rel.p95=35.49 > 0.05 ; efc_pos_rel.p95=0.8112 > 0.05 |
| box_stack3 | npu | S6 | 1 | 4 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 4 | qacc_linf=0.6616 > 0.01 ; qacc_rel_p95=81.86 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 5 | efc_J_rel.p95=22.1 > 0.05 ; efc_pos_rel.p95=0.6389 > 0.05 |
| box_stack3 | npu | S6 | 1 | 5 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 5 | qacc_linf=0.618 > 0.01 ; qacc_rel_p95=127.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 6 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.5505 > 0.05 |
| box_stack3 | npu | S6 | 1 | 6 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 6 | qacc_linf=0.5735 > 0.01 ; qacc_rel_p95=269.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 7 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.4856 > 0.05 |
| box_stack3 | npu | S6 | 1 | 7 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 7 | qacc_linf=0.5282 > 0.01 ; qacc_rel_p95=298.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 8 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.4355 > 0.05 |
| box_stack3 | npu | S6 | 1 | 8 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 8 | qacc_linf=0.4824 > 0.01 ; qacc_rel_p95=2435 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 9 | efc_pos_rel.p95=0.3953 > 0.05 |
| box_stack3 | npu | S6 | 1 | 9 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 9 | qacc_linf=0.4363 > 0.01 ; qacc_rel_p95=50.11 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 10 | efc_pos_rel.p95=0.362 > 0.05 |
| box_stack3 | npu | S6 | 1 | 10 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 10 | qacc_linf=0.3902 > 0.01 ; qacc_rel_p95=61.36 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 11 | efc_J_rel.p95=0.05622 > 0.05 ; efc_pos_rel.p95=0.3338 > 0.05 |
| box_stack3 | npu | S6 | 1 | 11 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 11 | qacc_linf=0.3446 > 0.01 ; qacc_rel_p95=132 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 12 | efc_J_rel.p95=0.06492 > 0.05 ; efc_pos_rel.p95=0.3093 > 0.05 |
| box_stack3 | npu | S6 | 1 | 12 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 12 | qacc_linf=0.2996 > 0.01 ; qacc_rel_p95=94.02 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 13 | efc_J_rel.p95=0.07389 > 0.05 ; efc_pos_rel.p95=0.2876 > 0.05 |
| box_stack3 | npu | S6 | 1 | 13 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 13 | qacc_linf=0.2557 > 0.01 ; qacc_rel_p95=146.8 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 14 | efc_J_rel.p95=0.08308 > 0.05 ; efc_pos_rel.p95=0.2682 > 0.05 |
| box_stack3 | npu | S6 | 1 | 14 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 14 | qacc_linf=0.2132 > 0.01 ; qacc_rel_p95=192.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 15 | efc_J_rel.p95=0.09204 > 0.05 ; efc_pos_rel.p95=0.2505 > 0.05 |
| box_stack3 | npu | S6 | 1 | 15 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 15 | qacc_linf=0.1723 > 0.01 ; qacc_rel_p95=201.8 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 16 | efc_J_rel.p95=0.1012 > 0.05 ; efc_pos_rel.p95=0.2343 > 0.05 |
| box_stack3 | npu | S6 | 1 | 16 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 16 | qacc_linf=0.1332 > 0.01 ; qacc_rel_p95=113.4 > 0.05 |
| box_stack3 | npu | S4 | 1 | 17 | efc_J_rel.p95=0.1101 > 0.05 ; efc_pos_rel.p95=0.2192 > 0.05 |
| box_stack3 | npu | S6 | 1 | 17 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 17 | qacc_linf=0.09619 > 0.01 ; qacc_rel_p95=80.25 > 0.05 |
| box_stack3 | npu | S4 | 1 | 18 | efc_J_rel.p95=0.1255 > 0.05 ; efc_pos_rel.p95=0.205 > 0.05 |
| box_stack3 | npu | S6 | 1 | 18 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 18 | qacc_linf=0.06129 > 0.01 ; qacc_rel_p95=85.77 > 0.05 |
| box_stack3 | npu | S4 | 1 | 19 | efc_J_rel.p95=0.1428 > 0.05 ; efc_pos_rel.p95=0.1917 > 0.05 |
| box_stack3 | npu | S6 | 1 | 19 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 19 | qacc_linf=0.02863 > 0.01 ; qacc_rel_p95=91.6 > 0.05 |
| box_stack3 | npu | S4 | 1 | 20 | efc_J_rel.p95=0.1594 > 0.05 ; efc_pos_rel.p95=0.179 > 0.05 |
| box_stack3 | npu | S6 | 1 | 20 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 20 | qacc_linf=0.03278 > 0.01 ; qacc_rel_p95=97.84 > 0.05 |
| box_stack3 | npu | S4 | 1 | 21 | efc_J_rel.p95=0.1682 > 0.05 ; efc_pos_rel.p95=0.167 > 0.05 |
| box_stack3 | npu | S6 | 1 | 21 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 21 | qacc_linf=0.04852 > 0.01 ; qacc_rel_p95=104.6 > 0.05 |
| box_stack3 | npu | S4 | 1 | 22 | efc_J_rel.p95=0.1769 > 0.05 ; efc_pos_rel.p95=0.1555 > 0.05 |
| box_stack3 | npu | S6 | 1 | 22 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 22 | qacc_linf=0.06253 > 0.01 ; qacc_rel_p95=243.7 > 0.05 |
| box_stack3 | npu | S4 | 1 | 23 | efc_J_rel.p95=0.1856 > 0.05 ; efc_pos_rel.p95=0.1445 > 0.05 |
| box_stack3 | npu | S6 | 1 | 23 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 23 | qacc_linf=0.07871 > 0.01 ; qacc_rel_p95=120.4 > 0.05 |
| box_stack3 | npu | S4 | 1 | 24 | efc_J_rel.p95=0.1941 > 0.05 ; efc_pos_rel.p95=0.1339 > 0.05 |
| box_stack3 | npu | S6 | 1 | 24 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 24 | qacc_linf=0.09978 > 0.01 ; qacc_rel_p95=129.8 > 0.05 |
| box_stack3 | npu | S4 | 1 | 25 | efc_J_rel.p95=0.2026 > 0.05 ; efc_pos_rel.p95=0.1238 > 0.05 |
| box_stack3 | npu | S6 | 1 | 25 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 25 | qacc_linf=0.1186 > 0.01 ; qacc_rel_p95=198.7 > 0.05 |
| box_stack3 | npu | S4 | 1 | 26 | efc_J_rel.p95=0.2109 > 0.05 ; efc_pos_rel.p95=0.114 > 0.05 |
| box_stack3 | npu | S6 | 1 | 26 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 26 | qacc_linf=0.1354 > 0.01 ; qacc_rel_p95=410.8 > 0.05 |
| box_stack3 | npu | S4 | 1 | 27 | efc_J_rel.p95=0.2191 > 0.05 ; efc_pos_rel.p95=0.1047 > 0.05 |
| box_stack3 | npu | S6 | 1 | 27 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 27 | qacc_linf=0.15 > 0.01 ; qacc_rel_p95=502.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 28 | efc_J_rel.p95=0.227 > 0.05 ; efc_pos_rel.p95=0.09572 > 0.05 |
| box_stack3 | npu | S6 | 1 | 28 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 28 | qacc_linf=0.1627 > 0.01 ; qacc_rel_p95=449.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 1 | 29 | efc_J_rel.p95=0.2348 > 0.05 ; efc_pos_rel.p95=0.08712 > 0.05 |
| box_stack3 | npu | S6 | 1 | 29 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 1 | 29 | qacc_linf=0.1735 > 0.01 ; qacc_rel_p95=533.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 1 | efc_pos_rel.p95=2.5 > 0.05 |
| box_stack3 | npu | S6 | 2 | 1 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 1 | qacc_linf=0.4745 > 0.01 ; qacc_rel_p95=2.623e+11 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 2 | efc_pos_rel.p95=2.126 > 0.05 |
| box_stack3 | npu | S6 | 2 | 2 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 2 | qacc_linf=0.66 > 0.01 ; qacc_rel_p95=30.47 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 3 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=1.154 > 0.05 |
| box_stack3 | npu | S6 | 2 | 3 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 3 | qacc_linf=0.7046 > 0.01 ; qacc_rel_p95=107.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 4 | efc_J_rel.p95=35.49 > 0.05 ; efc_pos_rel.p95=0.8112 > 0.05 |
| box_stack3 | npu | S6 | 2 | 4 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 4 | qacc_linf=0.6616 > 0.01 ; qacc_rel_p95=81.86 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 5 | efc_J_rel.p95=22.1 > 0.05 ; efc_pos_rel.p95=0.6389 > 0.05 |
| box_stack3 | npu | S6 | 2 | 5 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 5 | qacc_linf=0.618 > 0.01 ; qacc_rel_p95=127.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 6 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.5505 > 0.05 |
| box_stack3 | npu | S6 | 2 | 6 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 6 | qacc_linf=0.5735 > 0.01 ; qacc_rel_p95=269.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 7 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.4856 > 0.05 |
| box_stack3 | npu | S6 | 2 | 7 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 7 | qacc_linf=0.5282 > 0.01 ; qacc_rel_p95=298.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 8 | efc_J_rel.p95=2.042 > 0.05 ; efc_pos_rel.p95=0.4355 > 0.05 |
| box_stack3 | npu | S6 | 2 | 8 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 8 | qacc_linf=0.4824 > 0.01 ; qacc_rel_p95=2435 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 9 | efc_pos_rel.p95=0.3953 > 0.05 |
| box_stack3 | npu | S6 | 2 | 9 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 9 | qacc_linf=0.4363 > 0.01 ; qacc_rel_p95=50.11 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 10 | efc_pos_rel.p95=0.362 > 0.05 |
| box_stack3 | npu | S6 | 2 | 10 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 10 | qacc_linf=0.3902 > 0.01 ; qacc_rel_p95=61.36 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 11 | efc_J_rel.p95=0.05622 > 0.05 ; efc_pos_rel.p95=0.3338 > 0.05 |
| box_stack3 | npu | S6 | 2 | 11 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 11 | qacc_linf=0.3446 > 0.01 ; qacc_rel_p95=132 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 12 | efc_J_rel.p95=0.06492 > 0.05 ; efc_pos_rel.p95=0.3093 > 0.05 |
| box_stack3 | npu | S6 | 2 | 12 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 12 | qacc_linf=0.2996 > 0.01 ; qacc_rel_p95=94.02 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 13 | efc_J_rel.p95=0.07389 > 0.05 ; efc_pos_rel.p95=0.2876 > 0.05 |
| box_stack3 | npu | S6 | 2 | 13 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 13 | qacc_linf=0.2557 > 0.01 ; qacc_rel_p95=146.8 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 14 | efc_J_rel.p95=0.08308 > 0.05 ; efc_pos_rel.p95=0.2682 > 0.05 |
| box_stack3 | npu | S6 | 2 | 14 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 14 | qacc_linf=0.2132 > 0.01 ; qacc_rel_p95=192.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 15 | efc_J_rel.p95=0.09204 > 0.05 ; efc_pos_rel.p95=0.2505 > 0.05 |
| box_stack3 | npu | S6 | 2 | 15 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 15 | qacc_linf=0.1723 > 0.01 ; qacc_rel_p95=201.8 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 16 | efc_J_rel.p95=0.1012 > 0.05 ; efc_pos_rel.p95=0.2343 > 0.05 |
| box_stack3 | npu | S6 | 2 | 16 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 16 | qacc_linf=0.1332 > 0.01 ; qacc_rel_p95=113.4 > 0.05 |
| box_stack3 | npu | S4 | 2 | 17 | efc_J_rel.p95=0.1101 > 0.05 ; efc_pos_rel.p95=0.2192 > 0.05 |
| box_stack3 | npu | S6 | 2 | 17 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 17 | qacc_linf=0.09619 > 0.01 ; qacc_rel_p95=80.25 > 0.05 |
| box_stack3 | npu | S4 | 2 | 18 | efc_J_rel.p95=0.1255 > 0.05 ; efc_pos_rel.p95=0.205 > 0.05 |
| box_stack3 | npu | S6 | 2 | 18 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 18 | qacc_linf=0.06129 > 0.01 ; qacc_rel_p95=85.77 > 0.05 |
| box_stack3 | npu | S4 | 2 | 19 | efc_J_rel.p95=0.1428 > 0.05 ; efc_pos_rel.p95=0.1917 > 0.05 |
| box_stack3 | npu | S6 | 2 | 19 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 19 | qacc_linf=0.02863 > 0.01 ; qacc_rel_p95=91.6 > 0.05 |
| box_stack3 | npu | S4 | 2 | 20 | efc_J_rel.p95=0.1594 > 0.05 ; efc_pos_rel.p95=0.179 > 0.05 |
| box_stack3 | npu | S6 | 2 | 20 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 20 | qacc_linf=0.03278 > 0.01 ; qacc_rel_p95=97.84 > 0.05 |
| box_stack3 | npu | S4 | 2 | 21 | efc_J_rel.p95=0.1682 > 0.05 ; efc_pos_rel.p95=0.167 > 0.05 |
| box_stack3 | npu | S6 | 2 | 21 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 21 | qacc_linf=0.04852 > 0.01 ; qacc_rel_p95=104.6 > 0.05 |
| box_stack3 | npu | S4 | 2 | 22 | efc_J_rel.p95=0.1769 > 0.05 ; efc_pos_rel.p95=0.1555 > 0.05 |
| box_stack3 | npu | S6 | 2 | 22 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 22 | qacc_linf=0.06253 > 0.01 ; qacc_rel_p95=243.7 > 0.05 |
| box_stack3 | npu | S4 | 2 | 23 | efc_J_rel.p95=0.1856 > 0.05 ; efc_pos_rel.p95=0.1445 > 0.05 |
| box_stack3 | npu | S6 | 2 | 23 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 23 | qacc_linf=0.07871 > 0.01 ; qacc_rel_p95=120.4 > 0.05 |
| box_stack3 | npu | S4 | 2 | 24 | efc_J_rel.p95=0.1941 > 0.05 ; efc_pos_rel.p95=0.1339 > 0.05 |
| box_stack3 | npu | S6 | 2 | 24 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 24 | qacc_linf=0.09978 > 0.01 ; qacc_rel_p95=129.8 > 0.05 |
| box_stack3 | npu | S4 | 2 | 25 | efc_J_rel.p95=0.2026 > 0.05 ; efc_pos_rel.p95=0.1238 > 0.05 |
| box_stack3 | npu | S6 | 2 | 25 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 25 | qacc_linf=0.1186 > 0.01 ; qacc_rel_p95=198.7 > 0.05 |
| box_stack3 | npu | S4 | 2 | 26 | efc_J_rel.p95=0.2109 > 0.05 ; efc_pos_rel.p95=0.114 > 0.05 |
| box_stack3 | npu | S6 | 2 | 26 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 26 | qacc_linf=0.1354 > 0.01 ; qacc_rel_p95=410.8 > 0.05 |
| box_stack3 | npu | S4 | 2 | 27 | efc_J_rel.p95=0.2191 > 0.05 ; efc_pos_rel.p95=0.1047 > 0.05 |
| box_stack3 | npu | S6 | 2 | 27 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 27 | qacc_linf=0.15 > 0.01 ; qacc_rel_p95=502.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 28 | efc_J_rel.p95=0.227 > 0.05 ; efc_pos_rel.p95=0.09572 > 0.05 |
| box_stack3 | npu | S6 | 2 | 28 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 28 | qacc_linf=0.1627 > 0.01 ; qacc_rel_p95=449.7 > 0.05 ; efc_force_rel.p95 > 0.05 |
| box_stack3 | npu | S4 | 2 | 29 | efc_J_rel.p95=0.2348 > 0.05 ; efc_pos_rel.p95=0.08712 > 0.05 |
| box_stack3 | npu | S6 | 2 | 29 | efc_aref_rel.p95 > 0.05 |
| box_stack3 | npu | S9 | 2 | 29 | qacc_linf=0.1735 > 0.01 ; qacc_rel_p95=533.9 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 0 | qacc_linf=0.4137 > 0.01 ; qacc_rel_p95=1.23e+05 > 0.05 |
| spheres_20 | npu | S4 | 0 | 1 | efc_pos_rel.p95=2.451 > 0.05 |
| spheres_20 | npu | S6 | 0 | 1 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 1 | qacc_linf=1.754 > 0.01 ; qacc_rel_p95=0.2362 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 0 | 2 | efc_pos_rel.p95=1.878 > 0.05 |
| spheres_20 | npu | S6 | 0 | 2 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 2 | qacc_linf=2.596 > 0.01 ; qacc_rel_p95=0.1687 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 0 | 3 | efc_pos_rel.p95=1.646 > 0.05 |
| spheres_20 | npu | S6 | 0 | 3 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 3 | qacc_linf=2.041 > 0.01 ; qacc_rel_p95=0.1132 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 0 | 4 | efc_pos_rel.p95=2.542 > 0.05 |
| spheres_20 | npu | S6 | 0 | 4 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 4 | qacc_linf=2.399 > 0.01 ; qacc_rel_p95=0.08074 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 0 | 5 | efc_pos_rel.p95=3.096 > 0.05 |
| spheres_20 | npu | S6 | 0 | 5 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 5 | qacc_linf=2.145 > 0.01 ; qacc_rel_p95=0.06099 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 0 | 6 | efc_pos_rel.p95=2.888 > 0.05 |
| spheres_20 | npu | S6 | 0 | 6 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 6 | qacc_linf=2.036 > 0.01 ; qacc_rel_p95=0.09497 > 0.05 |
| spheres_20 | npu | S4 | 0 | 7 | efc_pos_rel.p95=2.282 > 0.05 |
| spheres_20 | npu | S6 | 0 | 7 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 7 | qacc_linf=1.753 > 0.01 ; qacc_rel_p95=0.07575 > 0.05 |
| spheres_20 | npu | S4 | 0 | 8 | efc_pos_rel.p95=1.914 > 0.05 |
| spheres_20 | npu | S6 | 0 | 8 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 8 | qacc_linf=2.27 > 0.01 ; qacc_rel_p95=0.07551 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S3 | 0 | 9 | ncon mismatch ref=31 test=32 ; spurious_rate=0.03125 > 0.02 |
| spheres_20 | npu | S4 | 0 | 9 | nefc mismatch ref=124 test=128 |
| spheres_20 | npu | S9 | 0 | 9 | qacc_linf=84.12 > 0.01 ; qacc_rel_p95=0.8202 > 0.05 |
| spheres_20 | npu | S10 | 0 | 9 | qvel_linf=0.1653 > 0.05 |
| spheres_20 | npu | S4 | 0 | 10 | efc_pos_rel.p95=1.129 > 0.05 |
| spheres_20 | npu | S6 | 0 | 10 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 10 | qacc_linf=11.37 > 0.01 ; qacc_rel_p95=0.1152 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 0 | 10 | qvel_linf=0.1425 > 0.05 |
| spheres_20 | npu | S4 | 0 | 11 | efc_pos_rel.p95=0.999 > 0.05 |
| spheres_20 | npu | S6 | 0 | 11 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 11 | qacc_linf=9.608 > 0.01 ; qacc_rel_p95=0.1223 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 0 | 11 | qvel_linf=0.1233 > 0.05 |
| spheres_20 | npu | S4 | 0 | 12 | efc_pos_rel.p95=1.276 > 0.05 |
| spheres_20 | npu | S6 | 0 | 12 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 12 | qacc_linf=8.115 > 0.01 ; qacc_rel_p95=0.1425 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 0 | 12 | qvel_linf=0.1083 > 0.05 |
| spheres_20 | npu | S4 | 0 | 13 | efc_pos_rel.p95=1.224 > 0.05 |
| spheres_20 | npu | S6 | 0 | 13 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 13 | qacc_linf=6.865 > 0.01 ; qacc_rel_p95=0.1556 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 0 | 13 | qvel_linf=0.09711 > 0.05 |
| spheres_20 | npu | S4 | 0 | 14 | efc_pos_rel.p95=1.147 > 0.05 |
| spheres_20 | npu | S6 | 0 | 14 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 14 | qacc_linf=5.824 > 0.01 ; qacc_rel_p95=0.1722 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 0 | 14 | qvel_linf=0.08764 > 0.05 |
| spheres_20 | npu | S4 | 0 | 15 | efc_pos_rel.p95=1.378 > 0.05 |
| spheres_20 | npu | S6 | 0 | 15 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 15 | qacc_linf=4.966 > 0.01 ; qacc_rel_p95=0.1826 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 0 | 15 | qvel_linf=0.07956 > 0.05 |
| spheres_20 | npu | S3 | 0 | 16 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 0 | 16 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 0 | 16 | qacc_linf=80.3 > 0.01 ; qacc_rel_p95=0.67 > 0.05 |
| spheres_20 | npu | S10 | 0 | 16 | qvel_linf=0.1917 > 0.05 |
| spheres_20 | npu | S3 | 0 | 17 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 0 | 17 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 0 | 17 | qacc_linf=80.22 > 0.01 ; qacc_rel_p95=0.6894 > 0.05 |
| spheres_20 | npu | S10 | 0 | 17 | qvel_linf=0.3522 > 0.05 |
| spheres_20 | npu | S4 | 0 | 18 | efc_pos_rel.p95=1.503 > 0.05 |
| spheres_20 | npu | S6 | 0 | 18 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 18 | qacc_linf=3.953 > 0.01 ; qacc_rel_p95=0.2385 > 0.05 |
| spheres_20 | npu | S10 | 0 | 18 | qvel_linf=0.3463 > 0.05 |
| spheres_20 | npu | S4 | 0 | 19 | efc_pos_rel.p95=1.323 > 0.05 |
| spheres_20 | npu | S6 | 0 | 19 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 19 | qacc_linf=3.621 > 0.01 ; qacc_rel_p95=0.2068 > 0.05 |
| spheres_20 | npu | S10 | 0 | 19 | qvel_linf=0.3414 > 0.05 |
| spheres_20 | npu | S4 | 0 | 20 | efc_pos_rel.p95=1.058 > 0.05 |
| spheres_20 | npu | S6 | 0 | 20 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 20 | qacc_linf=3.37 > 0.01 ; qacc_rel_p95=0.155 > 0.05 |
| spheres_20 | npu | S10 | 0 | 20 | qvel_linf=0.3373 > 0.05 |
| spheres_20 | npu | S4 | 0 | 21 | efc_pos_rel.p95=0.7968 > 0.05 |
| spheres_20 | npu | S6 | 0 | 21 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 21 | qacc_linf=3.188 > 0.01 ; qacc_rel_p95=0.1691 > 0.05 |
| spheres_20 | npu | S10 | 0 | 21 | qvel_linf=0.3338 > 0.05 |
| spheres_20 | npu | S3 | 0 | 22 | missed_rate=0.0645 > 0.0 ; ncon mismatch ref=31 test=29 |
| spheres_20 | npu | S4 | 0 | 22 | nefc mismatch ref=124 test=116 |
| spheres_20 | npu | S9 | 0 | 22 | qacc_linf=191.5 > 0.01 ; qacc_rel_p95=1.465 > 0.05 |
| spheres_20 | npu | S10 | 0 | 22 | qvel_linf=0.129 > 0.05 |
| spheres_20 | npu | S3 | 0 | 23 | missed_rate=0.0645 > 0.0 ; ncon mismatch ref=31 test=29 |
| spheres_20 | npu | S4 | 0 | 23 | nefc mismatch ref=124 test=116 |
| spheres_20 | npu | S9 | 0 | 23 | qacc_linf=170.9 > 0.01 ; qacc_rel_p95=1.051 > 0.05 |
| spheres_20 | npu | S10 | 0 | 23 | qvel_linf=0.467 > 0.05 |
| spheres_20 | npu | S3 | 0 | 24 | missed_rate=0.0323 > 0.0 ; ncon mismatch ref=31 test=30 |
| spheres_20 | npu | S4 | 0 | 24 | nefc mismatch ref=124 test=120 |
| spheres_20 | npu | S9 | 0 | 24 | qacc_linf=14.37 > 0.01 ; qacc_rel_p95=0.5676 > 0.05 |
| spheres_20 | npu | S10 | 0 | 24 | qvel_linf=0.4831 > 0.05 |
| spheres_20 | npu | S3 | 0 | 25 | missed_rate=0.0323 > 0.0 ; ncon mismatch ref=31 test=30 |
| spheres_20 | npu | S4 | 0 | 25 | nefc mismatch ref=124 test=120 |
| spheres_20 | npu | S9 | 0 | 25 | qacc_linf=13.72 > 0.01 ; qacc_rel_p95=0.5622 > 0.05 |
| spheres_20 | npu | S10 | 0 | 25 | qvel_linf=0.491 > 0.05 |
| spheres_20 | npu | S3 | 0 | 26 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 0 | 26 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 0 | 26 | qacc_linf=146 > 0.01 ; qacc_rel_p95=1.31 > 0.05 |
| spheres_20 | npu | S10 | 0 | 26 | qvel_linf=0.227 > 0.05 |
| spheres_20 | npu | S3 | 0 | 27 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 0 | 27 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 0 | 27 | qacc_linf=133.9 > 0.01 ; qacc_rel_p95=1.497 > 0.05 |
| spheres_20 | npu | S10 | 0 | 27 | qvel_linf=0.2245 > 0.05 |
| spheres_20 | npu | S3 | 0 | 28 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 0 | 28 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 0 | 28 | qacc_linf=123.7 > 0.01 ; qacc_rel_p95=1.83 > 0.05 |
| spheres_20 | npu | S10 | 0 | 28 | qvel_linf=0.4718 > 0.05 |
| spheres_20 | npu | S4 | 0 | 29 | efc_pos_rel.p95=0.1866 > 0.05 |
| spheres_20 | npu | S6 | 0 | 29 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 0 | 29 | qacc_linf=8.976 > 0.01 ; qacc_rel_p95=0.7225 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 0 | 29 | qvel_linf=0.4538 > 0.05 |
| spheres_20 | npu | S9 | 1 | 0 | qacc_linf=0.4137 > 0.01 ; qacc_rel_p95=1.23e+05 > 0.05 |
| spheres_20 | npu | S4 | 1 | 1 | efc_pos_rel.p95=2.451 > 0.05 |
| spheres_20 | npu | S6 | 1 | 1 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 1 | qacc_linf=1.754 > 0.01 ; qacc_rel_p95=0.2362 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 1 | 2 | efc_pos_rel.p95=1.878 > 0.05 |
| spheres_20 | npu | S6 | 1 | 2 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 2 | qacc_linf=2.596 > 0.01 ; qacc_rel_p95=0.1687 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 1 | 3 | efc_pos_rel.p95=1.646 > 0.05 |
| spheres_20 | npu | S6 | 1 | 3 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 3 | qacc_linf=2.041 > 0.01 ; qacc_rel_p95=0.1132 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 1 | 4 | efc_pos_rel.p95=2.542 > 0.05 |
| spheres_20 | npu | S6 | 1 | 4 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 4 | qacc_linf=2.399 > 0.01 ; qacc_rel_p95=0.08074 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 1 | 5 | efc_pos_rel.p95=3.096 > 0.05 |
| spheres_20 | npu | S6 | 1 | 5 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 5 | qacc_linf=2.145 > 0.01 ; qacc_rel_p95=0.06099 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 1 | 6 | efc_pos_rel.p95=2.888 > 0.05 |
| spheres_20 | npu | S6 | 1 | 6 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 6 | qacc_linf=2.036 > 0.01 ; qacc_rel_p95=0.09497 > 0.05 |
| spheres_20 | npu | S4 | 1 | 7 | efc_pos_rel.p95=2.282 > 0.05 |
| spheres_20 | npu | S6 | 1 | 7 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 7 | qacc_linf=1.753 > 0.01 ; qacc_rel_p95=0.07575 > 0.05 |
| spheres_20 | npu | S4 | 1 | 8 | efc_pos_rel.p95=1.914 > 0.05 |
| spheres_20 | npu | S6 | 1 | 8 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 8 | qacc_linf=2.27 > 0.01 ; qacc_rel_p95=0.07551 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S3 | 1 | 9 | ncon mismatch ref=31 test=32 ; spurious_rate=0.03125 > 0.02 |
| spheres_20 | npu | S4 | 1 | 9 | nefc mismatch ref=124 test=128 |
| spheres_20 | npu | S9 | 1 | 9 | qacc_linf=84.12 > 0.01 ; qacc_rel_p95=0.8202 > 0.05 |
| spheres_20 | npu | S10 | 1 | 9 | qvel_linf=0.1653 > 0.05 |
| spheres_20 | npu | S4 | 1 | 10 | efc_pos_rel.p95=1.129 > 0.05 |
| spheres_20 | npu | S6 | 1 | 10 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 10 | qacc_linf=11.37 > 0.01 ; qacc_rel_p95=0.1152 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 1 | 10 | qvel_linf=0.1425 > 0.05 |
| spheres_20 | npu | S4 | 1 | 11 | efc_pos_rel.p95=0.999 > 0.05 |
| spheres_20 | npu | S6 | 1 | 11 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 11 | qacc_linf=9.608 > 0.01 ; qacc_rel_p95=0.1223 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 1 | 11 | qvel_linf=0.1233 > 0.05 |
| spheres_20 | npu | S4 | 1 | 12 | efc_pos_rel.p95=1.276 > 0.05 |
| spheres_20 | npu | S6 | 1 | 12 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 12 | qacc_linf=8.115 > 0.01 ; qacc_rel_p95=0.1425 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 1 | 12 | qvel_linf=0.1083 > 0.05 |
| spheres_20 | npu | S4 | 1 | 13 | efc_pos_rel.p95=1.224 > 0.05 |
| spheres_20 | npu | S6 | 1 | 13 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 13 | qacc_linf=6.865 > 0.01 ; qacc_rel_p95=0.1556 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 1 | 13 | qvel_linf=0.09711 > 0.05 |
| spheres_20 | npu | S4 | 1 | 14 | efc_pos_rel.p95=1.147 > 0.05 |
| spheres_20 | npu | S6 | 1 | 14 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 14 | qacc_linf=5.824 > 0.01 ; qacc_rel_p95=0.1722 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 1 | 14 | qvel_linf=0.08764 > 0.05 |
| spheres_20 | npu | S4 | 1 | 15 | efc_pos_rel.p95=1.378 > 0.05 |
| spheres_20 | npu | S6 | 1 | 15 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 15 | qacc_linf=4.966 > 0.01 ; qacc_rel_p95=0.1826 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 1 | 15 | qvel_linf=0.07956 > 0.05 |
| spheres_20 | npu | S3 | 1 | 16 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 1 | 16 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 1 | 16 | qacc_linf=80.3 > 0.01 ; qacc_rel_p95=0.67 > 0.05 |
| spheres_20 | npu | S10 | 1 | 16 | qvel_linf=0.1917 > 0.05 |
| spheres_20 | npu | S3 | 1 | 17 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 1 | 17 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 1 | 17 | qacc_linf=80.22 > 0.01 ; qacc_rel_p95=0.6894 > 0.05 |
| spheres_20 | npu | S10 | 1 | 17 | qvel_linf=0.3522 > 0.05 |
| spheres_20 | npu | S4 | 1 | 18 | efc_pos_rel.p95=1.503 > 0.05 |
| spheres_20 | npu | S6 | 1 | 18 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 18 | qacc_linf=3.953 > 0.01 ; qacc_rel_p95=0.2385 > 0.05 |
| spheres_20 | npu | S10 | 1 | 18 | qvel_linf=0.3463 > 0.05 |
| spheres_20 | npu | S4 | 1 | 19 | efc_pos_rel.p95=1.323 > 0.05 |
| spheres_20 | npu | S6 | 1 | 19 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 19 | qacc_linf=3.621 > 0.01 ; qacc_rel_p95=0.2068 > 0.05 |
| spheres_20 | npu | S10 | 1 | 19 | qvel_linf=0.3414 > 0.05 |
| spheres_20 | npu | S4 | 1 | 20 | efc_pos_rel.p95=1.058 > 0.05 |
| spheres_20 | npu | S6 | 1 | 20 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 20 | qacc_linf=3.37 > 0.01 ; qacc_rel_p95=0.155 > 0.05 |
| spheres_20 | npu | S10 | 1 | 20 | qvel_linf=0.3373 > 0.05 |
| spheres_20 | npu | S4 | 1 | 21 | efc_pos_rel.p95=0.7968 > 0.05 |
| spheres_20 | npu | S6 | 1 | 21 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 21 | qacc_linf=3.188 > 0.01 ; qacc_rel_p95=0.1691 > 0.05 |
| spheres_20 | npu | S10 | 1 | 21 | qvel_linf=0.3338 > 0.05 |
| spheres_20 | npu | S3 | 1 | 22 | missed_rate=0.0645 > 0.0 ; ncon mismatch ref=31 test=29 |
| spheres_20 | npu | S4 | 1 | 22 | nefc mismatch ref=124 test=116 |
| spheres_20 | npu | S9 | 1 | 22 | qacc_linf=191.5 > 0.01 ; qacc_rel_p95=1.465 > 0.05 |
| spheres_20 | npu | S10 | 1 | 22 | qvel_linf=0.129 > 0.05 |
| spheres_20 | npu | S3 | 1 | 23 | missed_rate=0.0645 > 0.0 ; ncon mismatch ref=31 test=29 |
| spheres_20 | npu | S4 | 1 | 23 | nefc mismatch ref=124 test=116 |
| spheres_20 | npu | S9 | 1 | 23 | qacc_linf=170.9 > 0.01 ; qacc_rel_p95=1.051 > 0.05 |
| spheres_20 | npu | S10 | 1 | 23 | qvel_linf=0.467 > 0.05 |
| spheres_20 | npu | S3 | 1 | 24 | missed_rate=0.0323 > 0.0 ; ncon mismatch ref=31 test=30 |
| spheres_20 | npu | S4 | 1 | 24 | nefc mismatch ref=124 test=120 |
| spheres_20 | npu | S9 | 1 | 24 | qacc_linf=14.37 > 0.01 ; qacc_rel_p95=0.5676 > 0.05 |
| spheres_20 | npu | S10 | 1 | 24 | qvel_linf=0.4831 > 0.05 |
| spheres_20 | npu | S3 | 1 | 25 | missed_rate=0.0323 > 0.0 ; ncon mismatch ref=31 test=30 |
| spheres_20 | npu | S4 | 1 | 25 | nefc mismatch ref=124 test=120 |
| spheres_20 | npu | S9 | 1 | 25 | qacc_linf=13.72 > 0.01 ; qacc_rel_p95=0.5622 > 0.05 |
| spheres_20 | npu | S10 | 1 | 25 | qvel_linf=0.491 > 0.05 |
| spheres_20 | npu | S3 | 1 | 26 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 1 | 26 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 1 | 26 | qacc_linf=146 > 0.01 ; qacc_rel_p95=1.31 > 0.05 |
| spheres_20 | npu | S10 | 1 | 26 | qvel_linf=0.227 > 0.05 |
| spheres_20 | npu | S3 | 1 | 27 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 1 | 27 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 1 | 27 | qacc_linf=133.9 > 0.01 ; qacc_rel_p95=1.497 > 0.05 |
| spheres_20 | npu | S10 | 1 | 27 | qvel_linf=0.2245 > 0.05 |
| spheres_20 | npu | S3 | 1 | 28 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 1 | 28 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 1 | 28 | qacc_linf=123.7 > 0.01 ; qacc_rel_p95=1.83 > 0.05 |
| spheres_20 | npu | S10 | 1 | 28 | qvel_linf=0.4718 > 0.05 |
| spheres_20 | npu | S4 | 1 | 29 | efc_pos_rel.p95=0.1866 > 0.05 |
| spheres_20 | npu | S6 | 1 | 29 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 1 | 29 | qacc_linf=8.976 > 0.01 ; qacc_rel_p95=0.7225 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 1 | 29 | qvel_linf=0.4538 > 0.05 |
| spheres_20 | npu | S9 | 2 | 0 | qacc_linf=0.4137 > 0.01 ; qacc_rel_p95=1.23e+05 > 0.05 |
| spheres_20 | npu | S4 | 2 | 1 | efc_pos_rel.p95=2.451 > 0.05 |
| spheres_20 | npu | S6 | 2 | 1 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 1 | qacc_linf=1.754 > 0.01 ; qacc_rel_p95=0.2362 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 2 | 2 | efc_pos_rel.p95=1.878 > 0.05 |
| spheres_20 | npu | S6 | 2 | 2 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 2 | qacc_linf=2.596 > 0.01 ; qacc_rel_p95=0.1687 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 2 | 3 | efc_pos_rel.p95=1.646 > 0.05 |
| spheres_20 | npu | S6 | 2 | 3 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 3 | qacc_linf=2.041 > 0.01 ; qacc_rel_p95=0.1132 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 2 | 4 | efc_pos_rel.p95=2.542 > 0.05 |
| spheres_20 | npu | S6 | 2 | 4 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 4 | qacc_linf=2.399 > 0.01 ; qacc_rel_p95=0.08074 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 2 | 5 | efc_pos_rel.p95=3.096 > 0.05 |
| spheres_20 | npu | S6 | 2 | 5 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 5 | qacc_linf=2.145 > 0.01 ; qacc_rel_p95=0.06099 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S4 | 2 | 6 | efc_pos_rel.p95=2.888 > 0.05 |
| spheres_20 | npu | S6 | 2 | 6 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 6 | qacc_linf=2.036 > 0.01 ; qacc_rel_p95=0.09497 > 0.05 |
| spheres_20 | npu | S4 | 2 | 7 | efc_pos_rel.p95=2.282 > 0.05 |
| spheres_20 | npu | S6 | 2 | 7 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 7 | qacc_linf=1.753 > 0.01 ; qacc_rel_p95=0.07575 > 0.05 |
| spheres_20 | npu | S4 | 2 | 8 | efc_pos_rel.p95=1.914 > 0.05 |
| spheres_20 | npu | S6 | 2 | 8 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 8 | qacc_linf=2.27 > 0.01 ; qacc_rel_p95=0.07551 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S3 | 2 | 9 | ncon mismatch ref=31 test=32 ; spurious_rate=0.03125 > 0.02 |
| spheres_20 | npu | S4 | 2 | 9 | nefc mismatch ref=124 test=128 |
| spheres_20 | npu | S9 | 2 | 9 | qacc_linf=84.12 > 0.01 ; qacc_rel_p95=0.8202 > 0.05 |
| spheres_20 | npu | S10 | 2 | 9 | qvel_linf=0.1653 > 0.05 |
| spheres_20 | npu | S4 | 2 | 10 | efc_pos_rel.p95=1.129 > 0.05 |
| spheres_20 | npu | S6 | 2 | 10 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 10 | qacc_linf=11.37 > 0.01 ; qacc_rel_p95=0.1152 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 2 | 10 | qvel_linf=0.1425 > 0.05 |
| spheres_20 | npu | S4 | 2 | 11 | efc_pos_rel.p95=0.999 > 0.05 |
| spheres_20 | npu | S6 | 2 | 11 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 11 | qacc_linf=9.608 > 0.01 ; qacc_rel_p95=0.1223 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 2 | 11 | qvel_linf=0.1233 > 0.05 |
| spheres_20 | npu | S4 | 2 | 12 | efc_pos_rel.p95=1.276 > 0.05 |
| spheres_20 | npu | S6 | 2 | 12 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 12 | qacc_linf=8.115 > 0.01 ; qacc_rel_p95=0.1425 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 2 | 12 | qvel_linf=0.1083 > 0.05 |
| spheres_20 | npu | S4 | 2 | 13 | efc_pos_rel.p95=1.224 > 0.05 |
| spheres_20 | npu | S6 | 2 | 13 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 13 | qacc_linf=6.865 > 0.01 ; qacc_rel_p95=0.1556 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 2 | 13 | qvel_linf=0.09711 > 0.05 |
| spheres_20 | npu | S4 | 2 | 14 | efc_pos_rel.p95=1.147 > 0.05 |
| spheres_20 | npu | S6 | 2 | 14 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 14 | qacc_linf=5.824 > 0.01 ; qacc_rel_p95=0.1722 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 2 | 14 | qvel_linf=0.08764 > 0.05 |
| spheres_20 | npu | S4 | 2 | 15 | efc_pos_rel.p95=1.378 > 0.05 |
| spheres_20 | npu | S6 | 2 | 15 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 15 | qacc_linf=4.966 > 0.01 ; qacc_rel_p95=0.1826 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 2 | 15 | qvel_linf=0.07956 > 0.05 |
| spheres_20 | npu | S3 | 2 | 16 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 2 | 16 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 2 | 16 | qacc_linf=80.3 > 0.01 ; qacc_rel_p95=0.67 > 0.05 |
| spheres_20 | npu | S10 | 2 | 16 | qvel_linf=0.1917 > 0.05 |
| spheres_20 | npu | S3 | 2 | 17 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 2 | 17 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 2 | 17 | qacc_linf=80.22 > 0.01 ; qacc_rel_p95=0.6894 > 0.05 |
| spheres_20 | npu | S10 | 2 | 17 | qvel_linf=0.3522 > 0.05 |
| spheres_20 | npu | S4 | 2 | 18 | efc_pos_rel.p95=1.503 > 0.05 |
| spheres_20 | npu | S6 | 2 | 18 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 18 | qacc_linf=3.953 > 0.01 ; qacc_rel_p95=0.2385 > 0.05 |
| spheres_20 | npu | S10 | 2 | 18 | qvel_linf=0.3463 > 0.05 |
| spheres_20 | npu | S4 | 2 | 19 | efc_pos_rel.p95=1.323 > 0.05 |
| spheres_20 | npu | S6 | 2 | 19 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 19 | qacc_linf=3.621 > 0.01 ; qacc_rel_p95=0.2068 > 0.05 |
| spheres_20 | npu | S10 | 2 | 19 | qvel_linf=0.3414 > 0.05 |
| spheres_20 | npu | S4 | 2 | 20 | efc_pos_rel.p95=1.058 > 0.05 |
| spheres_20 | npu | S6 | 2 | 20 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 20 | qacc_linf=3.37 > 0.01 ; qacc_rel_p95=0.155 > 0.05 |
| spheres_20 | npu | S10 | 2 | 20 | qvel_linf=0.3373 > 0.05 |
| spheres_20 | npu | S4 | 2 | 21 | efc_pos_rel.p95=0.7968 > 0.05 |
| spheres_20 | npu | S6 | 2 | 21 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 21 | qacc_linf=3.188 > 0.01 ; qacc_rel_p95=0.1691 > 0.05 |
| spheres_20 | npu | S10 | 2 | 21 | qvel_linf=0.3338 > 0.05 |
| spheres_20 | npu | S3 | 2 | 22 | missed_rate=0.0645 > 0.0 ; ncon mismatch ref=31 test=29 |
| spheres_20 | npu | S4 | 2 | 22 | nefc mismatch ref=124 test=116 |
| spheres_20 | npu | S9 | 2 | 22 | qacc_linf=191.5 > 0.01 ; qacc_rel_p95=1.465 > 0.05 |
| spheres_20 | npu | S10 | 2 | 22 | qvel_linf=0.129 > 0.05 |
| spheres_20 | npu | S3 | 2 | 23 | missed_rate=0.0645 > 0.0 ; ncon mismatch ref=31 test=29 |
| spheres_20 | npu | S4 | 2 | 23 | nefc mismatch ref=124 test=116 |
| spheres_20 | npu | S9 | 2 | 23 | qacc_linf=170.9 > 0.01 ; qacc_rel_p95=1.051 > 0.05 |
| spheres_20 | npu | S10 | 2 | 23 | qvel_linf=0.467 > 0.05 |
| spheres_20 | npu | S3 | 2 | 24 | missed_rate=0.0323 > 0.0 ; ncon mismatch ref=31 test=30 |
| spheres_20 | npu | S4 | 2 | 24 | nefc mismatch ref=124 test=120 |
| spheres_20 | npu | S9 | 2 | 24 | qacc_linf=14.37 > 0.01 ; qacc_rel_p95=0.5676 > 0.05 |
| spheres_20 | npu | S10 | 2 | 24 | qvel_linf=0.4831 > 0.05 |
| spheres_20 | npu | S3 | 2 | 25 | missed_rate=0.0323 > 0.0 ; ncon mismatch ref=31 test=30 |
| spheres_20 | npu | S4 | 2 | 25 | nefc mismatch ref=124 test=120 |
| spheres_20 | npu | S9 | 2 | 25 | qacc_linf=13.72 > 0.01 ; qacc_rel_p95=0.5622 > 0.05 |
| spheres_20 | npu | S10 | 2 | 25 | qvel_linf=0.491 > 0.05 |
| spheres_20 | npu | S3 | 2 | 26 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 2 | 26 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 2 | 26 | qacc_linf=146 > 0.01 ; qacc_rel_p95=1.31 > 0.05 |
| spheres_20 | npu | S10 | 2 | 26 | qvel_linf=0.227 > 0.05 |
| spheres_20 | npu | S3 | 2 | 27 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 2 | 27 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 2 | 27 | qacc_linf=133.9 > 0.01 ; qacc_rel_p95=1.497 > 0.05 |
| spheres_20 | npu | S10 | 2 | 27 | qvel_linf=0.2245 > 0.05 |
| spheres_20 | npu | S3 | 2 | 28 | ncon mismatch ref=29 test=30 ; spurious_rate=0.03333 > 0.02 |
| spheres_20 | npu | S4 | 2 | 28 | nefc mismatch ref=116 test=120 |
| spheres_20 | npu | S9 | 2 | 28 | qacc_linf=123.7 > 0.01 ; qacc_rel_p95=1.83 > 0.05 |
| spheres_20 | npu | S10 | 2 | 28 | qvel_linf=0.4718 > 0.05 |
| spheres_20 | npu | S4 | 2 | 29 | efc_pos_rel.p95=0.1866 > 0.05 |
| spheres_20 | npu | S6 | 2 | 29 | efc_aref_rel.p95 > 0.05 |
| spheres_20 | npu | S9 | 2 | 29 | qacc_linf=8.976 > 0.01 ; qacc_rel_p95=0.7225 > 0.05 ; efc_force_rel.p95 > 0.05 |
| spheres_20 | npu | S10 | 2 | 29 | qvel_linf=0.4538 > 0.05 |
| box_drop | npu | S9 | 0 | 15 | qacc_linf=0.05267 > 0.01 |
| box_drop | npu | S6 | 0 | 16 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 16 | qacc_linf=0.02798 > 0.01 |
| box_drop | npu | S6 | 0 | 17 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 17 | qacc_linf=0.01088 > 0.01 |
| box_drop | npu | S6 | 0 | 18 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 19 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 20 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 20 | qacc_linf=0.01269 > 0.01 |
| box_drop | npu | S6 | 0 | 21 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 21 | qacc_linf=0.01518 > 0.01 |
| box_drop | npu | S6 | 0 | 22 | efc_aref_rel.p95 > 0.05 ; qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 22 | qacc_linf=0.01624 > 0.01 |
| box_drop | npu | S6 | 0 | 23 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 23 | qacc_linf=0.01633 > 0.01 |
| box_drop | npu | S6 | 0 | 24 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 24 | qacc_linf=0.01626 > 0.01 |
| box_drop | npu | S6 | 0 | 25 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 25 | qacc_linf=0.01665 > 0.01 |
| box_drop | npu | S3 | 0 | 26 | ncon mismatch ref=0 test=1 ; spurious_rate=1 > 0.02 |
| box_drop | npu | S4 | 0 | 26 | nefc mismatch ref=0 test=4 |
| box_drop | npu | S6 | 0 | 26 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 0 | 26 | qacc_linf=4.163 > 0.01 ; qacc_rel_p95=4.145e+12 > 0.05 |
| box_drop | npu | S6 | 0 | 27 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 28 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 0 | 29 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 15 | qacc_linf=0.05267 > 0.01 |
| box_drop | npu | S6 | 1 | 16 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 16 | qacc_linf=0.02798 > 0.01 |
| box_drop | npu | S6 | 1 | 17 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 17 | qacc_linf=0.01088 > 0.01 |
| box_drop | npu | S6 | 1 | 18 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 19 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 20 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 20 | qacc_linf=0.01269 > 0.01 |
| box_drop | npu | S6 | 1 | 21 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 21 | qacc_linf=0.01518 > 0.01 |
| box_drop | npu | S6 | 1 | 22 | efc_aref_rel.p95 > 0.05 ; qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 22 | qacc_linf=0.01624 > 0.01 |
| box_drop | npu | S6 | 1 | 23 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 23 | qacc_linf=0.01633 > 0.01 |
| box_drop | npu | S6 | 1 | 24 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 24 | qacc_linf=0.01626 > 0.01 |
| box_drop | npu | S6 | 1 | 25 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 25 | qacc_linf=0.01665 > 0.01 |
| box_drop | npu | S3 | 1 | 26 | ncon mismatch ref=0 test=1 ; spurious_rate=1 > 0.02 |
| box_drop | npu | S4 | 1 | 26 | nefc mismatch ref=0 test=4 |
| box_drop | npu | S6 | 1 | 26 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 1 | 26 | qacc_linf=4.163 > 0.01 ; qacc_rel_p95=4.145e+12 > 0.05 |
| box_drop | npu | S6 | 1 | 27 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 28 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 1 | 29 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 15 | qacc_linf=0.05267 > 0.01 |
| box_drop | npu | S6 | 2 | 16 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 16 | qacc_linf=0.02798 > 0.01 |
| box_drop | npu | S6 | 2 | 17 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 17 | qacc_linf=0.01088 > 0.01 |
| box_drop | npu | S6 | 2 | 18 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 19 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 20 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 20 | qacc_linf=0.01269 > 0.01 |
| box_drop | npu | S6 | 2 | 21 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 21 | qacc_linf=0.01518 > 0.01 |
| box_drop | npu | S6 | 2 | 22 | efc_aref_rel.p95 > 0.05 ; qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 22 | qacc_linf=0.01624 > 0.01 |
| box_drop | npu | S6 | 2 | 23 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 23 | qacc_linf=0.01633 > 0.01 |
| box_drop | npu | S6 | 2 | 24 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 24 | qacc_linf=0.01626 > 0.01 |
| box_drop | npu | S6 | 2 | 25 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 25 | qacc_linf=0.01665 > 0.01 |
| box_drop | npu | S3 | 2 | 26 | ncon mismatch ref=0 test=1 ; spurious_rate=1 > 0.02 |
| box_drop | npu | S4 | 2 | 26 | nefc mismatch ref=0 test=4 |
| box_drop | npu | S6 | 2 | 26 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S9 | 2 | 26 | qacc_linf=4.163 > 0.01 ; qacc_rel_p95=4.145e+12 > 0.05 |
| box_drop | npu | S6 | 2 | 27 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 28 | qfrc_bias_rel.p95 > 0.001 |
| box_drop | npu | S6 | 2 | 29 | qfrc_bias_rel.p95 > 0.001 |
| box_plane | npu | S9/S10 | 0 | None | qacc_linf=0.3501 > 0.01 |
| box_plane | npu | S9/S10 | 1 | None | qacc_linf=0.3501 > 0.01 |
| box_plane | npu | S9/S10 | 2 | None | qacc_linf=0.3501 > 0.01 |
| box_box_vf | npu | S9/S10 | 0 | None | qacc_linf=0.1838 > 0.01 |
| box_box_vf | npu | S9/S10 | 1 | None | qacc_linf=0.1838 > 0.01 |
| box_box_vf | npu | S9/S10 | 2 | None | qacc_linf=0.1838 > 0.01 |
| box_box_ee_deep | npu | S9/S10 | 0 | None | qacc_linf=0.2128 > 0.01 |
| box_box_ee_deep | npu | S9/S10 | 1 | None | qacc_linf=0.2128 > 0.01 |
| box_box_ee_deep | npu | S9/S10 | 2 | None | qacc_linf=0.2128 > 0.01 |
| plane_capsule | npu | S9/S10 | 0 | None | qacc_linf=0.7083 > 0.01 |
| plane_capsule | npu | S9/S10 | 1 | None | qacc_linf=0.7083 > 0.01 |
| plane_capsule | npu | S9/S10 | 2 | None | qacc_linf=0.7083 > 0.01 |
| capsule_capsule | npu | S9/S10 | 0 | None | qacc_linf=0.1821 > 0.01 |
| capsule_capsule | npu | S9/S10 | 1 | None | qacc_linf=0.1821 > 0.01 |
| capsule_capsule | npu | S9/S10 | 2 | None | qacc_linf=0.1821 > 0.01 |
| sphere_sphere_overlap | npu | S9/S10 | 0 | None | qacc_linf=0.2229 > 0.01 |
| sphere_sphere_overlap | npu | S9/S10 | 1 | None | qacc_linf=0.2229 > 0.01 |
| sphere_sphere_overlap | npu | S9/S10 | 2 | None | qacc_linf=0.2229 > 0.01 |
| capsule_capsule_parallel | npu | S9/S10 | 0 | None | qacc_linf=0.09888 > 0.01 |
| capsule_capsule_parallel | npu | S9/S10 | 1 | None | qacc_linf=0.09888 > 0.01 |
| capsule_capsule_parallel | npu | S9/S10 | 2 | None | qacc_linf=0.09888 > 0.01 |
| gjk_mesh_edge2 | npu | S9/S10 | 0 | None | qacc_linf=0.2266 > 0.01 |
| gjk_mesh_edge2 | npu | S9/S10 | 1 | None | qacc_linf=0.2266 > 0.01 |
| gjk_mesh_edge2 | npu | S9/S10 | 2 | None | qacc_linf=0.2266 > 0.01 |
| gjk_cylinder_box_margin | npu | S9/S10 | 0 | None | qacc_linf=0.7068 > 0.01 |
| gjk_cylinder_box_margin | npu | S9/S10 | 1 | None | qacc_linf=0.7068 > 0.01 |
| gjk_cylinder_box_margin | npu | S9/S10 | 2 | None | qacc_linf=0.7068 > 0.01 |

## S3 碰撞阶段误差(按 case 聚合最坏值)

| case | tier | lane | missed | flip | ncon(r/t) | dist_p95 | pos_p95 | normal°_p95 |
|---|---|---|---|---|---|---|---|---|
| box_drop | scene | npu | 0.000 | 0.000 | 0/0 | 3.39e-05 | 8.52e-06 | 0.00 |
| box_stack3 | scene | npu | 0.000 | 0.000 | 12/12 | 9.91e-05 | 3.83e-04 | 0.02 |
| spheres_20 | scene | npu | 0.065 | 0.000 | 29/29 | 1.06e-04 | 3.31e-04 | 0.05 |

## 混合模式 —— 碰撞差异是否影响下游

| case | lane | qacc_linf | qpos_linf | ncon(test/cap) | pass |
|---|---|---|---|---|---|
| box_plane | npu | 3.501e-01 | 9.474e-07 | 2/2 | ❌ |
| box_plane | npu | 3.501e-01 | 9.474e-07 | 2/2 | ❌ |
| box_plane | npu | 3.501e-01 | 9.474e-07 | 2/2 | ❌ |
| box_box_vf | npu | 1.838e-01 | 7.351e-07 | 1/1 | ❌ |
| box_box_vf | npu | 1.838e-01 | 7.351e-07 | 1/1 | ❌ |
| box_box_vf | npu | 1.838e-01 | 7.351e-07 | 1/1 | ❌ |
| box_box_ee | npu | 1.282e-06 | 5.127e-12 | 1/1 | ✅ |
| box_box_ee | npu | 1.282e-06 | 5.127e-12 | 1/1 | ✅ |
| box_box_ee | npu | 1.282e-06 | 5.127e-12 | 1/1 | ✅ |
| box_box_ee_deep | npu | 2.128e-01 | 8.513e-07 | 1/1 | ❌ |
| box_box_ee_deep | npu | 2.128e-01 | 8.513e-07 | 1/1 | ❌ |
| box_box_ee_deep | npu | 2.128e-01 | 8.513e-07 | 1/1 | ❌ |
| plane_sphere | npu | 2.980e-05 | 1.192e-10 | 1/1 | ✅ |
| plane_sphere | npu | 2.980e-05 | 1.192e-10 | 1/1 | ✅ |
| plane_sphere | npu | 2.980e-05 | 1.192e-10 | 1/1 | ✅ |
| plane_ellipsoid | npu | 1.187e-07 | 4.750e-13 | 1/1 | ✅ |
| plane_ellipsoid | npu | 1.187e-07 | 4.750e-13 | 1/1 | ✅ |
| plane_ellipsoid | npu | 1.187e-07 | 4.750e-13 | 1/1 | ✅ |
| plane_capsule | npu | 7.083e-01 | 1.238e-06 | 2/2 | ❌ |
| plane_capsule | npu | 7.083e-01 | 1.238e-06 | 2/2 | ❌ |
| plane_capsule | npu | 7.083e-01 | 1.238e-06 | 2/2 | ❌ |
| convex_convex | npu | 9.437e-07 | 3.775e-12 | 1/1 | ✅ |
| convex_convex | npu | 9.437e-07 | 3.775e-12 | 1/1 | ✅ |
| convex_convex | npu | 9.437e-07 | 3.775e-12 | 1/1 | ✅ |
| capsule_capsule | npu | 1.821e-01 | 7.282e-07 | 1/1 | ❌ |
| capsule_capsule | npu | 1.821e-01 | 7.282e-07 | 1/1 | ❌ |
| capsule_capsule | npu | 1.821e-01 | 7.282e-07 | 1/1 | ❌ |
| sphere_sphere_overlap | npu | 2.229e-01 | 8.916e-07 | 1/1 | ❌ |
| sphere_sphere_overlap | npu | 2.229e-01 | 8.916e-07 | 1/1 | ❌ |
| sphere_sphere_overlap | npu | 2.229e-01 | 8.916e-07 | 1/1 | ❌ |
| sphere_plane_grazing | npu | 6.202e-09 | 2.481e-14 | 1/1 | ✅ |
| sphere_plane_grazing | npu | 6.202e-09 | 2.481e-14 | 1/1 | ✅ |
| sphere_plane_grazing | npu | 6.202e-09 | 2.481e-14 | 1/1 | ✅ |
| capsule_capsule_parallel | npu | 9.888e-02 | 1.978e-07 | 2/2 | ❌ |
| capsule_capsule_parallel | npu | 9.888e-02 | 1.978e-07 | 2/2 | ❌ |
| capsule_capsule_parallel | npu | 9.888e-02 | 1.978e-07 | 2/2 | ❌ |
| box_plane_flush | npu | 0.000e+00 | 0.000e+00 | 4/4 | ✅ |
| box_plane_flush | npu | 0.000e+00 | 0.000e+00 | 4/4 | ✅ |
| box_plane_flush | npu | 0.000e+00 | 0.000e+00 | 4/4 | ✅ |
| gjk_sphere_sphere_dist | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_dist | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_dist | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_dist_cutoff | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_dist_cutoff | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_dist_cutoff | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_no_dist | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_no_dist | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_no_dist | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_intersect | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_intersect | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_sphere_sphere_intersect | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth3 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth3 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_depth3 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05b | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05b | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05b | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05c | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05c | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_size05c | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_touching | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_touching | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_touching | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d3 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d3 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d3 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d4 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d4 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d4 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d5 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d5 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d5 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d6 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d6 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d6 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d7 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d7 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d7 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d8 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d8 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d8 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d9 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d9 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d9 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d10 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d10 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d10 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d11 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d11 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d11 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d12 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d12 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d12 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d13 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d13 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d13 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d14 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d14 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d14 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d15 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d15 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_multi_c_c_d15 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_small_box_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_small_box_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_small_box_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh_prune | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh_prune | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_mesh_prune | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_mesh | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_mesh_prune | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_mesh_prune | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_mesh_prune | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge2 | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_edge | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_mesh_edge2 | npu | 2.266e-01 | 9.064e-07 | 4/4 | ❌ |
| gjk_mesh_edge2 | npu | 2.266e-01 | 9.064e-07 | 4/4 | ❌ |
| gjk_mesh_edge2 | npu | 2.266e-01 | 9.064e-07 | 4/4 | ❌ |
| gjk_ellipsoid_ellipsoid | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid_slow_convergence | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid_slow_convergence | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid_slow_convergence | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_large | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_large | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_box_large | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_long_box | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_long_box | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_long_box | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid_intersect | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid_intersect | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_ellipsoid_ellipsoid_intersect | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_capsule_capsule | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_capsule_capsule | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_capsule_capsule | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_cylinder_box_margin | npu | 7.068e-01 | 1.414e-06 | 1/1 | ❌ |
| gjk_cylinder_box_margin | npu | 7.068e-01 | 1.414e-06 | 1/1 | ❌ |
| gjk_cylinder_box_margin | npu | 7.068e-01 | 1.414e-06 | 1/1 | ❌ |
| gjk_box_edge_flipped | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge_flipped | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
| gjk_box_edge_flipped | npu | 0.000e+00 | 0.000e+00 | 0/0 | ✅ |
