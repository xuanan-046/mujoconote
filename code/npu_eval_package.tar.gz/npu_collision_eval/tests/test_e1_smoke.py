"""E1 冒烟 —— 各泳道能从同一初值跑若干步、不崩、无 NaN、ncon>0。"""
import numpy as np
import pytest

import mujoco

from npu_eval import fixtures
from npu_eval.lanes import get_lanes
from npu_eval.runner import _init_state

SMOKE_CASES = ["box_plane", "box_stack3", "spheres_20"]


@pytest.mark.parametrize("case", SMOKE_CASES)
@pytest.mark.parametrize("lane_name", ["cpu_fp64", "npu"])
def test_smoke(case, lane_name):
    lane = get_lanes([lane_name])[0]
    if not lane.available() and lane_name != "npu":
        pytest.skip(f"{lane_name} 不可用")
    xml = fixtures.xml_of(case)
    m = mujoco.MjModel.from_xml_string(xml)
    qpos, qvel = _init_state(m, 0, 0.0)
    h = lane.load(xml)
    h.reset(qpos, qvel)
    snaps = h.run_full(20, ("S3", "S10"))
    assert len(snaps) == 20
    last = {s.stage: s for s in snaps[-1]}
    assert not np.isnan(last["S10"].fields["qpos"]).any(), f"{case}/{lane_name} qpos NaN"
