"""S3/S4/S9/S10 阶段级 gate + 混合模式。npu 缺省用 mock 泳道跑通。

真跑法(内部机器):
  NPU_EVAL_ENABLE=1 pytest tests/test_stages.py --lanes ...
这里为保持 pytest 简单, 泳道固定 cpu_fp64(参考) + npu(被测/mock)。
"""
import pytest

from npu_eval import fixtures
from npu_eval.gates import load_thresholds
from npu_eval.runner import run_free, run_hybrid, summarize

THR = load_thresholds()
FREE_CASES = list(fixtures.by_tier("scene"))
HYBRID_CASES = list(fixtures.by_tier("analytic", "primitive", "degenerate"))


def test_self_consistency_cpu_fp64():
    """cpu_fp64 对自己跑 free 模式必须逐阶段零差异(harness 自检)。"""
    rows = run_free(["box_stack3"], ["cpu_fp64", "cpu_fp64"], nstep=5)
    # 同泳道被 runner 跳过 -> rows 为空即通过; 若实现改为允许自比, 断言全 pass
    for r in rows:
        assert r["passed"], (r["stage"], r["failures"])


@pytest.mark.parametrize("case", FREE_CASES)
def test_free_mode_stage_gates(case):
    rows = run_free([case], ["cpu_fp64", "npu"], nstep=15, thr=THR)
    s = summarize(rows)
    hard = [f for f in s["failures"]
            if any("missed_rate" in w or "flip" in w for w in f["why"])]
    assert not hard, f"S3 硬门禁失败: {hard}"
    # 其余阈值类失败在 mock 下允许(mock 故意注入 fp32 误差), 只打印
    if s["failed"]:
        print(f"[{case}] 非硬门禁失败 {s['failed']}/{s['total']}: {s['failures'][:3]}")


@pytest.mark.parametrize("case", HYBRID_CASES)
def test_hybrid_downstream_sensitivity(case):
    rows = run_hybrid([case], ["npu"], thr=THR)
    assert rows, case
    for r in rows:
        m = r["metrics"]
        assert m["qacc_linf"] == m["qacc_linf"], "qacc_linf NaN"  # not-NaN
        print(f"[{case}] qacc_linf={m['qacc_linf']:.3e} qpos_linf={m['qpos_linf']:.3e} "
              f"pass={r['passed']}")
