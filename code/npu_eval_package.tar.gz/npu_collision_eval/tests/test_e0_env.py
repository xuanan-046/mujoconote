"""E0 环境校验 —— golden checksum、模型可加载、开关一致。"""
import json
import pathlib

import mujoco
import pytest

from npu_eval import fixtures
from npu_eval.lanes import MujocoLane

GOLDEN = pathlib.Path(__file__).resolve().parents[1] / "golden"


def test_all_fixtures_load():
    for name in fixtures.ALL_FIXTURES:
        m = mujoco.MjModel.from_xml_string(fixtures.xml_of(name))
        assert m.ngeom >= 2, name


def test_cpu_fp64_lane_available():
    assert MujocoLane("fp64").available(), "当前 wheel 不是 double 构建?"


@pytest.mark.skipif(not (GOLDEN / "manifest.json").exists(),
                    reason="先跑 scripts/gen_golden.py")
def test_golden_checksums():
    import hashlib
    man = json.loads((GOLDEN / "manifest.json").read_text())
    for case, meta in man.items():
        npz = GOLDEN / f"{case}.npz"
        assert npz.exists(), case
        got = hashlib.sha256(npz.read_bytes()).hexdigest()
        assert got == meta["sha256"], f"golden 漂移: {case}"


@pytest.mark.skipif(not (GOLDEN / "manifest.json").exists(),
                    reason="先跑 scripts/gen_golden.py")
def test_golden_mj_version_matches():
    man = json.loads((GOLDEN / "manifest.json").read_text())
    for case, meta in man.items():
        assert meta["mj_version"] == mujoco.__version__, (
            f"{case}: golden 用 mujoco {meta['mj_version']}, 当前 {mujoco.__version__}")
