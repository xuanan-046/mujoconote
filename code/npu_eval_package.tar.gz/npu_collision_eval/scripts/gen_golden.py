#!/usr/bin/env python3
"""生成 golden + fp32 参考带。

1. 对每个 case, 用 cpu_fp64 跑 nstep, dump 每步阶段快照 -> golden/<case>.npz + sha256
2. 若当前是 fp32 wheel (或提供 --fp32-python 指向 fp32 构建的 python), 同时跑 cpu_fp32
   并算 cpu_fp64-vs-cpu_fp32 的逐阶段误差分布 -> golden/fp32_band.json
   这个 band 就是 thresholds.yaml 各 p95 阈值的经验依据 (Phase 2.4)。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import sys

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import mujoco  # noqa: E402

from npu_eval import fixtures  # noqa: E402
from npu_eval.lanes import MujocoLane  # noqa: E402
from npu_eval.metrics import stage_metrics  # noqa: E402
from npu_eval.runner import DEFAULT_SNAP_STAGES, _init_state  # noqa: E402


def _pack(snaps_by_step):
    flat = {}
    for step, snaps in enumerate(snaps_by_step):
        for s in snaps:
            for k, v in s.fields.items():
                flat[f"{step}.{s.stage}.{k}"] = np.asarray(v)
    return flat


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", nargs="+", default=None)
    ap.add_argument("--nstep", type=int, default=20)
    ap.add_argument("--out", default=str(ROOT / "golden"))
    args = ap.parse_args()
    out = pathlib.Path(args.out); out.mkdir(parents=True, exist_ok=True)

    cases = args.cases or list(fixtures.ALL_FIXTURES)
    fp64 = MujocoLane("fp64")
    fp32 = MujocoLane("fp32")
    manifest = {}
    band = {sid: {} for sid in DEFAULT_SNAP_STAGES}

    for case in cases:
        xml = fixtures.xml_of(case)
        m = mujoco.MjModel.from_xml_string(xml)
        qpos, qvel = _init_state(m, 0, 0.0)

        h = fp64.load(xml); h.reset(qpos, qvel)
        s64 = h.run_full(args.nstep, DEFAULT_SNAP_STAGES)
        flat = _pack(s64)
        npz = out / f"{case}.npz"
        np.savez_compressed(npz, **flat)
        manifest[case] = dict(sha256=hashlib.sha256(npz.read_bytes()).hexdigest(),
                              nstep=args.nstep, tier=fixtures.tier_of(case),
                              mj_version=mujoco.__version__)

        if fp32.available():
            h32 = fp32.load(xml); h32.reset(qpos, qvel)
            s32 = h32.run_full(args.nstep, DEFAULT_SNAP_STAGES)
            for step in range(min(len(s64), len(s32))):
                rmap = {s.stage: s for s in s64[step]}
                tmap = {s.stage: s for s in s32[step]}
                for sid in DEFAULT_SNAP_STAGES:
                    if sid in rmap and sid in tmap:
                        mt = stage_metrics(sid, rmap[sid], tmap[sid])
                        for k, v in mt.items():
                            if isinstance(v, (int, float)) and "p95" in k or k in (
                                    "missed_rate", "spurious_rate", "qacc_linf", "dist_abs_p95"):
                                band[sid].setdefault(k, []).append(float(v))

    (out / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
    if fp32.available():
        band_summary = {sid: {k: dict(p50=float(np.percentile(v, 50)),
                                      p95=float(np.percentile(v, 95)),
                                      max=float(np.max(v)))
                              for k, v in d.items() if v}
                        for sid, d in band.items()}
        (out / "fp32_band.json").write_text(json.dumps(band_summary, indent=2, ensure_ascii=False))
        print("fp32 band ->", out / "fp32_band.json")
    else:
        print("当前非 fp32 wheel, 跳过 fp32_band。用 --fp32 构建重跑本脚本以标定阈值。")
    print(f"golden -> {out} ({len(cases)} cases)")


if __name__ == "__main__":
    main()
