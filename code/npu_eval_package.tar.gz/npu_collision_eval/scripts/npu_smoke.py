#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""隔离测你的 NPU 适配层（npu_eval/npu_backend.py）—— 不跑评测，只看接口通不通。

在内网机器上，接好 npu_backend.py 后先跑这个：
    NPU_EVAL_ENABLE=1 python scripts/npu_smoke.py
    NPU_EVAL_ENABLE=1 python scripts/npu_smoke.py --case box_stack3 --steps 5
接 kernel 前想先验证胶水：
    NPU_EVAL_ENABLE=1 NPU_BACKEND=selfcheck python scripts/npu_smoke.py

它做的事：
  1. 编译一个模型，build_static → npu_open
  2. 从初始位形算世界位姿，调 npu_collide，打印返回的接触数组 + 逐项 sanity 检查
  3. 和 CPU mj_collision 的接触做一次无序匹配，报漏检 / 虚检 / 最大几何误差
  4. 连跑几步，看每步是否稳定、有无 NaN
"""
from __future__ import annotations

import argparse
import pathlib
import sys

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import mujoco  # noqa: E402

from npu_eval import fixtures, npu_backend  # noqa: E402
from npu_eval.lanes import NpuHandle  # noqa: E402
from npu_eval.matching import match_contacts  # noqa: E402
from npu_eval.stages import _contacts  # noqa: E402


def sanity(c: np.ndarray) -> list[str]:
    bad = []
    if c.ndim != 2 or c.shape[1] != npu_backend.NCOL:
        return [f"shape={c.shape}，期望 [K,{npu_backend.NCOL}]"]
    if not np.isfinite(c).all():
        bad.append("含 NaN / inf")
    nrm = np.linalg.norm(c[:, 4:7], axis=1) if len(c) else np.array([])
    if len(nrm) and (np.abs(nrm - 1) > 1e-3).any():
        bad.append(f"法向非单位向量（max|‖n‖-1|={np.abs(nrm-1).max():.2e}）")
    if len(c) and (c[:, 14] > c[:, 15]).any():
        bad.append("geom 列存在 g1 > g2（应 g1 < g2）")
    if len(c) and not np.isin(c[:, 13], [1, 3, 4, 6]).all():
        bad.append(f"dim 非 1/3/4/6：{sorted(set(c[:,13].tolist()))}")
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", default="box_plane", help="fixtures 里的用例名")
    ap.add_argument("--steps", type=int, default=3)
    args = ap.parse_args()

    xml = fixtures.xml_of(args.case)
    print(f"用例: {args.case}   backend: {npu_backend._backend_name()}")

    try:
        h = NpuHandle(xml)
    except NotImplementedError as e:
        print(f"\n✗ npu_backend 还没接: {e}")
        print("  先接 npu_eval/npu_backend.py 的 npu_open / npu_collide，或用 NPU_BACKEND=selfcheck 验证胶水。")
        sys.exit(2)

    m = h.m
    d = mujoco.MjData(m)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    qpos = np.array(d.qpos)
    qvel = np.zeros(m.nv)

    print(f"\n模型: ngeom={m.ngeom}  nq={m.nq}  nv={m.nv}")
    ok = True
    for step in range(args.steps):
        c = h.collision_only(qpos, qvel)
        d.qpos[:] = qpos; d.qvel[:] = qvel
        mujoco.mj_forward(m, d)              # 让 cref 对应当前位形
        cref = _contacts(d)
        problems = sanity(c)
        mm = match_contacts(cref, c)
        n_ref = max(mm["n_ref"], 1)
        missed = len(mm["missed"]) / n_ref
        spur = len(mm["spurious"]) / max(mm["n_test"], 1)
        derr = 0.0
        if mm["matched"]:
            derr = max(abs(cref[i, 0] - c[j, 0]) for i, j in mm["matched"])
        tag = "ok" if not problems and missed == 0 else "CHECK"
        print(f"[step {step}] npu ncon={len(c):2d}  cpu ncon={mm['n_ref']:2d}  "
              f"漏检={missed:.2f}  虚检={spur:.2f}  max|Δdist|={derr:.2e}  [{tag}]")
        if problems:
            ok = False
            for p in problems:
                print(f"           ✗ {p}")
        # 推进一步（用 CPU，只是为了换个位形再测一次）
        d.qpos[:] = qpos; d.qvel[:] = qvel
        mujoco.mj_step(m, d)
        qpos = np.array(d.qpos); qvel = np.array(d.qvel)

    # 确定性快检：同输入重复 5 次
    c0 = h.collision_only(np.array(d.qpos), np.array(d.qvel))
    same = all(np.array_equal(c0, h.collision_only(np.array(d.qpos), np.array(d.qvel))) for _ in range(4))
    print(f"\n确定性快检（重复 5 次同输入）: {'一致' if same else '不一致 —— Step 5 要量抖动上界'}")

    h.close()
    print("\n结论:", "接口通，可以跑 run_eval.py" if ok else "有问题，见上面 ✗，先修 npu_backend / kernel")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
