#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Step 5 · 确定性：同输入重复跑 NPU 碰撞 N 次，看是否逐位一致；不一致则报 FP 抖动上界。

    NPU_EVAL_ENABLE=1 python scripts/npu_determinism.py --repeats 1000
    NPU_EVAL_ENABLE=1 python scripts/npu_determinism.py --cases box_stack3 spheres_20 --repeats 200
"""
from __future__ import annotations

import argparse
import pathlib
import sys

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import mujoco  # noqa: E402

from npu_eval import fixtures  # noqa: E402
from npu_eval.lanes import NpuHandle  # noqa: E402
from npu_eval.matching import GEOM_ATOL, GEOM_RTOL, match_contacts  # noqa: E402


def run_case(name, repeats):
    xml = fixtures.xml_of(name)
    h = NpuHandle(xml)
    m = h.m
    d = mujoco.MjData(m)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    # 走几步到有接触的位形
    for _ in range(20):
        mujoco.mj_step(m, d)
    qpos, qvel = np.array(d.qpos), np.array(d.qvel)

    base = h.collision_only(qpos, qvel)
    bit_same = 0
    max_dist_jit = 0.0
    max_pos_jit = 0.0
    ncon_changes = 0
    for _ in range(repeats):
        c = h.collision_only(qpos, qvel)
        if c.shape == base.shape and np.array_equal(c, base):
            bit_same += 1
            continue
        if c.shape[0] != base.shape[0]:
            ncon_changes += 1
            continue
        mm = match_contacts(base, c, rtol=1e9, atol=1e9)  # 强行按 geom+pos 配上
        for i, j in mm["matched"]:
            max_dist_jit = max(max_dist_jit, abs(base[i, 0] - c[j, 0]))
            max_pos_jit = max(max_pos_jit, np.linalg.norm(base[i, 1:4] - c[j, 1:4]))
    h.close()
    return dict(case=name, repeats=repeats, bit_identical=bit_same,
                ncon_changes=ncon_changes,
                max_dist_jitter=max_dist_jit, max_pos_jitter=max_pos_jit)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", nargs="+", default=None)
    ap.add_argument("--repeats", type=int, default=500)
    args = ap.parse_args()
    cases = args.cases or list(fixtures.by_tier("scene", "degenerate"))

    print(f"{'case':22} {'bit一致':>10} {'ncon变化':>9} {'Δdist上界':>12} {'Δpos上界':>12}")
    worst_d = worst_p = 0.0
    for name in cases:
        try:
            r = run_case(name, args.repeats)
        except NotImplementedError as e:
            print(f"npu_backend 未接: {e}"); sys.exit(2)
        worst_d = max(worst_d, r["max_dist_jitter"])
        worst_p = max(worst_p, r["max_pos_jitter"])
        print(f"{r['case']:22} {r['bit_identical']:>7}/{args.repeats:<3} "
              f"{r['ncon_changes']:>9} {r['max_dist_jitter']:>12.2e} {r['max_pos_jitter']:>12.2e}")

    print("\n结论:")
    if worst_d == 0 and worst_p == 0:
        print("  全部逐位一致 —— 确定性通过，不必给抖动上界。")
    else:
        print(f"  非逐位一致。FP 抖动上界: Δdist ≤ {worst_d:.2e}, Δpos ≤ {worst_p:.2e}")
        print(f"  → 把这两个值并入 config/thresholds.yaml 的 S3 容差（Step 3 的阈值要 ≥ 抖动上界）。")
        print(f"  → 若出现 ncon 变化（接触数跳变），是硬问题，需要 NPU 侧定位（并行归约 / 竞态）。")


if __name__ == "__main__":
    main()
