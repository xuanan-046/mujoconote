#!/usr/bin/env python3
"""一键跑测评 -> report/。

例:
  # 无 NPU, 用 mock 泳道跑通全流程
  python scripts/run_eval.py --lanes cpu_fp64 npu --modes free hybrid

  # 内部机器, 有 NVIDIA GPU + mujoco-warp + 真 NPU
  NPU_EVAL_ENABLE=1 python scripts/run_eval.py \
      --lanes cpu_fp64 cpu_fp32 mjwarp npu --modes free hybrid \
      --nstep 40 --seeds 0 1 2 --jitter 1e-3
"""
from __future__ import annotations

import argparse
import datetime
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from npu_eval import fixtures, report  # noqa: E402
from npu_eval.runner import run_free, run_hybrid, summarize  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lanes", nargs="+", default=["cpu_fp64", "npu"])
    ap.add_argument("--modes", nargs="+", default=["free", "hybrid"],
                    choices=["free", "hybrid"])
    ap.add_argument("--cases", nargs="+", default=None,
                    help="默认: free 用 scene tier, hybrid 用 analytic+primitive+degenerate")
    ap.add_argument("--nstep", type=int, default=20)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--jitter", type=float, default=0.0)
    ap.add_argument("--out", default=str(ROOT / "report"))
    args = ap.parse_args()

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rows = []

    if "free" in args.modes:
        cases = args.cases or list(fixtures.by_tier("scene"))
        rows += run_free(cases, args.lanes, nstep=args.nstep,
                         seeds=tuple(args.seeds), jitter=args.jitter)
    if "hybrid" in args.modes:
        cases = args.cases or list(fixtures.by_tier("analytic", "primitive", "degenerate"))
        rows += run_hybrid(cases, args.lanes, seeds=tuple(args.seeds), jitter=args.jitter)

    summary = summarize(rows)
    meta = dict(timestamp=datetime.datetime.now().isoformat(timespec="seconds"),
                lanes=args.lanes, modes=args.modes, nstep=args.nstep,
                seeds=args.seeds, jitter=args.jitter)
    report.write_csv(rows, out / "results.csv")
    md = report.write_markdown(rows, summary, out / "report.md", meta)
    (out / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False))

    print(md)
    print(f"\n-> {out/'report.md'} , {out/'results.csv'}")
    sys.exit(0 if summary["failed"] == 0 else 1)


if __name__ == "__main__":
    main()
