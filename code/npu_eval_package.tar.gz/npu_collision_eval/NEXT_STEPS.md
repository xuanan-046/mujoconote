# 我要做什么 · 怎么做

NPU 碰撞检测优化 —— 阶段级对比测评的落地清单。
配套: `README.md`(用法) · `../npu_collision_eval_plan.md`(方案) · `../npu_collision_eval_tables_A_B.md`(用例池)。

---

## 0. 现状(已完成)

- [x] 阶段级 harness `npu_collision_eval/`,`pytest -q` 全绿
- [x] 阶段分解已验证 `== mj_forward()+mj_Euler()` 逐位相同
- [x] 4 泳道骨架(`cpu_fp64` 可跑 / `cpu_fp32` `mjwarp` `npu` 待接) + Mock NPU 跑通全流程
- [x] `free` / `hybrid` 两模式 + S3/S4/S6/S9/S10 阶段 gate + 报告 + CI 退出码
- [x] `golden/` 63 个 case 的 `cpu_fp64` 参考 + sha256(A3 已完成：47 个官方 GJK 内联位形 + 1 个官方 broadphase 判定场景，逐字抽自 `~/mujoco@f9a00bd`)
- [x] 修了两个 bug：① `MockNpuHandle` 原来 free 模式不传播扰动到 S4~S10（只在事后覆盖快照展示值），现改为复用 `NpuHandle` 真实注入逻辑；② `run_hybrid` 遇到 0 自由度模型（官方 GJK 静态位形）时 `qacc`/`qpos` 是空数组，`.max()` 会崩，已加空数组保护
- [ ] 阈值仍是占位值(待 A2 标定)
- [ ] `cpu_fp32` / `mjwarp` / `npu` 三条泳道待接

---

## Track A — 本周可做(不等合作方、不等 NPU)

### A1. 内部 N 卡机器跑通 + 接 MJWarp 泳道

**目标**: 拿到 MJWarp 相对 `cpu_fp64` 的偏差参考带,后面判 NPU "达没达到成熟 GPU 移植水平" 靠它。

**步骤**
1. 把 `npu_collision_eval/` 拷到内部机器。
2. 装依赖:
   ```bash
   pip install -r requirements.txt
   pip install mujoco-warp==<与 mujoco 3.11 对应的 release> warp-lang
   python -c "import warp as wp; print(wp.get_cuda_device_count())"   # 应 >0
   ```
3. 先只跑 MJWarp 泳道:
   ```bash
   python scripts/run_eval.py --lanes cpu_fp64 mjwarp --modes free hybrid --nstep 40
   ```
4. `lanes.py:MjWarpHandle` 大概率要小修(字段名 / `nworld` 维度 / `d.contact.*` 的 numpy 取法)。
   参照 `mujoco_warp/_src/collision_driver_test.py` 的实际 API 改。
5. 跑通后固定 MJWarp 版本(pin 进 `requirements.txt`)。

**完成标准**: `report/report.md` 里 `mjwarp` 泳道有完整 S3/S4/S9/S10 数字;记下每个 case 的 `dist_p95` / `pos_p95` / `qacc_linf` 作为 "参考带"。

**依赖**: 无 · **预计**: 0.5–1 天(主要是调 MJWarp 字段)

---

### A2. 建 `cpu_fp32` 泳道 → 标定阈值(最重要)

**目标**: 把 `config/thresholds.yaml` 的占位阈值换成有依据的值。顺带定性 apple_8/11 轨迹偏移是精简质量还是纯精度。

**步骤**
1. 单独 venv,装 float 构建的 mujoco:
   - 优先找现成 single-precision wheel;找不到就自己编:
     ```bash
     git clone --branch <与 3.11 对应 tag> https://github.com/google-deepmind/mujoco
     cmake -B build -DmjUSESINGLE=ON ... && cmake --build build
     # 装对应的 python 绑定
     ```
   - 验证:`python -c "import mujoco,numpy; print(mujoco.MjModel.from_xml_string('<mujoco/>').qpos0.dtype)"` → `float32`
2. 在这个 venv 里跑:
   ```bash
   python scripts/gen_golden.py --nstep 40
   ```
   产出 `golden/fp32_band.json`(各阶段 `cpu_fp64` vs `cpu_fp32` 的误差分布 p50/p95/max)。
3. 回填 `config/thresholds.yaml`:每个 `*_p95` 阈值 = `fp32_band.json` 对应项的 p95 × 1.5;
   绝对下限保留(`dist_abs_p95` 不小于 `1e-4·rbound` 量级)。
4. 硬门禁不动:`missed_rate: 0.0` / `normal_flip_rate: 0.0` / broadphase 非子集。

**完成标准**: `thresholds.yaml` 每个阈值旁注明来源(fp32 band 实测 / 绝对下限);`gen_golden.py` 在 fp64 自比对下输出全零(自洽性检查)。

**依赖**: 无 · **预计**: 1–2 天(主要是搞定 fp32 构建)

---

### A3.（已完成）扩 case 池到官方用例

**完成情况**：覆盖率从 16 个 fixture 提到 **63 个**。

1. `engine_collision_gjk_test.cc` 的 47 个内联位形，用正则抽取脚本自动解析出 46 个（`EllipsoidEllipsoidPenetrating` 依赖 keyframe，格式跟现有 fixture schema 不兼容，暂缺），归入 `GJK_OFFICIAL_FIXTURES`，5 个有闭式解的标 `analytic`，其余标 `degenerate`。
2. `testdata/collisions.xml`（broadphase 分类/过滤判定：碰/需窄相位/可宽相位排除/exclude/pair）逐字抽入 `BROADPHASE_FIXTURES`，命名 `broadphase_filter`。**故意标 `tier="structural"`（不是 `scene`），不会被默认 `--cases` 选中**——这个模型深度穿透 + 部分关节轴穿过 geom 中心导致物理上无法通过积分缓解，硬跑 30 步会产生数量级 1e10 的假性"炸裂"（参考解本身就这么大，不是 NPU 引入的），只应该用它做 S3 层面的结构性检查（候选对集合/`ncon`/漏检率），手动跑：`--cases broadphase_filter --modes free --nstep 1`，只看 S3 那一行。
3. 顺带修了两个 bug（见 §0）：`MockNpuHandle` free 模式不传播扰动、`run_hybrid` 0 自由度模型 `qacc`/`qpos` 空数组导致崩溃（前者是这批 63 个 case 之前就存在的、被新 case 暴露出来的既有 bug）。
4. `gen_golden.py --nstep 30` 已重跑，`pytest -q` 73 passed。

**未完成的子项（仍然按原计划推迟）**：`mjc_SDF` 族（`phase0_scope.md` 里提到"整个 `mj_collision()` offload 后 SDF 默认进范围"）——嵌入 SDF geom 需要额外的 mesh/plugin 资产，本轮暂缺，等确认实际测试模型集里有没有 SDF/非凸 geom 再决定要不要补。

---

## Track B — 等合作方(发一封邮件,越早越好)

### B1. Phase 0 五个问题

抄 `../npu_collision_eval_plan.md` Phase 0 的表,发给 NPU 合作方,要书面答复:

1. **offload 边界**: broadphase / 窄相位分派 / GJK+EPA / multiCCD 哪几段在 NPU?调用点是整个 `mj_collision()` 还是替换某几个 `mjCOLLISIONFUNC` 表项?
2. **精度**: fp32 / bf16 / 混合 / 定点?中间累加精度?
3. **CCD 参数**(最关键): `ccd_iterations` / `ccd_tolerance` 沿用 CPU 值,还是改成固定迭代?
   → 改了就得单列 "算法变体" 一档,不能混进主对照。
4. **对标的 CPU 实现**: native CCD(默认)还是 libccd/MPR?multiCCD 开还是关?
5. **接口形态**: host 每步上行什么(geom 位姿 / AABB / mesh)、下行什么(`mjContact` / `mjCCDStatus`)?
   同步还是异步?接触对最终排序规则?

**完成标准**: 一页纸书面答复 + NPU 侧代码/接口访问方式,存 `phase0_scope.md`。

**依赖**: 无 · **预计**: 邮件 10 分钟,等回复 N 天

---

## Track C — 拿到 NPU 访问后

### C1. 接 NPU 后端

**目标**: 填 `npu_eval/lanes.py:NpuHandle`,让 `npu` 泳道跑真硬件。

**步骤**
1. `NpuHandle.__init__(xml)`: 初始化 NPU 上下文,加载模型。
2. `NpuHandle.collision_only(qpos, qvel) -> np.ndarray [N,21]`:
   - 设 geom 位姿(可先在 host 用 `mujoco.mj_kinematics` 算好 `geom_xpos/xmat` 传下去)
   - 调 NPU 碰撞 kernel
   - **按 MuJoCo 确定性接触排序规则重排**(见 Phase 0 Q5 答复)
   - 返回 `[dist(1), pos(3), frame(9), dim(1), geom(2), friction(5)]` 每行一个接触
3. 若 NPU 能跑完整 `mj_step`,再实现 `run_full`(用于 `free` 模式);只做碰撞就跳过,用 `hybrid`。
4. `NPU_EVAL_ENABLE=1` 打开真泳道。

**完成标准**: `NPU_EVAL_ENABLE=1 python scripts/run_eval.py --lanes cpu_fp64 npu --modes hybrid` 出真数字,不再走 mock。

**依赖**: B1 + NPU 访问 · **预计**: 2–5 天(取决于接口)

---

### C2. 首轮全泳道评测 + 出报告

**步骤**
```bash
NPU_EVAL_ENABLE=1 python scripts/run_eval.py \
    --lanes cpu_fp64 cpu_fp32 mjwarp npu \
    --modes free hybrid \
    --nstep 40 --seeds 0 1 2 3 4 --jitter 1e-3
```

**看什么**
- **有无差异**: S3 的 `missed_rate` / `dist_p95` / `normal_deg_p95`;S10 的 `qpos_linf` 发散曲线
- **差异是否重要**: `hybrid` 的 `qacc_linf` —— 超 fp32 band 就是碰撞差异污染了仿真
- **能不能更好**: 加速比(见 D3);解析 case 上 NPU 是否比 `cpu_fp64` 更接近闭式解(一般不会,除非改了算法)
- **相对 MJWarp**: NPU 偏差 ≤ MJWarp band → 达到成熟 GPU 移植水平

**完成标准**: `report/report.md` 一版完整报告 + 结论段(和原版有无差异 / 差异是否影响结果 / 加速比是否划算)。

**依赖**: A1 + A2 + C1 · **预计**: 1 天跑 + 1 天写结论

---

## Track D — 主线跑通后补(不挡路)

- [ ] **D1 E5 不变量**: 新增 `tests/test_invariants.py` —— 法向指向 geom1→geom2 / witness 在表面 / 交换 geom 法向翻转深度不变 / 平移穿过穿透深度连续。无需 golden。
- [ ] **D2 E6 确定性**: `runner.run_determinism()` —— NPU 同输入重复 1000 次,比 `contact` 是否 bit 一致;不一致给 FP 抖动上界并入阈值。
- [ ] **D3 E8 完整性能基准**: 挪 `~/mujoco/test/benchmark/ccd_benchmark_test.cc` 的 `TestHarness`(预热 1000 / 批 50 / 线程 0,9)+ `step_benchmark` 的 Humanoid/Humanoid100/Particle;报 `timer[POS_COLLISION/COL_BROAD/COL_NARROW]` + 端到端 + `particle.xml` N 扫描曲线 + host↔NPU 传输。算 "阶段加速比 × 阶段占比 − 传输 = 整步净收益"(对照 `conclusion.md` §5.2 的 10–15%)。
- [ ] **D4 E9 fuzz**(nightly): 随机 geom 对 + 随机位姿 N≥1e5,报分布,和上次 nightly 比回归趋势。
- [ ] **D5 CI**: `run_eval.py` 退出码接内部 CI;每个 NPU 新构建触发;golden 漂移需 review。

---

## 附:门禁公式(D5 用)

```
PASS 当且仅当:
  S3.missed_rate == 0  且  S3.normal_flip_rate == 0  且  broadphase 非子集
  且 每阶段 {p95 指标} ≤ thresholds.yaml(已由 A2 标定)
  且 hybrid.qacc_linf 的 p95 ≤ 阈值
  且 碰撞阶段加速比 ≥ Phase 0 约定目标
  且 mj_step 端到端不慢于纯 CPU
  且 golden sha256 未漂移(或漂移已 review + 更新)
CCD 参数变体(Phase 0 Q3)单列一条非阻塞报告线。
```

## 附:关键路径

```
B1(邮件) ┐
A1(MJWarp) ┼─► C1(接NPU) ─► C2(首轮报告) ─► D(补全)
A2(fp32标阈值) ┘
```
硬件到位前:A1 + A2 可做完(~3 天)。合作方回复 + NPU 到位后:C1→C2 约 1 周。
