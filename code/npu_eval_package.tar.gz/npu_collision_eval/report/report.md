# NPU 碰撞检测 —— 阶段级对比测评报告

```
timestamp: 2026-09-10T11:00:51
lanes: ['cpu_fp64', 'npu']
modes: ['free', 'hybrid']
nstep: 15
seeds: [0]
jitter: 0.0
```

## 总判定

**PASS ✅** — pass_rate = 1.000

| mode:stage | pass/total |
|---|---|
| free:S10 | 45/45 |
| free:S3 | 45/45 |
| free:S4 | 45/45 |
| free:S6 | 45/45 |
| free:S9 | 45/45 |
| hybrid:S9/S10 | 13/13 |

## S3 碰撞阶段误差(按 case 聚合最坏值)

| case | tier | lane | missed | flip | ncon(r/t) | dist_p95 | pos_p95 | normal°_p95 |
|---|---|---|---|---|---|---|---|---|
| box_drop | scene | npu | 0.000 | 0.000 | 0/0 | 0.00e+00 | 0.00e+00 | 0.00 |
| box_stack3 | scene | npu | 0.000 | 0.000 | 12/12 | 0.00e+00 | 0.00e+00 | 0.00 |
| spheres_20 | scene | npu | 0.000 | 0.000 | 31/31 | 0.00e+00 | 0.00e+00 | 0.00 |

## 混合模式 —— 碰撞差异是否影响下游

| case | lane | qacc_linf | qpos_linf | ncon(test/cap) | pass |
|---|---|---|---|---|---|
| box_plane | npu | 0.000e+00 | 0.000e+00 | 2/2 | ✅ |
| box_box_vf | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| box_box_ee | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| box_box_ee_deep | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| plane_sphere | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| plane_ellipsoid | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| plane_capsule | npu | 2.015e-12 | 1.388e-17 | 2/2 | ✅ |
| convex_convex | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| capsule_capsule | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| sphere_sphere_overlap | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| sphere_plane_grazing | npu | 0.000e+00 | 0.000e+00 | 1/1 | ✅ |
| capsule_capsule_parallel | npu | 0.000e+00 | 0.000e+00 | 2/2 | ✅ |
| box_plane_flush | npu | 0.000e+00 | 0.000e+00 | 4/4 | ✅ |
