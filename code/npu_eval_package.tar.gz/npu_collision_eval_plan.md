# NPU 碰撞检测优化 — 按流程走的检测测评方案

> 对象：在 NPU（bluenpu 裸金属服务器）上优化运行的 MuJoCo **碰撞检测阶段**（`mj_collision` / 窄相位 / CCD）。
> 目标：证明 / 证伪「把碰撞检测 offload 到 NPU」在**数值正确性**、**确定性**、**性能**三个维度上是否达标。
> 方法论基线：MuJoCo 官方单元测试体系（`test/engine/engine_collision_*_test.cc`）+ 官方性能基准（`test/benchmark/ccd_benchmark_test.cc`）。
> 配套文档：`npu_collision_eval_tables_A_B.md`（表 A 碰撞函数矩阵 / 表 B 官方用例池）、`evaluation_metrics_survey.md`、`mesh_optimization_evaluation_survey.md`、`mujoco_benchmarks_and_unittests_survey.md`、`conclusion.md`。
> pin：MuJoCo 源码 `~/mujoco` @ `f9a00bd`。全流程以此 commit 为准。

---

## 0. 搭建阶段总览（第二部分 Phase 0–6 的鸟瞰；每次跑的执行流程见 § E）

```
Phase 0  范围锁定 ──────────────► 冻结 offload 边界 / 精度 / 算法参数（合作方确认）
   │
Phase 1  复用官方测试基座 ──────► 直接挪用 fixture / benchmark harness / testdata，搭好 C++ + Python 双跑道
   │
Phase 2  建 CPU 参考 + golden ──► fp64 与 fp32 两个 CPU 构建；dump 每个 case 的 contact + CCD 诊断 + timer，存 checksum
   │       └── 副产物：fp64-vs-fp32 差异 = NPU 误差的物理下界，用来标定 Phase 3 的容差
   │
Phase 3  用例库 + 指标表定稿 ──► cases/*.yaml（对齐表 A×表 B）；每个指标写死阈值与门禁规则
   │
Phase 4  NPU parity 跑 ────────► 三路对照（CPU-fp64 / CPU-fp32 / NPU）跑同一 case 池，产出逐算子误差表
   │
Phase 5  性能 + 下游敏感度 ────► 复用 ccd_benchmark / step_benchmark；接触喂回同一 CPU 求解器测 qacc 偏差
   │
Phase 6  门禁 + 报告 ──────────► CI gate（漏检=0 且 p95 达标 且 加速比达标 且 整步不劣化）；按 mjCOLLISIONFUNC 出报告
```

**这份文档分两部分：**

- **第一部分 = 测评执行流程（§ E）**：冻结素材后，**每次**要评测一个 NPU 碰撞检测构建时，按顺序跑的流水线。这才是「按流程走的测评」本身 —— 类比 MuJoCo 官方的 `ctest` + CI 流程。
- **第二部分 = 一次性搭建（Phase 0–6）**：为执行流程准备素材（参考构建、golden、cases、阈值、harness）。做完一次，之后只在 MuJoCo 版本升级或 NPU 接口变更时重做。

Phase 0 未完成前，Phase 1–2 中「与硬件无关」的部分可并行开工。

---

# 第一部分：测评执行流程（§ E）

> 前提：Phase 0–6 已完成，以下资产已冻结并入库：`ref-fp64` / `ref-fp32` 构建、`golden/`（含 checksum）、`cases/*.yaml`、`metrics_spec.md`（阈值）、`npu_eval/` harness。
> 触发时机：① 每个新的 NPU 碰撞检测构建（提交级）；② 每晚 nightly（含 fuzz）；③ MuJoCo / NPU SDK 版本变更（先重跑 Phase 2 再跑本流程）。
> 输入：一个 NPU 构建标识（commit / 镜像 tag）。
> 输出：PASS / FAIL + `report/npu_collision_eval_report.md`。

> **已实现**：`npu_collision_eval/`（Python 包，可直接跑）。它把 § E 的核心做成**阶段级**（pipeline-stage）对照——不看碰撞算子内部，只在 `mj_step` 各阶段边界比 `mjData`。四条泳道（`cpu_fp64` / `cpu_fp32` / `mjwarp` / `npu`）、两种模式（`free` 自由运行逐阶段对照 / `hybrid` 碰撞喂回 CPU 求解器测下游）。见该目录 `README.md` 与下方 **§ E.impl**。E0/E1/S3/S4/S6/S9/S10/下游/报告已落地；E5 不变量、E6 确定性、E8 完整性能基准、E9 fuzz 为待补。

```
E0 环境校验 ─gate→ E1 冒烟 ─gate→ E2 逐算子 parity ─gate→ E3 连续误差 ─gate→
E4 全场景 parity ─gate→ E5 不变量 ─gate→ E6 确定性 ─gate→ E7 下游敏感度 ─gate→
E8 性能 ─gate→ E9 fuzz(非阻塞) ──→ E10 判定 + 报告
```

任一 gate 不过：阻塞级 stage（E0–E8）**立即停**，标 FAIL，报告写清停在哪、差多少；非阻塞级（E9）记录后继续。

| Stage | 输入 | 动作 | 直接用的官方件 | Gate（通过判据） | Fail 处理 |
|---|---|---|---|---|---|
| **E0 环境校验** | NPU 构建、冻结资产 | ① 校验 `golden/manifest.csv` 每条 sha256 未漂移；② NPU 构建能 `mj_loadXML` 加载全部 case 模型；③ dump NPU 侧 `opt.{ccd_iterations,ccd_tolerance,broadphase,disableflags}`，与 golden meta 逐项比对 | `test/fixture.h` 的 `LoadModelFromPath`、`MujocoErrorTestGuard` | golden 无漂移 **且** 全模型可加载 **且** `opt.*` 开关与 golden 完全一致 | 停。开关不一致→要么改 NPU 配置要么重生成 golden；不可「带病继续」 |
| **E1 冒烟** | `particle.xml`、`collision_driver/humanoid.xml`、`perf/mixed.xml` | NPU 后端各跑 200 步，检查不崩溃、无 `mju_error`、`ncon > 0`、无 NaN | `test/sample/` 冒烟测试思路；`test/benchmark` 的 `TestHarness` 预热逻辑 | 三个模型都跑完且 `ncon>0` 且无 NaN | 停。这是最基本的「能跑」 |
| **E2 逐算子 parity（单帧静态）** | `cases/` 中 `tier ∈ {analytic, degenerate}`（≥57 个，47 抽自 `gjk_test.cc`） | 对每个 case 取初始 keyframe，三路（fp64/fp32/npu）各调被 offload 的 kernel（`mjc_ccd` 或 `mj_collision`），`contact_dump` → `contact_match` | `engine_collision_gjk_test.cc` 骨架 + 内联模型 + expected 值；`engine_collision_box_test.cc` 的 `ThinBox*` / `EdgeContactAtDepthBound` | **漏检率 == 0** 且 **法向翻转率 == 0** 且 `ncon` 与 fp64 一致（允许 fp32 已知抖动） | 停。逐 case 列出 missed / 翻转的 geom 对 |
| **E3 连续误差核对** | E2 的匹配集 | 在匹配集上算 深度误差 / 位置误差 / 法向夹角 / 切平面夹角 / CCD 迭代差，按算法族 + 按穿透深度分桶，取 p95/max | `mjCCDStatus.{gjk_iterations,epa_iterations,epa_status}`；`compare_model.h` 的相对差思路 | 每个算法族的 {深度 p95, 位置 p95, 法向 p95, 迭代差 p95} ≤ `metrics_spec.md` 阈值（阈值 = fp32 对照值 × 1.5 或绝对下限） | 停。输出超阈值的族 + 分桶曲线（定位是不是深穿透档崩） |
| **E4 全场景 parity（N 步 rollout）** | `cases/` 中 `tier == official_scene`（humanoid / midphase / mixed / stacked_boxes / particle） | 固定初值跑 N 步（N ≤ 混沌时间尺度），逐帧三路 dump `d->contact` + `d->ncon` + `timer`，逐帧 `contact_match` | `engine_collision_driver_test.cc` 的 `ContactCount` / `MaxContact` / `MarginSumming` / `FilterParent` 断言写法；`mj_getState`/`mj_setState` | 逐帧 **漏检率 == 0** 且 `ncon` 逐帧一致率 ≥ 阈值 且 **broadphase 候选对不是 CPU 的子集** 且 法向翻转率 == 0 | 停。给出首个发散帧 + 该帧的接触差异 |
| **E5 不变量检查** | `cases/` 中 `tier == invariant` + fuzz 抽样 1000 对 | 无需 golden：断言 法向指向 geom1→geom2；witness 到表面距离 ≈ 0；交换 geom1/geom2 → 法向翻转、深度不变；平移穿过 → 穿透深度连续（数值单调/无跳变） | `engine_collision_gjk_test.cc` 的不变量测试模式（如 rotation-sweep） | 全部不变量通过（容差 = fp32 同项水平） | 停。不变量违反 = 结构性 bug |
| **E6 确定性** | E4 用过的 3 个场景 | NPU 同输入重复跑 1000 次，比每次 `d->contact` 是否 bit 一致；记录 `epa_status` 分布跨次是否稳定 | `mj_getState`/`mj_setState`；`test/benchmark` 的 `Reset()` 模式 | bit 一致；**若异步 reduction 导致不一致** → FP 抖动 ≤ 预先声明的上界，且该上界已并入 E3 容差 | 停（除非抖动上界已在 metrics_spec 中登记并 review 通过） |
| **E7 下游敏感度** | E4 各场景每帧 NPU 产出的 `d->contact` | 把 NPU 接触喂进 `ref-fp64` 的约束求解器（只替换碰撞、其余全 CPU-fp64），比 `qacc`、单步 `qpos`、N 步轨迹发散曲线；对 `ref-fp32` 走同流程做对照 | MuJoCo pipeline 函数 `mj_fwdConstraint` 及之后；`evaluation_metrics_survey.md` §2.5 轨迹一致性 RMSE | `‖qacc_npu − qacc_ref‖∞` 的 p95 ≤ 阈值（与 fp32 接触喂求解器同量级）且 短 horizon 轨迹不超 fp32 发散包络 | 停。这一步 fail = 碰撞差异确实污染仿真结果 |
| **E8 性能** | 全部 benchmark 模型 | 复制自 `ccd_benchmark_test.cc` 的 5 个 BM + `step_benchmark_test.cc` 的 3 个 BM，三路各跑（预热 1000 / 批 50 / 线程 0 与 9）；读 `timer[POS_COLLISION / COL_BROAD / COL_NARROW]` 与端到端 `mj_step` 耗时；跑 `particle.xml` N 扫描曲线 + host↔NPU 传输打点 | **`test/benchmark/ccd_benchmark_test.cc` 整个 `TestHarness` 类**；`test/benchmark/step_benchmark_test.cc`；Google Benchmark | 碰撞阶段加速比 ≥ Phase 0 约定目标 **且** `mj_step` 端到端不慢于纯 CPU（扣除传输后）**且** 加速比-规模曲线随 N 单调不退化 | 停（性能不达标即评测失败；但报告仍要给出「阶段加速比 × 阶段占比 − 传输 = 整步净收益」的账） |
| **E9 fuzz（非阻塞，nightly）** | 随机 geom 对 + 随机位姿生成器，N ≥ 1e5 | 三路跑，报漏检率 / 深度 / 法向的**分布**（mean/p95/p99/max），与历史 nightly 对比看回归趋势 | `engine_collision_gjk_test.cc` fuzz/sweep 模式；`mujoco.rollout` | 无硬 gate；p99 相对上次 nightly 恶化 > 20% 则告警（不阻塞） | 记录、开 issue、继续 |
| **E10 判定 + 报告** | E0–E9 全部结果 | `gen_report.py` 出逐 `mjCOLLISIONFUNC` 误差表 + 分桶曲线 + 性能表 + 下游图 + 确定性结论 + 「值不值」的账；CI 依 §6.1 门禁公式判 PASS/FAIL | `report/gen_report.py`；CI mirror `test/CMakeLists.txt` 的 `gtest_discover_tests` | — | — |

**执行流程与官方 `ctest` 流程的对应**：E2/E4/E5 = 官方 `engine_collision_*_test`（正确性，红/绿）；E8 = 官方 `ccd_benchmark` + `step_benchmark`（性能回归）；E10 的 CI 判定 = 官方 PR 门禁（`CONTRIBUTING.md`：无测试不合并）。差异在于我们多了 E3（分族分桶的容差制，因为 fp32 不可能 bit-parity）、E6（NPU 异步带来的确定性风险）、E7（下游敏感度，回答「碰撞差异影不影响仿真」）。

---

## § E.impl — 已实现的阶段级 harness（`npu_collision_eval/`）

把「逐算子 parity」换成「阶段边界 mjData 对照」。理由：与 NPU 内部实现无关、和 MJWarp 的测试做法一致、直接对上「效果有无差异 / 能不能更好」——因为「效果」就是 S9 的 `qacc` 和 S10 的轨迹。算子级只在 S3 gate 失败时作诊断工具，不进常规流程。

**阶段分解**（`npu_eval/stages.py`，已验证依次调用下列函数 == `mj_forward()` + `mj_Euler()` 逐位相同）：

| 阶段 | mujoco 函数 | 官方 timer | 对照的 mjData | NPU 改动 |
|---|---|---|---|---|
| S1 | `mj_fwdKinematics` `mj_makeM` `mj_factorM` | `POS_KINEMATICS` `POS_INERTIA` | `geom_xpos` `geom_xmat` `qM` | 否（应 bit 相同，自检点） |
| **S3** | `mj_collision` | `POS_COLLISION` `COL_BROAD` `COL_NARROW` | **`ncon` `contact[]`**(dist/pos/frame/dim/geom/friction) | **是（唯一）** |
| S4 | `mj_makeConstraint` `mj_island` | `POS_MAKE` | `nefc` `efc_J` `efc_pos` | 传播 |
| S5 | `mj_projectConstraint` `mj_transmission` | `POS_PROJECT` | `efc_AR` 相关 | 传播 |
| S6 | `mj_fwdVelocity` | `VELOCITY` | `efc_aref` `qfrc_bias` | 传播 |
| S7 | `mj_fwdActuation` `mj_fwdAcceleration` | `ACTUATION` | `qfrc_smooth` `qacc_smooth` | 否 |
| **S9** | `mj_fwdConstraint` | `CONSTRAINT` | **`qacc`** `efc_force` `qfrc_constraint` `solver_niter` | 传播（下游关键） |
| S10 | `mj_Euler`/`mj_implicit`/`mj_RungeKutta` | `ADVANCE` | **`qpos` `qvel` `act` `time`** | 传播（最终结果） |

**两种运行模式**（`npu_eval/runner.py`）：

- `run_free`（模式 A）：各泳道从同一初值跑 N 步，每步在 S3/S4/S6/S9/S10 边界 `snapshot()`，`stage_metrics()` 逐阶段对照 `cpu_fp64`，`check_stage()` 判 gate。看碰撞差异经 S4→S9→S10 是收敛还是发散。
- `run_hybrid`（混合）：被测泳道只跑 `collision_only()`，接触注入一份新的 `cpu_fp64` mjData 跑 S4..S10，比 `qacc` / 下一帧 `qpos` 与纯 `cpu_fp64` 差异。**这一步就是原 E7 下游敏感度**，回答「碰撞差异影不影响仿真」。

**E 阶段 → 代码**：E0 `tests/test_e0_env.py`（golden sha256 / 模型加载 / mj 版本）；E1 `tests/test_e1_smoke.py`；E2+E3+E4 合并为 `run_free` 的 S3 gate（漏检=0 / 翻转=0 / `dist,pos,normal` p95，p95 阈值待 `cpu_fp64`-vs-`cpu_fp32` band 标定）；E7 `run_hybrid`；E10 `report.py` + `run_eval.py` 退出码。**待补**：E5 不变量、E6 确定性重复 1000 次、E8 完整挪用 `ccd_benchmark`/`step_benchmark`、E9 fuzz。

**直接挪用的官方件（已落地在代码里）**：`mujoco.mj_*` 阶段函数逐个调（= `mj_step1/mj_step2` 之外的官方 pipeline 切分）；官方 `mjTIMER_*`（`set_mjcb_time(time.perf_counter)` 后 `d.timer[i].duration` 生效）；无序接触匹配器 + 两档容差（`5e-2/1e-2` 几何、`5e-4` 材料）逐字抄自 `mujoco_warp/_src/collision_driver_test.py`；`_FIXTURES` 前 9 条逐字来自同文件；结构对标 `test/pipeline_test.cc`（跨配置跑同一 pipeline 比 mjData，fp64 `1e-11` / fp32 `1e-4`）。

**唯一必填**：`npu_eval/lanes.py:NpuHandle.collision_only(qpos, qvel) -> [N,21]`。无 NPU 时自动降级为 mock 泳道（= `cpu_fp64` + fp32 截断 + 确定性扰动），整条流水线可跑通、gate 逻辑可自检。

---

# 第二部分：一次性搭建（Phase 0–6）

> 以下 6 个 Phase 产出 § E 执行流程所消费的全部冻结资产。做完一轮后，仅在 MuJoCo 版本升级 / NPU 接口变更时重做相应 Phase。

## Phase 0 — 范围锁定（合作方确认，1 天，阻塞后续）

### 必须问到的 5 个问题（答案决定后面每一步的具体内容）

| # | 问题 | 影响 |
|---|---|---|
| 1 | offload 的边界：broadphase / 窄相位分派 / GJK+EPA / multiCCD，哪几段在 NPU？调用点是整个 `mj_collision()`，还是替换某几个 `mjCOLLISIONFUNC` 表项？ | 决定 Phase 4 是「逐算子 parity」还是「整阶段 parity」，决定 case 池按表 A 哪几族铺 |
| 2 | 精度：fp32 / bf16 / 混合 / 定点？中间累加用什么精度？ | 决定 Phase 2 的 fp32 参考怎么编，决定 Phase 3 容差档位数量 |
| 3 | CCD 参数：`m->opt.ccd_iterations` / `ccd_tolerance` 是否沿用 CPU 值？还是改成固定迭代次数？ | 若改动 → 不是同一算法，Phase 4 必须单列「算法变体」一档，不能混进主对照 |
| 4 | 对标的 CPU 实现：native CCD（默认）还是 libccd/MPR（`mjDSBL_NATIVECCD`）？multiCCD 开还是关？ | Phase 2 golden 必须用同一套开关生成，否则对照口径错 |
| 5 | 接口形态：host 每步上行什么（geom 位姿 / AABB / mesh 数据）、下行什么（`mjContact` 数组 / `mjCCDStatus`）？同步还是异步？接触对最终排序规则？ | 决定 Phase 5 传输开销怎么测；异步 → Phase 4 需加 bit 一致性重复实验 |

**退出条件**：拿到一页纸的书面确认（5 个答案 + NPU 侧代码/接口访问方式）。存档为 `phase0_scope.md`。

---

## Phase 1 — 复用官方测试基座（3 天，硬件无关，可立即开工）

目标：不重新造轮子。把 MuJoCo 官方 `test/` 里能直接用的部分整体搬进一个新目录，搭好 C++ 和 Python 两条跑道。

### 1.1 目录布局（镜像官方 1:1 白盒风格）

```
mujoco/                              # = ~/mujoco @ f9a00bd，作为 submodule 或固定 tag
npu_eval/
├── CMakeLists.txt                   # 复制 test/engine/CMakeLists.txt 的 mujoco_test() 宏用法
├── harness/
│   ├── fixture.h  fixture.cc        # ← 直接复制 mujoco/test/fixture.{h,cc}（见 1.2）
│   ├── compare_model.h  .cc         # ← 直接复制 mujoco/test/compare_model.{h,cc}
│   ├── contact_dump.h  .cc          # 新写：dump d->contact + mjCCDStatus + timer 到 JSON
│   └── contact_match.py             # 新写：接触匹配器（漏检/虚检/匹配集）
├── cases/                           # Phase 3 产出：*.yaml case 清单
├── golden/                          # Phase 2 产出：fp64 / fp32 参考 dump + checksum
├── engine_collision_npu_test.cc     # ← 骨架复制 mujoco/test/engine/engine_collision_gjk_test.cc
├── engine_collision_driver_npu_test.cc  # ← 骨架复制 engine_collision_driver_test.cc
├── ccd_npu_benchmark_test.cc        # ← 直接复制 mujoco/test/benchmark/ccd_benchmark_test.cc，改 TestHarness
├── step_npu_benchmark_test.cc       # ← 直接复制 mujoco/test/benchmark/step_benchmark_test.cc
└── report/
    └── gen_report.py               # 按 mjCOLLISIONFUNC 出误差表
```

### 1.2 直接挪用清单（逐项，改动量标注）

| 官方件 | 路径 | 怎么用 | 改动 |
|---|---|---|---|
| **测试 fixture** | `test/fixture.h` `fixture.cc` | `LoadModelFromPath` / `LoadModelFromString` / `GetModelPath` / `GetTestDataFilePath` / `MujocoErrorTestGuard` / `MockWarningHandler` | **零改动**，整文件复制 |
| **模型逐字段比对** | `test/compare_model.h` `.cc` | `CompareModel(m1, m2, field)` 返回最大相对差 + 出错字段名 | 零改动 |
| **GoogleTest 断言风格** | — | `EXPECT_THAT(x, Pointwise(DoubleNear(tol), expected))`、`ElementsAre`、顶部 `constexpr mjtNum kTolerance` | 照抄 `engine_collision_gjk_test.cc` 的写法 |
| **CCD 单元测试骨架** | `test/engine/engine_collision_gjk_test.cc`（2135 行，47 内联模型，25 `MjGjkTest`） | 把内联 XML 模型 + `mjc_ccd` 调用逻辑抽出来，改成 parametrized（遍历 case 池 × {fp64, fp32, npu}） | 中等：加参数化、加三路对照 |
| **全场景驱动测试骨架** | `test/engine/engine_collision_driver_test.cc`（`MjCollisionTest`：`ContactCount` / `MaxContact` / `MarginSumming` / `FilterParent` …） | `ContactCount` / `MaxContact` 直接给「结构性指标」断言写法；`FilterParent` / `TestOBB` 给 broadphase 断言写法 | 小：换模型、加 NPU 分支 |
| **box 专用测试** | `test/engine/engine_collision_box_test.cc`（`ThinBox*` / `DeepPenetration` / `EdgeContactAtDepthBound`） | 精度退化最易翻车的位形，整组纳入回归池 | 小 |
| **CCD 性能基准 harness** | `test/benchmark/ccd_benchmark_test.cc` 的 `TestHarness` 类（`kNumWarmupSteps=1000`、`kBatchSize=50`、`kNumThreads=9`，`mju_threadpool`，`mjSTATE_INTEGRATION` 存取） | **整类复制**。`RunBenchmark` 里累加 `ncon` 并计时的模式照搬 | 中等：`SetThreads` 旁边加 `SetBackend(NPU)`；计时读 `d->timer[mjTIMER_POS_COLLISION]` |
| **整步性能基准** | `test/benchmark/step_benchmark_test.cc`（`BM_StepHumanoid` / `BM_StepHumanoid100` / `BM_StepParticle`） | 证明碰撞加速没被 host↔NPU 传输吃掉整步收益 | 小 |
| **Google Benchmark 框架** | 官方已依赖 | `BENCHMARK(BM_x)->Arg(0)->Arg(9)` | 零改动 |
| **测试模型文件** | `test/engine/testdata/collision_*`、`test/engine/testdata/collisions.xml`、`test/benchmark/testdata/*`、`model/humanoid/*`、`model/replicate/particle.xml` | 见表 B。直接 `LoadModelFromPath` | 零改动（`model/` 需 `git checkout -- model/` 实体化） |
| **CMake 测试注册宏** | `test/CMakeLists.txt` 的 `macro(mujoco_test name)` + `test/engine/CMakeLists.txt`（`mujoco_test(engine_collision_box_test ADDITIONAL_LINK_LIBRARIES ccd)`） | 复制宏，注册 `engine_collision_npu_test` | 小 |
| **状态快照 API** | `mj_stateSize` / `mj_getState` / `mj_setState` + `mjSTATE_INTEGRATION` | 固定初值、可复现 rollout | 零改动 |
| **内置分阶段计时** | `d->timer[mjTIMER_POS_COLLISION / COL_BROAD / COL_NARROW]`（对齐 `conclusion.md` §3.2） | 性能报告的唯一计时口径 | 零改动 |
| **CCD 诊断量** | `mjCCDStatus.{gjk_iterations, epa_iterations, epa_status, nx}` | 确定性 / 收敛一致性指标数据源 | 零改动（需从 `mjc_penetration` 透出，或加一个 debug hook） |
| **Python 绑定 rollout** | `mujoco` 包 + `mujoco.rollout` | Phase 5 批量 rollout 吞吐、快速 fuzz | 零改动 |

### 1.3 交付物 & 退出条件

- `npu_eval/` 目录能 `cmake --build` 通过，`engine_collision_npu_test`（此刻只跑 CPU-fp64 自比对，应全绿）+ `ccd_npu_benchmark_test`（跑官方 5 个 BM，出基线数字）可执行。
- 一份 `reuse_manifest.md` 记录上表每一项的实际复制/改动情况。

---

## Phase 2 — CPU 参考基座 + golden 管线（5 天，硬件无关）

这是整个方案的地基，**必须在 NPU 接入前完成**。

### 2.1 两个 CPU 参考构建

| 构建 | 配置 | 角色 |
|---|---|---|
| `ref-fp64` | 官方默认（`mjtNum = double`），`~/mujoco` @ `f9a00bd` 原样编译 | 「物理正确」的黄金参考；也是精度天花板 |
| `ref-fp32` | `mjtNum = float` 重编（改 `mjtnum.h` 或编译宏），其余不变 | **公平对照锚点**：NPU 若用 fp32，其误差应主要相对这个，而非 fp64 |

> 若 Phase 0 答案是 bf16 / 定点，再加一个对应的 `ref-*` 软件模拟构建（用软件模拟低精度算子），口径同上。

### 2.2 golden dump 内容（每个 case、每步）

`contact_dump.cc` 输出 JSON：

```
per_step:
  ncon
  contacts[]: {geom1, geom2, dim, pos[3], dist, frame[9], normal[3], includemargin, friction[5], solref, solimp}
  ccd_status[]: {pair, gjk_iterations, epa_iterations, epa_status, nx}   # 仅走 mjc_Convex 的对
  timer: {POS_COLLISION, COL_BROAD, COL_NARROW}
meta: {model_path, keyframe, nstep, mj_commit, build=ref-fp64|ref-fp32, opt.{ccd_iterations,ccd_tolerance,broadphase,disableflags}, sha256}
```

- 排序：**先按 MuJoCo 确定性接触排序规则重排再 dump**（NPU 并行窄相位后也要按同规则重排）。
- checksum：整个 JSON 的 sha256 写进 `golden/manifest.csv`，回归时先比 checksum。

### 2.3 接触匹配器 `contact_match.py`

输入两份 dump（A=参考，B=被测），逐步：
1. 按 `(geom1, geom2)` 分组，组内按 `pos` 最近邻匹配（阈值 = `rel_tol · min(rbound1, rbound2)`，`rel_tol` 默认 `1e-3`，与 `mjc_Convex` 里 `mjc_isDistinctContact` 同源）。
2. 输出：`matched[]`、`missed[]`（A 有 B 无 → **漏检**）、`spurious[]`（B 有 A 无 → 虚检）。
3. 匹配集上算连续误差（见 Phase 3）。

### 2.4 关键副产物：fp64-vs-fp32 对照

对整个 case 池跑 `ref-fp64` vs `ref-fp32` 的匹配。产出：
- 纯精度损失能造成多大漏检率 / `ncon` 不一致率 / 深度误差 / 法向夹角。
- **这就是 NPU 误差的物理下界**。Phase 3 的容差阈值以此为经验依据（NPU 容差不能定得比 fp32 单独的误差还严）。
- 顺带回答历史疑问：apple_8/11 的大轨迹偏移，是精简 mesh 质量差，还是纯 fp 精度 + 混沌放大（对照 `mesh_optimization_evaluation_survey.md` §3.1）。

### 2.5 交付物 & 退出条件

- `golden/` 下每个 case 有 `ref-fp64.json` + `ref-fp32.json` + checksum。
- `phase2_fp32_vs_fp64_report.md`：每个算法族（表 A.2）一行，列漏检率 / 深度 p50/p95/max / 法向 p95。
- `contact_match.py` 在 fp64 自比对下输出全零差异（自洽性检查）。

---

## Phase 3 — 用例库 + 指标表定稿（4 天）

### 3.1 用例库 `cases/*.yaml`（对齐 表 A 族 × 表 B 池）

每个 case：

```yaml
id: gjk_ellipsoid_ellipsoid_slowconv
source: mujoco/test/engine/engine_collision_gjk_test.cc  # 直接来自官方
family: mjc_Convex          # 表 A.2 的族
geom_pair: [ellipsoid, ellipsoid]
model: inline|<path>
keyframe: 0
nstep: 1                    # 单帧 parity，或 N 步 rollout
has_analytic_truth: false
tier: degenerate            # analytic | degenerate | official_scene | fuzz | invariant
notes: EPA 慢收敛位形，fp32 最可能发散
```

五层 tier（对齐官方分层）：

| tier | 来源 | 例 |
|---|---|---|
| `analytic` | 新写少量 | sphere-sphere / sphere-plane / 平行 capsule / box-plane 静置；让分离距离**扫过 margin 边界** |
| `degenerate` | **直接抽自** `engine_collision_gjk_test.cc`（47 内联模型）+ `box_test.cc`（`ThinBox*` / `EdgeContactAtDepthBound`）+ `edge_edge.xml` / `long_box.xml` | edge-edge、vertex-face、共面退化流形、深穿透、`EllipsoidEllipsoidSlowConvergence` |
| `official_scene` | **直接用** 表 B.2 模型文件 | `collision_driver/humanoid.xml`（capsule 自碰）、`midphase.xml`（1000 box）、`perf/mixed.xml`（全类型上百 geom）、`stacked_boxes.xml`、`particle.xml`（1000 sphere） |
| `fuzz` | 新写生成器 | 随机 geom 对 + 随机位姿，大 N（≥1e5），报分布 |
| `invariant` | 新写断言（无需 golden） | 法向指向 geom1→geom2；witness 落在表面（到面距离≈0）；交换 geom1/geom2 → 法向翻转、深度不变；一个 geom 平移穿过另一个 → 穿透深度连续 |

抽取脚本：`extract_gjk_cases.py` 把 `engine_collision_gjk_test.cc` 里 `R"(...)"` 内联 XML + 对应的 expected 值 dump 成 `cases/gjk_*.yaml` + `golden/gjk_*.expected.json`。这批 expected 值是**官方维护的正确答案**，直接当 golden 用。

### 3.2 指标表（写死阈值 —— 这是方案的核心产物）

结构性指标（**门禁**，先看这些）：

| 指标 | 定义 | 阈值 | 阈值来源 |
|---|---|---|---|
| 漏检率 | `missed / (matched + missed)`，全 case 池汇总 | **= 0**（安全关键，硬门禁） | 无条件 |
| 虚检率 | `spurious / (matched + spurious)` | ≤ Phase 2 fp32 值 × 1.5 | fp32 对照标定 |
| `ncon` 逐帧一致率 | `Σ [ncon_npu == ncon_ref] / nframe` | ≥ 官方多点接触本就有的抖动水平（由 fp32 对照测出） | fp32 对照 |
| 接触集 IoU | 按 `(geom1,geom2,pos邻近)` 匹配后的 Jaccard | ≥ 0.98（primitive 族）/ ≥ 0.90（`mjc_Convex` 族） | fp32 对照分族标定 |
| 法向翻转率 | 匹配集中 `angle(n_npu, n_ref) > 90°` 占比 | **= 0** | 无条件（翻转是 bug 不是精度） |
| broadphase 集合关系 | NPU 候选对 vs CPU 候选对 | 允许**超集**（只损性能）；**子集 = fail**（非对称指标） | 无条件 |

连续指标（**仅在匹配集上算**，报 mean / p95 / max，按算法族 + 按穿透深度分桶）：

| 指标 | 定义 | 归一化 | p95 阈值 |
|---|---|---|---|
| 穿透深度误差 | `|dist_npu − dist_ref|` 及相对值 | 相对 `min(rbound)` | ≤ max(fp32 p95 × 1.5, 1e-4·rbound) |
| 接触点位置误差 | `‖pos_npu − pos_ref‖₂` | 除以 `min(geom_size)` | ≤ fp32 p95 × 1.5 |
| 法向夹角误差 | `acos(n_npu · n_ref)` 度 | — | ≤ 1.0°（primitive）/ ≤ 5.0°（`mjc_Convex`） |
| 切向帧误差 | 比**切平面**夹角，不比逐轴（切向有规范自由度） | — | ≤ 5° |
| CCD 迭代差 | `|gjk_iter_npu − gjk_iter_ref|`、`epa_status` 分布 KL | — | 迭代差 p95 ≤ 2；`epa_status` 失败码占比不高于 ref |

> 分桶：穿透深度 `[0, 1e-4)`、`[1e-4, 1e-3)`、`[1e-3, 1e-2)`、`≥1e-2`（相对 rbound）。EPA 在 fp32/深穿透下恶化，必须分桶看，不能只报总体。

下游敏感度指标（**最能支撑「值不值」的决策**）：

| 指标 | 做法 | 阈值 |
|---|---|---|
| `qacc` 偏差 | NPU 产出的 `d->contact` 喂进**同一个 CPU 约束求解器**（禁用 NPU 之外一切改动），比 `qacc` 与全 CPU 的 `‖·‖∞` | p95 ≤ 与 `ref-fp32` 接触喂求解器得到的偏差同量级 |
| 下一帧 `qpos` 偏差 | 单步积分后比 `qpos` | 同上 |
| N 步轨迹发散 | 固定初值跑 N 步，记录逐步 L2/L∞ 增长曲线；无接触区间收紧容差 | 短 horizon（≤ 混沌时间尺度）内不超 fp32 轨迹的发散包络 |

性能指标（Phase 5 详展）：

| 指标 | 口径 |
|---|---|
| 碰撞阶段加速比 | `timer[POS_COLLISION]_cpu / timer[POS_COLLISION]_npu`，对 `ref-fp64` 与 `ref-fp32` 各报一条 |
| broad / narrow 拆分 | `timer[COL_BROAD]`、`timer[COL_NARROW]` 分别报 |
| 整步是否劣化 | `timer_total` 的 `mj_step` 端到端，含 host↔NPU 传输，**不得慢于纯 CPU** |
| 扩展性 | 加速比随 geom 数 / 场景接触数的曲线（`particle.xml` N 扫描、`mixed.xml`） |
| 传输开销 | 上行（geom 位姿/AABB）、下行（contact）字节数与耗时；batch breakeven 规模 |
| 批量 rollout 吞吐 | `mujoco.rollout` 多环境并行，steps/sec（NPU 预期赢点） |

### 3.3 交付物 & 退出条件

- `cases/` 完整（analytic ≥ 10，degenerate ≥ 47 全抽自官方，official_scene 全部表 B.2，fuzz 生成器就绪，invariant 断言就绪）。
- `metrics_spec.md`：上面三张表 + 每个阈值的 fp32 对照实测依据。
- 阈值经过评审签字（合作方 + 你）。

---

## Phase 4 — NPU parity 跑（拿到硬件后 1 周）

### 4.1 三路对照

对整个 case 池，同一 case、同一初始 `mjSTATE_INTEGRATION`、同一 `opt.*` 开关，跑：

```
ref-fp64 (CPU) ──┐
ref-fp32 (CPU) ──┼──► contact_dump ──► contact_match ──► metrics_spec 全指标
npu           ──┘
```

- `engine_collision_npu_test.cc`（骨架来自 `engine_collision_gjk_test.cc`）parametrized 遍历 `cases/ × {backend}`。
- 逐算子模式：直接调被 offload 的 kernel（如 NPU 版 `mjc_ccd`），喂相同 `mjCCDObj`，比 `mjCCDStatus` + witness。
- 整阶段模式：调 `mj_collision`（NPU 后端），比 `d->contact` + `d->ncon`。

### 4.2 确定性专项

| 检查 | 做法 | 判据 |
|---|---|---|
| 重复一致性 | NPU 同输入重复跑 1000 次 | bit 一致；若异步 reduction 不一致 → 给出 FP 抖动上界并纳入容差 |
| warmstart 敏感度 | 关掉 warmstart（若碰撞阶段涉及）CPU/NPU 是否更接近 | 用于定位差异源（算子本身 vs 迭代路径） |
| active set 一致性 | broadphase 候选对集合、窄相位 `epa_status` 分布 | 与 CPU 一致率纳入报告；不一致会导致下游全发散 |
| 排序一致性 | NPU 并行窄相位后按 MuJoCo 规则重排 | 重排后 `contact[i]` 逐条可比 |

### 4.3 交付物

- `phase4_parity.jsonl`：每个 case × backend 的全指标原始值。
- 逐 `mjCOLLISIONFUNC` 误差表（`gen_report.py` 出，见 Phase 6）。

---

## Phase 5 — 性能 + 下游敏感度（与 Phase 4 并行，1 周）

### 5.1 性能：直接复用官方基准

| 官方基准 | 直接用法 | 加 NPU |
|---|---|---|
| `ccd_benchmark_test.cc`：`BM_BoxMesh` / `BM_BoxBox` / `BM_BoxBoxConvex` / `BM_Ellipsoid` / `BM_Mixed`（模型 `perf/box.xml` 100 box、`perf/boxmesh.xml` 100 mesh、`perf/mixed.xml` 全类型） | 整文件复制成 `ccd_npu_benchmark_test.cc`，`TestHarness` 加 `SetBackend`；`kNumWarmupSteps=1000` / `kBatchSize=50` / 线程 `0` 与 `9` 照搬 | CPU-fp64 / CPU-fp32 / NPU 三条 |
| `step_benchmark_test.cc`：`BM_StepHumanoid` / `BM_StepHumanoid100` / `BM_StepParticle` | 复制成 `step_npu_benchmark_test.cc` | 验证整步不劣化 + 扩展性 |
| `d->timer[]` | 每个 BM 里读 `POS_COLLISION` / `COL_BROAD` / `COL_NARROW` | 分阶段加速比 |

补充扫描（新写，用 `<replicate>` 改 count 或 Python 生成）：
- `particle.xml` N ∈ {125, 512, 1000, 4000, 8000}：broadphase 加速比 vs N 曲线。
- `mixed.xml` 复制倍数扫描：窄相位加速比 vs 接触数曲线。
- host↔NPU 传输：单独打点上行/下行字节 + 耗时，算 batch breakeven。

### 5.2 下游敏感度

`downstream_sensitivity.py`：
1. 跑 NPU 碰撞 → 得 `d->contact`。
2. 用 `ref-fp64` 的求解器接着算（`mj_fwdConstraint` 之后），得 `qacc_npu`。
3. 全 CPU-fp64 得 `qacc_ref`。
4. 报 `‖qacc_npu − qacc_ref‖∞` 分布、单步 `qpos` 偏差、N 步轨迹发散曲线。
5. 对照 `ref-fp32` 走同样流程 → 「NPU 相对 fp32 是否额外引入下游误差」。

> 这一步回答核心问题：**碰撞检测的差异到底影不影响仿真结果**。接触点偏 1mm 可能无所谓，漏一个接触则灾难。

### 5.3 「值不值」的诚实结论

对照 `conclusion.md` §5.2（碰撞检测占 `mj_step` 约 10–15%，NPU 对分支密集/串行迭代不友好）。报告必须正面回答：
- 碰撞阶段加速比 × 阶段占比 = 整步理论收益上限是多少？
- 扣掉 host↔NPU 传输后，整步实测是否真的更快？
- 只有在批量 rollout（`mujoco.rollout` 多环境）场景才赢，还是单场景也赢？

---

## Phase 6 — 门禁 + 报告（3 天）

### 6.1 CI 门禁（回归 gate）

```
PASS 当且仅当：
  漏检率 == 0
  且 法向翻转率 == 0
  且 broadphase 不是子集
  且 每个算法族的 {深度 p95, 位置 p95, 法向夹角 p95} ≤ metrics_spec 阈值
  且 下游 qacc 偏差 p95 ≤ 阈值
  且 碰撞阶段加速比 ≥ 目标值（Phase 0 约定）
  且 mj_step 端到端不慢于纯 CPU
  且 golden checksum 未漂移（或漂移已 review 并更新）
```

任一不满足 → CI 红。CCD 参数变体（Phase 0 Q3）单独一条非阻塞报告线。

### 6.2 报告结构

1. **逐 `mjCOLLISIONFUNC` 误差表**：`gen_report.py` 遍历表 A 每个非零函数，出一行 {样本数, 漏检率, 深度 p50/p95/max, 位置 p95, 法向 p95, 迭代差 p95, epa_status 分布}。分 fp32 / npu 两列对照。
2. **按穿透深度分桶的 `mjc_Convex` 误差曲线**（EPA 退化可视化）。
3. **性能**：5 个 `ccd_benchmark` 数字 + 加速比-规模曲线 + 传输开销 + batch breakeven + 整步端到端。
4. **下游敏感度**：`qacc` 偏差分布 + N 步轨迹发散图（NPU / fp32 / fp64 三条）。
5. **确定性**：重复一致性结论 + active set 一致率。
6. **结论**：对照 `conclusion.md` §5.2，明确 offload 碰撞检测的净收益 / 适用场景 / 不适用场景。
7. 对照设计合规声明（`optimization_vs_baseline_case_studies.md` §七模板）：控制变量、复杂度递增场景梯度、多 seed 均值±方差、硬件对等性标注、消融（关 multiCCD / 关 warmstart）。

### 6.3 交付物

- `report/npu_collision_eval_report.md`（+ 图）。
- CI 配置（GitHub Actions / 内部 CI），mirror `test/CMakeLists.txt` 的 `mujoco_test()` + `gtest_discover_tests` 注册方式。
- `golden/` + `cases/` + `metrics_spec.md` 作为可复现资产入库。

---

## 附：时间线 & 依赖

| Phase | 时长 | 依赖 | 可并行 |
|---|---|---|---|
| 0 范围锁定 | 1 天 | 合作方 | — |
| 1 复用基座 | 3 天 | — | 与 0 并行（无硬件部分） |
| 2 CPU 参考 + golden | 5 天 | 1 | 与 0 部分并行 |
| 3 用例库 + 指标表 | 4 天 | 2（要 fp32 对照标阈值） | 与 2 后半并行 |
| 4 NPU parity | 1 周 | 0,1,2,3 + NPU 访问 | 与 5 并行 |
| 5 性能 + 下游 | 1 周 | 1,2,3 + NPU 访问 | 与 4 并行 |
| 6 门禁 + 报告 | 3 天 | 4,5 | — |

**关键路径**：0 → 2 → 3 → (4‖5) → 6，约 4 周（拿到 NPU 访问后）。硬件到位前，0/1/2/3 可先做完（约 2 周）。

## 附：立即可执行的三件事（不依赖 NPU）

1. 跑 `extract_gjk_cases.py`：把 `~/mujoco/test/engine/engine_collision_gjk_test.cc` 的 47 个内联模型 + expected 值抽成 `cases/gjk_*.yaml` + `golden/gjk_*.expected.json`。
2. 建 `ref-fp32` 构建，对上一步的 case 池跑 fp64 vs fp32 匹配 → `phase2_fp32_vs_fp64_report.md`。这给出所有容差阈值的经验依据，也顺带定性 apple_8/11 的偏移成因。
3. 复制 `ccd_benchmark_test.cc` → `ccd_npu_benchmark_test.cc`，先跑纯 CPU 出 5 个基线数字。
