# NPU 碰撞检测测评 — 表 A（碰撞函数矩阵）与 表 B（官方用例/模型清单）

> 来源：本地 MuJoCo 源码 checkout `~/mujoco`，commit `f9a00bd`（约对应 3.3.x 主线；已安装的 Python 包为 3.11.0，方案里以源码 checkout 的 commit 为准并 pin 死）。
> 用途：这两张表是 NPU parity 测试的**行清单**（表 A）和**基准/回归用例池**（表 B），对应方案 Phase 1 的产物。

---

## 表 A — `mjCOLLISIONFUNC[type1][type2]` 碰撞函数矩阵

MuJoCo 的窄相位按 (geom_type1, geom_type2) 查一张 9×9 的函数指针表（`src/engine/engine_collision_driver.c:45`，`mjNGEOMTYPES = 9`）。矩阵对称，只填上三角。`0` = 该对不做碰撞（如 plane-plane、plane-hfield）。

### A.1 原始矩阵（源码原样）

```
             PLANE  HFIELD  SPHERE            CAPSULE             ELLIPSOID    CYLINDER            BOX          MESH        SDF
PLANE     |  0      0       mjc_PlaneSphere   mjc_PlaneCapsule    mjc_PlaneConvex  mjc_PlaneCylinder  mjc_PlaneBox mjc_PlaneConvex mjc_PlaneConvex
HFIELD    |  0      0       mjc_ConvexHField  mjc_ConvexHField    mjc_ConvexHField mjc_ConvexHField   mjc_ConvexHField mjc_ConvexHField mjc_HFieldSDF
SPHERE    |  0      0       mjc_SphereSphere  mjc_SphereCapsule   mjc_Convex   mjc_SphereCylinder mjc_SphereBox  mjc_Convex   mjc_SDF
CAPSULE   |  0      0       0                 mjc_CapsuleCapsule  mjc_Convex   mjc_Convex         mjc_CapsuleBox mjc_Convex   mjc_SDF
ELLIPSOID |  0      0       0                 0                   mjc_Convex   mjc_Convex         mjc_Convex   mjc_Convex   mjc_SDF
CYLINDER  |  0      0       0                 0                   0            mjc_Convex         mjc_Convex   mjc_Convex   mjc_SDF
BOX       |  0      0       0                 0                   0            0                  mjc_BoxBox   mjc_Convex   mjc_SDF
MESH      |  0      0       0                 0                   0            0                  0            mjc_Convex   mjc_MeshSDF
SDF       |  0      0       0                 0                   0            0                  0            0            mjc_SDF
```

### A.2 按算法族归类（这才是 NPU offload 要关心的粒度）

| 族 | 函数 | 覆盖的 geom 对 | 算法本质 | 解析真值 | fp32/定点主要风险 | 官方测试文件 |
|---|---|---|---|---|---|---|
| **纯解析 primitive** | `mjc_PlaneSphere` | plane–sphere | 点到平面距离 | ✅ 闭式 | 极小；margin 边界处 ncon 0/1 跳变 | `engine_collision_primitive.c`；driver test |
| | `mjc_PlaneCapsule` | plane–capsule | 两端球心到平面 | ✅ | 平行贴面时两点/一点跳变 | 同上 |
| | `mjc_PlaneCylinder` | plane–cylinder | 端面圆到平面 | ✅（部分退化） | 掠射/共面退化流形 | 同上 |
| | `mjc_PlaneBox` | plane–box | 8 顶点到平面，取最多 4 | ✅ | 恰好贴面时接触点数 4/3/1 跳变 | `engine_collision_box.c`；`engine_collision_box_test.cc` |
| | `mjc_SphereSphere` | sphere–sphere | 圆心距 | ✅ | 极小 | `engine_collision_gjk_test.cc:SphereSphere*`（GJK 侧也测） |
| | `mjc_SphereCapsule` | sphere–capsule | 点到线段 | ✅ | 端点/侧面切换 | primitive |
| | `mjc_SphereCylinder` | sphere–cylinder | 点到圆柱（分区） | ✅（分区） | 边缘（rim）分区边界 | `engine_collision_primitive.c`；`collision_primitive/sphere_cylinder.xml` |
| | `mjc_SphereBox` | sphere–box | 点到 box 最近点（clamp） | ✅ | 角/棱/面区切换 | `engine_collision_box.c:101`；`box_test.cc:BoxSphere` |
| | `mjc_CapsuleCapsule` | capsule–capsule | 线段–线段最近距离 | ✅（平行退化） | 平行时单点 vs 双点；近平行数值敏感 | primitive；`gjk_test.cc:CapsuleCapsule` |
| | `mjc_CapsuleBox` | capsule–box | 线段 vs box（多区） | 部分 | 多接触点生成、edge-edge | `engine_collision_box.c:603` |
| **专用 SAT** | `mjc_BoxBox` | box–box | 分离轴 + 面裁剪，最多生成多点 | 部分（静置可推） | **接触点集 4→1 跳变、法向选面翻转**、深穿透 | `engine_collision_box_test.cc`（BadContacts / DeepPenetration / ThinBox* / EdgeContactAtDepthBound）；`gjk_test.cc:BoxBox*` |
| **CCD（GJK+EPA+multiCCD）** | `mjc_Convex` | 任意"凸–凸"组合：sphere/capsule/ellipsoid/cylinder/box/mesh 相互间，凡是不落到专用函数的 | GJK 求距离/最近点 → 不相交则 witness；相交则 EPA 求穿透深度+法向；单点时 multiCCD 微扰再取点 | ❌（一般无；少数对称位形可推） | **最高**：EPA 在 fp32/bf16 下可能停在不同 simplex → 法向翻转、深度误差随穿透加深恶化；固定迭代预算下深穿透/近退化 case 退化；multiCCD 的 `1e-3` 容差受精度影响改变点数 | `engine_collision_gjk_test.cc`（2135 行，47 个内联模型，25 个 `MjGjkTest`）；`engine_collision_convex_test.cc`；`gjk_benchmark`≈`ccd_benchmark_test.cc` |
| | `mjc_PlaneConvex` | plane 对 ellipsoid/cylinder/mesh（走 libccd 的 plane-convex）+ plane-mesh 额外点 | 支撑函数沿 -plane_normal + 至多 3 个额外顶点点 | 部分 | plane-mesh 额外点的 `tolplanemesh=0.3·rbound` 阈值 | `gjk_test.cc`；`collision_convex/*` |
| | `mjc_ConvexHField` | hfield 对 sphere/capsule/ellipsoid/cylinder/box/mesh | 定位重叠的 hfield 三角棱柱子集，逐个走 CCD | ❌ | 子三角选取 + 每个子碰撞都继承 CCD 风险；边界棱柱漏选 | `collision_convex/frameless_contact_hfield.xml`；`convex_test.cc:FramelessContactHfield` |
| **SDF（非凸/梯度下降）** | `mjc_SDF` | sdf–sdf、sdf 对各 primitive | 对 SDF 数学函数多起点梯度下降求交点（`sdf_initpoints`） | ❌ | **结构性漏检风险**（局部极小）；起点数/步长对精度极敏感；分支密集，NPU 最不适合 | `engine_collision_sdf_test.cc:SdfPrimitive` |
| | `mjc_MeshSDF` | mesh–sdf | 同上，mesh 顶点作为起点 | ❌ | 同上 | `sdf_test.cc` |
| | `mjc_HFieldSDF` | hfield–sdf | 同上 | ❌ | 同上 | — |
| | `mjc_FlexSDF` | flex（可变形体）元素–sdf | 同上（`engine_collision_sdf.c:1248`） | ❌ | 同上 + flex 元素遍历 | `sdf_test.cc:FlexSdfCollision` |

**关键实现事实（写进方案，影响对照口径）**：

- CCD 路径由两个模型选项控制：`m->opt.ccd_iterations`（EPA/GJK 最大迭代）、`m->opt.ccd_tolerance`（收敛容差）。**NPU 版若改了这两个值或改成固定迭代，就不是同一算法，必须在方案里显式声明并单列一档对照。**
- `mjDSBL_NATIVECCD`：关掉则回退到 **libccd（MPR 算法）**，`mjc_penetration` 走 `_libccd_wrapper`。native CCD 与 libccd 结果本身就有差异——**先确认 NPU 对标的是哪一个**。
- `mjDSBL_MULTICCD`：关掉则凸–凸单点接触不做微扰补点。box/mesh 面接触会从多点退化成 1 点。对照时两边必须同设置。
- `mjMAXCONPAIR = 50`：单对 geom 最多 50 个接触点。
- CCD 诊断量可从 `mjCCDStatus` 读到：`gjk_iterations`、`epa_iterations`、`epa_status`（`mjEPAStatus` 枚举，如 `mjEPA_P3_ORIGIN_ON_FACE` 等失败码）、`nx`（witness 点数）。**这些是"确定性/收敛一致性"指标的直接数据源**——NPU 与 CPU 的迭代次数、epa_status 分布是否一致。
- 接触帧：`con.normal`（geom1→geom2 单位向量）、`con.pos`、`con.tangent`（切向，有规范自由度，比切平面不比轴）、`con.dist`（= `margin + 带符号距离`，负值=穿透）。

### A.3 建议的行优先级（若 NPU 范围未定，按此顺序铺测试）

1. **P0 解析 primitive**（PlaneSphere / SphereSphere / SphereBox / PlaneBox / CapsuleCapsule）：有闭式真值，先把 harness 跑通、把容差标定方法验证掉。
2. **P0 `mjc_BoxBox`**：离散不一致（接触点集、选面法向）最典型，且 MJX 文档点名 box-box 是优化重点。
3. **P1 `mjc_Convex`（GJK+EPA）**：真正的难点，误差按穿透深度分桶报。再细分 primitive-primitive（如 ellipsoid-ellipsoid，有 `gjk_test.cc` golden）与含 mesh 两类。
4. **P2 `mjc_ConvexHField`**：叠加 hfield 子三角选取误差。
5. **P3 `mjc_SDF` 族**：仅当 NPU 范围明确包含 SDF 才做；结构性漏检要单独立指标。

---

## 表 B — 官方碰撞相关用例 / 模型清单

分三块：B.1 单元测试用例（正确性断言，做 parity 对照的模板）、B.2 testdata 模型文件（可直接 load 的场景）、B.3 benchmark 模型（性能基线，加速比挂这里）。

### B.1 单元测试用例（`~/mujoco/test/engine/engine_collision_*_test.cc`）

| 文件 | 行数 | fixture | 用例（`TEST_F` 名） | 断言什么 | 对 NPU 测评的用法 |
|---|---|---|---|---|---|
| `engine_collision_gjk_test.cc` | 2135 | `MjGjkTest` (25) | `SphereSphereDist` / `SphereSphereDistCutoff` / `SphereSphereNoDist` / `SphereSphereIntersect`；`BoxBoxDepth{,2,3}` / `BoxBoxSize05{,b,c}` / `BoxBoxTouching` / `BoxBoxMultiCCD1..15`；`SmallBoxMesh` / `BoxMesh{,2}` / `BoxMeshPrune`；`MeshMesh{,Prune}`；`BoxEdge{,2}` / `BoxEdgeEdge` / `BoxEdgeFlipped`；`MeshEdge{,2}`；`EllipsoidEllipsoid{,Penetrating,Intersect,SlowConvergence}`；`BoxBox` / `BoxBoxLarge` / `LongBox`；`CapsuleCapsule`；`CylinderBoxMargin` | 直接调 `mjc_ccd` / `mjc_penetration`，用 `kTolerance=1e-6` `DoubleNear` 比 **距离、witness 点、法向**；`SlowConvergence` 专测迭代收敛 | **这就是逐算子 parity 测试的模板**。把每个内联模型抽出来，CPU-fp64 / CPU-fp32 / NPU 三路各跑一遍 `mjc_ccd`，比 dist/normal/witness + `gjk_iterations`/`epa_iterations`/`epa_status` |
| `engine_collision_box_test.cc` | 526 | `MjCollisionBoxTest` | `BadContacts` / `DuplicateContacts` / `DeepPenetration` / `BoxSphere` / `BoxBoxContactDistance` / `ThinBoxNoSpuriousDeepContact` / `ThinBoxShallowPenetration` / `ThinBoxTunneledPenetration` / `EdgeContactAtDepthBound` | box-box / box-sphere 的接触点数、深度、无虚假深接触、隧穿处理、edge 接触在深度边界的行为 | box 专用 SAT 的离散不一致回归池。`ThinBox*` 和 `EdgeContactAtDepthBound` 是精度退化最容易翻车的点 |
| `engine_collision_driver_test.cc` | 478 | `MjCollisionTest` | `AllCollisions` / `EmptyModel` / `ZeroedHessian` / `ContactCount` / `InGapContactsMultiGeomBody` / `FilterParent` / `FilterParentDoesntAffectWorldBody` / `TestOBB` / `PlaneInBody` / `PinchingSucceeds` / `MarginSumming` / `MaxContact` | 全 pipeline：`d->ncon`、`d->contact[i]` 字段、broadphase 过滤规则（parent filter、OBB、exclude/pair）、margin 求和、接触上限 | **全场景 `d->contact` 逐步对照的模板**。`ContactCount` / `MaxContact` / `MarginSumming` 直接给"结构性指标"的断言写法 |
| `engine_collision_convex_test.cc` | 80 | `MjcConvexTest` | `FramelessContact` / `FramelessContactHfield` / `CylinderBox` | 加载不崩 + `CylinderBox`：multiCCD 开→5 点，关→1 点 | `CylinderBox` 是"multiCCD 开关必须两边一致"的活证据 |
| `engine_collision_sdf_test.cc` | 150 | `SdfTest` | `SdfPrimitive` / `FlexSdfCollision` | SDF 碰撞产生接触、flex-SDF | 仅当 NPU 范围含 SDF |

内联模型的关键参数（挑对 NPU 有意义的）：
- `gjk_test.cc` 顶部 `kTolerance = 1e-6`、`kMaxIterations = 1000`、`kEllipsoidXml`（带 keyframe，`time="1.446"` 的具体位形）。
- `EllipsoidEllipsoidSlowConvergence` = 官方自己承认 EPA 会慢收敛的位形 → **fp32 下最可能发散，必测**。

### B.2 testdata 模型文件（`~/mujoco/test/engine/testdata/`）

| 路径 | 组成 | 覆盖 | 用途 |
|---|---|---|---|
| `collisions.xml` | 1 box + 5 sphere（各带不同 body/pair/exclude/broadphase 状态） | broadphase 分类（碰/不碰但需窄相位/可宽相位排除/exclude/predefined pair） | broadphase 超集/子集判定的最小验证模型 |
| `collision_box/boxbox_bad0.xml` `boxbox_bad1.xml` | box-box 病态位形 | 历史上产出错误接触的回归 | 精度退化会不会让"已修的 bug"复发 |
| `collision_box/boxbox_deep.xml` | box-box 深穿透 | EPA/SAT 深穿透 | 深度误差分桶的最深一档 |
| `collision_box/boxbox_duplicate.xml` | box-box 重复接触点 | 去重逻辑 | 虚检率 |
| `collision_driver/humanoid.xml` | humanoid（capsule 自碰 + sphere + cube） | capsule-capsule 自碰撞、多对 | 中等复杂度全场景轨迹对照 |
| `collision_driver/midphase.xml` | 1000 box + 1 plane + `<include>` | 中相位过滤压力 | broadphase/midphase 计时扩展性 |
| `collision_driver/planks.xml` | 1 box + 2 plane | 简单堆叠 | 冒烟 |
| `collision_convex/perf/box.xml` | 5×5×4=**100 free box** + 3 墙，`solver=CG iterations=10`，`multiccd=enable` | box-box 密集 + 墙约束 | `ccd_benchmark` 的 BoxBox / BoxBoxConvex 用例（见 B.3） |
| `collision_convex/perf/boxmesh.xml` | 同上但 geom 换成 **mesh**（8 顶点立方 mesh） | mesh-mesh 密集走 GJK | `ccd_benchmark` BoxMesh 用例；primitive-box vs mesh-box 的直接对照 |
| `collision_convex/perf/ellipsoid.xml` | 1 ellipsoid + 2 plane | ellipsoid 走 `mjc_Convex` | `ccd_benchmark` Ellipsoid 用例 |
| `collision_convex/perf/spheremesh.xml` | 1 mesh + 2 plane | sphere 化 mesh | mesh 起点 CCD |
| `collision_convex/perf/mixed.xml` | box+capsule+cylinder+ellipsoid+2 hfield+2 mesh+sphere，`replicate` 4/15/20 多层 | **全 geom 类型混合、上百 geom** | `ccd_benchmark` Mixed 用例；最接近真实厨房场景的窄相位压力 |
| `collision_convex/stacked_boxes.xml` | 4 primitive box + 1 mesh box，`multiccd=enable` | 堆叠稳定性 + primitive/mesh 混 | 多点接触流形的稳定性对照 |
| `collision_convex/edge_edge.xml` | 1 box + 2 mesh | **edge-edge 接触** | GJK/EPA 退化 case golden |
| `collision_convex/long_box.xml` | 细长 box | 长细比病态 | `gjk_test.cc:LongBox` 配套 |
| `collision_convex/dice.xml` `dice_boxmesh.xml` `die.obj` | 骰子（圆角立方 mesh） | 真实凸 mesh | mesh CCD 现实用例 |
| `collision_convex/cylinder_box.xml` | cylinder-box | multiCCD 5点/1点 | `convex_test.cc:CylinderBox` |
| `collision_convex/conemesh_box.xml` `cone.obj` | 圆锥 mesh - box | 尖顶凸体 | 支撑函数尖点 |
| `collision_convex/capsule_mesh.xml` | capsule - mesh | 混合 | — |
| `collision_convex/multiple_objects.xml` | box+cylinder+3 mesh+plane | 小型多物体 | 全场景冒烟 |
| `collision_convex/frameless_contact{,_hfield}.xml` | 接触帧退化（xaxis undefined 历史 bug） | 切向帧规范自由度 | 提醒：切向必须比"帧"不比"轴" |
| `collision_primitive/sphere_cylinder.xml` `spheres_cylinders.xml` | sphere-cylinder 单/多 | `mjc_SphereCylinder` 分区 | primitive 分区边界 |

### B.3 benchmark 模型（`~/mujoco/test/benchmark/`，性能基线）

| benchmark 文件 | 用例（`BENCHMARK`） | 模型 | 测什么 | 加速比对照口径 |
|---|---|---|---|---|
| `ccd_benchmark_test.cc` | `BM_BoxMesh` | `perf/boxmesh.xml`（100 mesh box） | mesh-mesh 窄相位（`mjc_Convex`），线程 0 / 9 | **NPU 碰撞加速比主战场**。ncon 累加 + 计时 |
| | `BM_BoxBox` | `perf/box.xml`（100 primitive box） | box-box 专用 SAT（`mjc_BoxBox`） | primitive 路径基线 |
| | `BM_BoxBoxConvex` | `perf/box.xml` + `NativeCCD` | 同模型强制走 CCD | 同一场景 SAT vs CCD 的代价差 |
| | `BM_Ellipsoid` | `perf/ellipsoid.xml` | ellipsoid CCD | — |
| | `BM_Mixed` | `perf/mixed.xml` | 全类型混合，上百 geom | 最接近真实场景的综合基线 |
| | (harness) | `kNumWarmupSteps=1000` 预热，`kBatchSize=50` 步计时，`kNumThreads=9` | — | NPU 侧要复刻这套预热/批大小 |
| `step_benchmark_test.cc` | `BM_StepHumanoid` | `model/humanoid/humanoid.xml` | 完整 `mj_step` | 用于证明"碰撞加速没有被 host↔NPU 传输吃掉整步收益" |
| | `BM_StepHumanoid100` | `model/humanoid/humanoid100.xml`（20 humanoid，4×5） | 多体接触密集 | 扩展性 |
| | `BM_StepParticle` | `model/replicate/particle.xml`（10×10×10=1000 sphere on slides + plane） | 海量 sphere-plane + sphere-sphere | broadphase 扩展性；NPU 批量吞吐最可能赢的场景 |
| | `BM_StepFlag` / `BM_StepFlagPlugin` | `flag.xml` / `flex/flag.xml` | flex 布料自碰 | 仅当范围含 flex |

> 注意：`model/` 目录在当前 checkout 里没实体化（sparse），但文件已 tracked，用 `git -C ~/mujoco show HEAD:model/humanoid/humanoid100.xml` 可取，或 `git -C ~/mujoco checkout -- model/`。

### B.4 计时接口（方案 Phase 4 性能报告用）

- `d->timer[mjTIMER_POS_COLLISION]` — 碰撞检测总耗时。
- `d->timer[mjTIMER_COL_BROAD]` — broadphase（`engine_collision_driver.c:621`）。
- `d->timer[mjTIMER_COL_NARROW]` — narrowphase（`:879`）。
- 这三个就是"分阶段耗时断面"的数据源，对齐 `conclusion.md` §3.2 的官方 Timer 方法。

### B.5 消融开关（方案对照实验用）

| flag | 作用 | 为什么要在对照里控制 |
|---|---|---|
| `mjDSBL_NATIVECCD` (1<<17) | 关 → 回退 libccd/MPR | 先确认 NPU 对标 native 还是 libccd |
| `mjDSBL_MULTICCD` (1<<19) | 关 → 凸–凸单点不补点 | 影响 ncon，两边必须一致 |
| `mjDSBL_MIDPHASE` (1<<14) | 关 → 跳过中相位 BVH 过滤 | 隔离 broadphase 效应 |
| `mjDSBL_CONTACT` (1<<4) | 关 → 完全不做接触约束 | 下游敏感度实验的对照端 |
| `m->opt.broadphase` | N² vs SAP 选择 | broadphase 子集/超集判定要固定算法 |
| `m->opt.ccd_iterations` / `ccd_tolerance` | CCD 迭代预算/容差 | NPU 若改动必须单列一档 |

---

## 下一步（承接方案 Phase 1 → Phase 2）

1. 把 B.1 里 `gjk_test.cc` 的 47 个内联模型 + B.2 的 testdata 文件抽成一个 `cases/` 清单（yaml：路径 / geom 对 / 算法族 / 是否有解析真值 / 初始 keyframe / step 数）。
2. 建 CPU-fp64 与 CPU-fp32 两个构建，对整张表跑一遍 `mjc_ccd` + 全场景 `mj_collision`，dump `d->contact` + `mjCCDStatus` + timer，存 golden + checksum。
3. fp64-vs-fp32 差异就是 NPU 误差下界，用它标定表 A.2 每族的容差阈值。
